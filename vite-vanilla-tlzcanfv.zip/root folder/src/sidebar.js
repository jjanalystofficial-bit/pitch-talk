// =========================================================================
// SIDEBAR — renderApp, sidebar lists, context menu, watermark
// =========================================================================

import { state, THEME_KEY } from './config.js'
import {
  sb, escapeHtml, avatarHTML, debounce,
  ICONS, stackedLogo, toastInfo, toastSuccess
} from './lib.js'
import {
  clearLastChat, updateTabTitle
} from './messages.js'
import { confirmDialog, openModal, closeModal } from './modals.js'
import { hideDmConversation, pendingCountFor, loadPendingRequests } from './social.js'

let rerenderSidebarDebounced = null

export function renderApp() {
  const root = document.getElementById('root')
  if (!root) return

  root.innerHTML = `
    <div class="app-shell">
      <div class="sidebar">
        <div class="sidebar-header">
          <div class="brand-mark" style="width:32px;height:32px;border-radius:8px;"></div>
          <span class="brand-name font-display" style="font-size:16px;">PitchTalk</span>
          <span class="ephemeral-chip" style="margin-left:auto;font-size:9px;">${ICONS.clock} midnight</span>
        </div>
        <div class="sidebar-actions">
          <button id="btn-new-chat" class="btn-soft">+ Direct message</button>
          <button id="btn-new-group" class="btn-soft">+ Group</button>
        </div>
        <div class="link-row">
          <button id="btn-search">${stackedLogo()} Search</button>
        </div>
        <div class="sidebar-lists" id="sidebar-lists"></div>
        <button class="profile-footer" id="btn-edit-profile">
          ${avatarHTML(state.profile.display_name||state.profile.username, state.profile.avatar_url, 'sm', { online: true })}
          <div class="row-text">
            <p class="row-title">${escapeHtml(state.profile.display_name||state.profile.username)}</p>
            <p class="row-sub">${escapeHtml(state.profile.status_text||'Available')}</p>
          </div>
          <span style="font-size:12px;color:var(--ink-dim);margin-left:auto;padding-left:12px;">My Profile</span>
        </button>
      </div>
      <div class="chat-pane" id="chat-pane"></div>
    </div>`

  document.getElementById('btn-new-chat').onclick = () => openModal('newChat')
  document.getElementById('btn-new-group').onclick = () => openModal('newGroup')
  document.getElementById('btn-search').onclick = () => openModal('search')
  document.getElementById('btn-edit-profile').onclick = () => openModal('profile')

  renderSidebarLists()
  renderChatPaneEmpty()
  scheduleWatermarkRefresh()
}

export function activeKey() {
  if (!state.activeChat) return null
  return state.activeChat.type === 'dm'
    ? `dm-${state.activeChat.user.id}`
    : `group-${state.activeChat.group.id}`
}

export function renderSidebarLists() {
  const el = document.getElementById('sidebar-lists')
  if (!el) return
  const key = activeKey()

  let html = '<p class="list-heading">Groups</p>'
  if (!state.groupChats.length) html += '<p class="list-empty">No groups yet.</p>'
  state.groupChats.forEach(g => {
    const gKey = `group-${g.id}`
    const count = state.unread[gKey] || 0
    const reqCount = pendingCountFor(g.id)
    const isActive = key === gKey
    const isUnread = count > 0 && !isActive
    html += `<button class="chat-row ${isActive?'active':''} ${isUnread?'unread':''}" data-group-id="${g.id}">
      <div class="group-icon">#</div>
      <div class="row-text">
        <p class="row-title">${escapeHtml(g.name)}</p>
        ${isUnread?`<p class="row-sub">${count} new message${count>1?'s':''}</p>`:''}
      </div>
      ${reqCount ? `<span class="req-badge" title="${reqCount} pending join request${reqCount>1?'s':''}">${reqCount}</span>` : ''}
      ${isUnread ? `<span class="unread-badge">${count>99?'99+':count}</span>` : ''}
    </button>`
  })

  html += '<p class="list-heading" style="margin-top:16px;">Direct messages</p>'
  const visibleDms = state.directChats.filter(u => !state.hiddenDms.has(u.id))
  if (!visibleDms.length) html += '<p class="list-empty">No conversations yet.</p>'
  visibleDms.forEach(u => {
    const dKey = `dm-${u.id}`
    const count = state.unread[dKey] || 0
    const isActive = key === dKey
    const isUnread = count > 0 && !isActive
    const online = state.onlineUsers.has(u.id)
    html += `<button class="chat-row ${isActive?'active':''} ${isUnread?'unread':''}" data-user-id="${u.id}">
      ${avatarHTML(u.display_name||u.username, u.avatar_url, 'sm', { online })}
      <div class="row-text">
        <p class="row-title">${escapeHtml(u.display_name||u.username)}</p>
        <p class="row-sub">${isUnread ? `${count} new message${count>1?'s':''}` : (online ? 'Online' : 'Offline')}</p>
      </div>
      ${isUnread ? `<span class="unread-badge">${count>99?'99+':count}</span>` : ''}
    </button>`
  })

  el.innerHTML = html
  renderScheduledBadge()
  el.querySelectorAll('[data-group-id]').forEach(b => {
    b.onclick = () => {
      const g = state.groupChats.find(x => x.id === b.dataset.groupId)
      if (g) window.dispatchEvent(new CustomEvent('pitchtalk:open-group', { detail: { group: g } }))
    }
  })
  el.querySelectorAll('[data-user-id]').forEach(b => {
    const uid = b.dataset.userId
    b.onclick = () => {
      const u = state.directChats.find(x => x.id === uid)
      if (u) window.dispatchEvent(new CustomEvent('pitchtalk:open-dm', { detail: { user: u } }))
    }
    b.addEventListener('contextmenu', (e) => {
      e.preventDefault()
      openDmContextMenu(uid, e.clientX, e.clientY)
    })
    attachLongPress(b, (x, y) => openDmContextMenu(uid, x, y))
  })
}

function renderScheduledBadge() {
  const lists = document.getElementById('sidebar-lists')
  if (!lists) return
  const pinned = document.getElementById('sched-pinned')
  if (pinned) pinned.remove()
  if (!state.scheduled.length) return
  const upcoming = state.scheduled.filter(s => new Date(s.send_at).getTime() - Date.now() < 3600_000).length
  lists.insertAdjacentHTML('afterbegin',
    `<button id="sched-pinned" class="chat-row" style="background:rgba(255,90,31,.08);border:1px solid rgba(255,90,31,.3);margin-bottom:8px;">
      <div class="group-icon" style="color:var(--ember-glow);border-color:rgba(255,90,31,.4);">${ICONS.clock}</div>
      <div class="row-text">
        <p class="row-title">Scheduled messages</p>
        <p class="row-sub">${state.scheduled.length} pending${upcoming ? ` · ${upcoming} due soon` : ''}</p>
      </div>
      ${upcoming ? `<span class="unread-badge">${upcoming}</span>` : ''}
    </button>`)
  const el = document.getElementById('sched-pinned')
  if (el) el.onclick = () => openModal('scheduledList')
}

export function renderChatPaneEmpty() {
  const el = document.getElementById('chat-pane')
  if (!el) return
  el.innerHTML = `<div class="chat-empty"><div>
    <div class="brand-mark" style="width:56px;height:56px;border-radius:18px;margin:0 auto 16px;"></div>
    <p>Pick a person or group to start talking.</p>
    <p style="font-size:12px;opacity:.7;margin-top:8px;">All messages clear at midnight.</p>
  </div></div>`
}

export function scheduleSidebarRerender() {
  if (!rerenderSidebarDebounced) rerenderSidebarDebounced = debounce(renderSidebarLists, 150)
  rerenderSidebarDebounced()
}

window.addEventListener('pitchtalk:sidebar-rerender', scheduleSidebarRerender)

// =========================================================================
// CONTEXT MENU
// =========================================================================
function closeCtxMenu() {
  document.getElementById('ctx-menu')?.remove()
  document.removeEventListener('click', onGlobalClickForCtx)
  document.removeEventListener('contextmenu', onGlobalCtxForCtx)
  document.removeEventListener('keydown', onEscForCtx)
  document.removeEventListener('scroll', closeCtxMenu, true)
}
function onGlobalClickForCtx(e) {
  if (!e.target.closest('#ctx-menu')) closeCtxMenu()
}
function onGlobalCtxForCtx(e) {
  if (!e.target.closest('#ctx-menu')) closeCtxMenu()
}
function onEscForCtx(e) {
  if (e.key === 'Escape') closeCtxMenu()
}

function openDmContextMenu(otherUserId, x, y) {
  closeCtxMenu()
  const u = state.directChats.find(z => z.id === otherUserId)
  const name = u?.display_name || u?.username || 'this user'

  const menu = document.createElement('div')
  menu.id = 'ctx-menu'
  menu.innerHTML = `
    <button id="ctx-open-dm">${ICONS.chat}Open conversation</button>
    <div class="ctx-sep"></div>
    <button id="ctx-delete-dm" class="danger">${ICONS.trash}Delete conversation</button>`
  document.body.appendChild(menu)

  const rect = menu.getBoundingClientRect()
  const vw = window.innerWidth, vh = window.innerHeight
  let px = x, py = y
  if (px + rect.width > vw - 8) px = vw - rect.width - 8
  if (py + rect.height > vh - 8) py = vh - rect.height - 8
  if (px < 8) px = 8
  if (py < 8) py = 8
  menu.style.left = px + 'px'
  menu.style.top = py + 'px'

  menu.querySelector('#ctx-open-dm').onclick = () => {
    closeCtxMenu()
    const user = state.directChats.find(z => z.id === otherUserId)
    if (user) window.dispatchEvent(new CustomEvent('pitchtalk:open-dm', { detail: { user } }))
  }
  menu.querySelector('#ctx-delete-dm').onclick = async () => {
    closeCtxMenu()
    const ok = await confirmDialog({
      title: 'Delete conversation?',
      message: `This will remove the conversation with ${name} from your sidebar. It will stay for ${name} and reappear if they message you again.`,
      confirmText: 'Delete',
      danger: true
    })
    if (!ok) return
    await hideDmConversation(otherUserId)
  }

  setTimeout(() => {
    document.addEventListener('click', onGlobalClickForCtx)
    document.addEventListener('contextmenu', onGlobalCtxForCtx)
    document.addEventListener('keydown', onEscForCtx)
    document.addEventListener('scroll', closeCtxMenu, true)
  }, 0)
}

function attachLongPress(el, cb) {
  let pressTimer = null
  let startX = 0, startY = 0
  let longPressedAt = 0

  const start = (e) => {
    const t = e.touches ? e.touches[0] : e
    startX = t.clientX; startY = t.clientY
    longPressedAt = 0
    pressTimer = setTimeout(() => {
      longPressedAt = Date.now()
      if (navigator.vibrate) { try { navigator.vibrate(15) } catch (er) {} }
      cb(startX, startY)
    }, 500)
  }
  const cancel = () => { if (pressTimer) { clearTimeout(pressTimer); pressTimer = null } }
  const move = (e) => {
    if (!pressTimer) return
    const t = e.touches ? e.touches[0] : e
    const dx = Math.abs(t.clientX - startX)
    const dy = Math.abs(t.clientY - startY)
    if (dx > 8 || dy > 8) cancel()
  }
  el.addEventListener('touchstart', start, { passive: true })
  el.addEventListener('touchend', cancel)
  el.addEventListener('touchmove', move, { passive: true })
  el.addEventListener('touchcancel', cancel)
  el.addEventListener('click', (e) => {
    if (longPressedAt && Date.now() - longPressedAt < 700) {
      e.stopPropagation()
      e.preventDefault()
    }
  }, true)
}

// =========================================================================
// WATERMARK
// =========================================================================
function renderWatermark() {
  const layer = document.getElementById('watermark-layer')
  if (!layer) return
  if (!state.session || !state.profile) {
    layer.innerHTML = ''
    return
  }
  const name = state.profile.display_name || state.profile.username || 'user'
  const handle = state.profile.username || 'user'
  const now = new Date()
  const pad = n => String(n).padStart(2, '0')
  const stamp = `${now.getFullYear()}-${pad(now.getMonth()+1)}-${pad(now.getDate())} ${pad(now.getHours())}:${pad(now.getMinutes())}`
  const unit = `${name} · @${handle} · ${stamp}`
  const row = Array.from({ length: 6 }, () => unit).join('   ·   ')
  const lines = Array.from({ length: 14 }, () => row).join('\n')
  layer.innerHTML = `<div class="wm-tile">${escapeHtml(lines)}</div>`
}

function scheduleWatermarkRefresh() {
  renderWatermark()
  if (window.__wmTimer) clearInterval(window.__wmTimer)
  window.__wmTimer = setInterval(renderWatermark, 5 * 60 * 1000)
}

window.addEventListener('pitchtalk:profile-updated', () => scheduleWatermarkRefresh())