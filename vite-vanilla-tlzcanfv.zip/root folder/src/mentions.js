// =========================================================================
// MENTIONS — autocomplete, extraction, rendering
// =========================================================================

import { state } from './config.js'
import { escapeHtml, avatarHTML } from './lib.js'

export function currentMentionContext() {
  if (!state.activeChat) return { type: 'dm', memberUsernames: new Set() }
  if (state.activeChat.type === 'dm') return { type: 'dm', memberUsernames: new Set() }
  const memberUsernames = new Set(
    state.groupMembers
      .filter(m => m && m.username)
      .map(m => m.username.toLowerCase())
  )
  return { type: 'group', memberUsernames }
}

export function renderMessageBody(body, ctx = null) {
  let safe = escapeHtml(body || '')
  if (!ctx || ctx.type !== 'group') return safe

  const members = ctx.memberUsernames instanceof Set
    ? ctx.memberUsernames
    : new Set(ctx.memberUsernames || [])

  safe = safe.replace(/@([a-z0-9_]{2,20})/gi, (m, handle) => {
    const lower = handle.toLowerCase()
    if (lower === 'all') {
      return `<span class="mention mention-all">@all</span>`
    }
    if (members.has(lower)) {
      return `<span class="mention">@${handle}</span>`
    }
    return m
  })
  return safe
}

export function extractMentions(body) {
  const empty = { all: false, userIds: [] }
  if (!state.activeChat || state.activeChat.type !== 'group' || !body) return empty
  const handles = new Set(
    [...body.matchAll(/@([a-z0-9_]{2,20})/gi)].map(x => x[1].toLowerCase())
  )
  if (!handles.size) return empty

  const all = handles.has('all')
  const myId = state.session.user.id
  const userIds = [...new Set(
    state.groupMembers
      .filter(m => m.id !== myId)
      .filter(m => handles.has((m.username || '').toLowerCase()))
      .map(m => m.id)
  )]

  return { all, userIds }
}

export function attachMentionAutocomplete(inputEl) {
  if (!state.activeChat || state.activeChat.type !== 'group') return

  let popup = null
  let activeIdx = 0
  let matches = []
  let atPos = -1

  const myId = state.session.user.id

  function eligibleMembers() {
    return state.groupMembers.filter(m => m && m.id && m.id !== myId && m.username)
  }

  function buildList(prefix) {
    const p = (prefix || '').toLowerCase()
    const members = eligibleMembers()
    const showAll = p === '' || 'all'.startsWith(p) || p === 'a' || p === 'al'
    const list = []

    if (showAll) list.push({ kind: 'all' })

    const matched = members.filter(m => {
      if (!p) return true
      const u = (m.username || '').toLowerCase()
      const d = (m.display_name || '').toLowerCase()
      return u.startsWith(p) || d.includes(p)
    }).slice(0, showAll ? 7 : 8)

    matched.forEach(m => list.push({ kind: 'user', member: m }))
    return list
  }

  function close() {
    if (popup) { popup.remove(); popup = null }
    matches = []
    atPos = -1
  }

  function paint() {
    if (!popup) return
    if (!matches.length) {
      popup.innerHTML = `<div class="mention-empty">No members match</div>`
      return
    }
    popup.innerHTML = matches.map((m, i) => {
      if (m.kind === 'all') {
        return `<button type="button" class="mention-item is-all ${i===activeIdx?'active':''}" data-i="${i}">
          <span class="mention-badge">ALL</span>
          <span class="mention-name">Everyone in this group</span>
          <span class="mention-username">@all</span>
        </button>`
      }
      const mem = m.member
      return `<button type="button" class="mention-item ${i===activeIdx?'active':''}" data-i="${i}">
        ${avatarHTML(mem.display_name || mem.username, mem.avatar_url, 'xs')}
        <span class="mention-name">${escapeHtml(mem.display_name || mem.username)}</span>
        <span class="mention-username">@${escapeHtml(mem.username)}</span>
      </button>`
    }).join('')
    popup.querySelectorAll('[data-i]').forEach(b => {
      const idx = parseInt(b.dataset.i, 10)
      b.onmouseenter = () => { activeIdx = idx; paint() }
      b.onmousedown = (e) => { e.preventDefault(); pick(idx) }
    })
  }

  function currentPrefix() {
    if (atPos < 0) return ''
    const caret = inputEl.selectionStart
    return inputEl.value.slice(atPos + 1, caret)
  }

  function open(pos, prefix) {
    atPos = pos
    matches = buildList(prefix)
    if (!matches.length) { close(); return }
    activeIdx = 0
    if (!popup) {
      popup = document.createElement('div')
      popup.className = 'mention-popup'
      popup.setAttribute('role', 'listbox')
      inputEl.parentElement.appendChild(popup)
    }
    paint()
  }

  function pick(i) {
    const m = matches[i]
    if (!m || atPos < 0) return
    const caret = inputEl.selectionStart
    const before = inputEl.value.slice(0, atPos)
    const after = inputEl.value.slice(caret)
    const token = m.kind === 'all' ? '@all ' : `@${m.member.username} `
    inputEl.value = before + token + after
    const newCaret = (before + token).length
    inputEl.setSelectionRange(newCaret, newCaret)
    close()
    inputEl.dispatchEvent(new Event('input'))
  }

  inputEl.addEventListener('input', () => {
    const caret = inputEl.selectionStart
    const upto = inputEl.value.slice(0, caret)
    const at = upto.lastIndexOf('@')
    if (at === -1) { close(); return }
    const tail = upto.slice(at + 1)
    if (/\s/.test(tail)) { close(); return }
    if (tail.length > 20) { close(); return }
    open(at, tail)
  })

  inputEl.addEventListener('keydown', (e) => {
    if (!popup) return
    if (e.key === 'ArrowDown') {
      e.preventDefault()
      activeIdx = (activeIdx + 1) % matches.length
      paint()
    } else if (e.key === 'ArrowUp') {
      e.preventDefault()
      activeIdx = (activeIdx - 1 + matches.length) % matches.length
      paint()
    } else if (e.key === 'Enter' || e.key === 'Tab') {
      e.preventDefault()
      pick(activeIdx)
    } else if (e.key === 'Escape') {
      e.preventDefault()
      close()
    }
  })

  inputEl.addEventListener('blur', () => setTimeout(close, 150))
}