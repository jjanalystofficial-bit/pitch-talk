// =========================================================================
// STRUCTURED MESSAGES — bill, task, meeting, poll, wheel, capsule, location
// =========================================================================

import { state, MAX_MESSAGE_LENGTH, CURRENCIES } from './config.js'
import {
  sb, escapeHtml, avatarHTML, formatTime, formatDay,
  currencySymbol, computeSplit, toastError, toastSuccess,
  ICONS, stackedLogo
} from './lib.js'
import { buildStructuredRow } from './messages.js'
import { openModal, closeModal, confirmDialog } from './modals.js'

const STRUCTURED_RENDERERS = {}

// =========================================================================
// BILL
// =========================================================================
STRUCTURED_RENDERERS.bill = (info, m) => {
  const sym = currencySymbol(info.currency || 'PHP')
  const parts = (info.participants || []).map((p, i) => `
    <div class="bill-row" data-person="${i}">
      ${avatarHTML(p.display_name || p.username || 'User', p.avatar_url, 'xs')}
      <div class="row-text" style="min-width:0;">
        <p class="row-title">${escapeHtml(p.display_name || p.username || 'User')}${p.paid ? ' <span style="color:var(--online);font-size:10px;">paid</span>' : ''}</p>
        <p class="row-sub">${p.payer ? 'paid the bill' : 'owes'}</p>
      </div>
      <span class="bill-amount">${sym}${(p.share || 0).toFixed(2)}</span>
    </div>`).join('')
  return {
    html: `<div class="structured-center msg-in"><div class="bill-summary-card">
      <div class="bill-head">
        <div class="bill-icon">${ICONS.receipt}</div>
        <div>
          <p class="bill-title">${escapeHtml(info.title || 'Split bill')}</p>
          <p class="bill-sub">${(info.participants||[]).length} people · ${info.tipPct ? info.tipPct + '% tip · ' : ''}${sym}${(info.grand || info.total || 0).toFixed(2)} total</p>
        </div>
      </div>
      <div class="bill-rows">${parts}</div>
      <p class="bill-time">${formatTime(m.created_at)}</p>
    </div></div>`
  }
}

// =========================================================================
// TASK
// =========================================================================
STRUCTURED_RENDERERS.task = (info, m) => {
  const done = info.status === 'done'
  const overdue = !done && info.due_at && new Date(info.due_at).getTime() < Date.now()
  const mine = info.assignee_id === state.session.user.id
  const canToggle = mine || m.sender_id === state.session.user.id
  return {
    html: `<div class="structured-center"><div class="task-card ${done?'done':''}">
      <div class="task-head">
        <div class="task-check ${done?'checked':''}" ${canToggle?`data-toggle="1"`:''}>${done?'✓':''}</div>
        <div class="row-text" style="min-width:0;">
          <p class="task-title">${escapeHtml(info.title || 'Task')}</p>
          <p class="task-meta">${info.assignee_name ? `Assigned to ${escapeHtml(info.assignee_name)}` : 'Unassigned'}${info.due_at ? ` · due ${formatDay(info.due_at)} ${formatTime(info.due_at)}` : ''}</p>
          ${info.note ? `<p class="task-note">${escapeHtml(info.note)}</p>` : ''}
        </div>
        ${info.assignee_avatar !== undefined ? avatarHTML(info.assignee_name||'User', info.assignee_avatar, 'xs') : ''}
      </div>
      ${overdue ? `<p class="task-overdue">Overdue</p>` : ''}
    </div></div>`,
    wire(node) {
      const btn = node.querySelector('[data-toggle="1"]')
      if (!btn) return
      btn.onclick = async () => {
        const next = done ? 'open' : 'done'
        const newMeta = { ...info, status: next }
        const row = { metadata: newMeta }
        const { error } = await sb.from('messages').update(row).eq('id', m.id)
        if (error) toastError(error.message)
      }
    }
  }
}

// =========================================================================
// MEETING
// =========================================================================
STRUCTURED_RENDERERS.meeting = (info, m) => {
  const tally = {}
  Object.values(info.votes || {}).forEach(slotId => { tally[slotId] = (tally[slotId] || 0) + 1 })
  const myVote = (info.votes || {})[state.session.user.id]
  const responses = Object.keys(info.votes || {}).length
  return {
    html: `<div class="structured-center"><div class="meeting-card">
      <p class="meeting-title">${escapeHtml(info.title || 'Meeting')}</p>
      <p class="meeting-sub">${info.duration_min || 30} min · ${responses} response${responses===1?'':'s'}</p>
      <div class="meeting-slots">
        ${(info.slots || []).map(s => {
          const n = tally[s.id] || 0
          const mine = myVote === s.id
          return `<button class="meeting-slot ${mine?'mine':''}" data-slot="${s.id}">
            <span class="slot-time">${formatDay(s.at)} · ${formatTime(s.at)}</span>
            <span class="slot-count">${n ? `${n} ✓` : '—'}</span>
          </button>`
        }).join('')}
      </div>
    </div></div>`,
    wire(node) {
      node.querySelectorAll('[data-slot]').forEach(b => {
        b.onclick = async () => {
          const slotId = b.dataset.slot
          const newVotes = { ...(info.votes || {}) }
          if (newVotes[state.session.user.id] === slotId) delete newVotes[state.session.user.id]
          else newVotes[state.session.user.id] = slotId
          const newMeta = { ...info, votes: newVotes }
          const row = { metadata: newMeta }
          const { error } = await sb.from('messages').update(row).eq('id', m.id)
          if (error) toastError(error.message)
        }
      })
    }
  }
}

// =========================================================================
// LOCATION
// =========================================================================
STRUCTURED_RENDERERS.location = (info, m) => {
  const { lat, lng, label, accuracy } = info || {}
  if (typeof lat !== 'number' || typeof lng !== 'number') return null
  const d = 0.008
  const bbox = `${lng-d},${lat-d},${lng+d},${lat+d}`
  const mapSrc = `https://www.openstreetmap.org/export/embed.html?bbox=${bbox}&layer=mapnik&marker=${lat},${lng}`
  const gmaps = `https://www.google.com/maps?q=${lat},${lng}`
  return {
    html: `<div class="structured-center"><div class="loc-card">
      <iframe class="loc-map" src="${mapSrc}" loading="lazy" referrerpolicy="no-referrer"></iframe>
      <div class="loc-meta">
        <p class="loc-label">${escapeHtml(label || 'Shared location')}</p>
        <p class="loc-coords">${lat.toFixed(5)}, ${lng.toFixed(5)}${accuracy ? ` · ±${Math.round(accuracy)} m` : ''}</p>
        <a class="loc-open" href="${gmaps}" target="_blank" rel="noreferrer">Open in maps ↗</a>
      </div>
    </div></div>`
  }
}

// =========================================================================
// POLL
// =========================================================================
STRUCTURED_RENDERERS.poll = (info, m) => {
  const tally = {}
  Object.values(info.votes || {}).forEach(o => { tally[o] = (tally[o] || 0) + 1 })
  const total = Object.keys(info.votes || {}).length
  const myVote = (info.votes || {})[state.session.user.id]
  const closed = info.closed === true
  const canManage = m.sender_id === state.session.user.id
  return {
    html: `<div class="structured-center"><div class="poll-card">
      <p class="poll-q">${escapeHtml(info.question || 'Poll')}${closed ? ' <span class="poll-closed">closed</span>' : ''}</p>
      <div class="poll-opts">
        ${(info.options || []).map(o => {
          const n = tally[o.id] || 0
          const pct = total ? Math.round(100 * n / total) : 0
          const mine = myVote === o.id
          return `<button class="poll-opt ${mine?'mine':''}" data-opt="${o.id}" ${closed?'disabled':''}>
            <span class="poll-bar" style="width:${pct}%"></span>
            <span class="poll-text">${escapeHtml(o.text)}</span>
            <span class="poll-pct">${n} · ${pct}%</span>
          </button>`
        }).join('')}
      </div>
      <p class="poll-meta">${total} vote${total===1?'':'s'}${info.anonymous ? ' · anonymous' : ''}${canManage && !closed ? ' · <span data-close-poll style="cursor:pointer;color:var(--ember-glow);">close poll</span>' : ''}</p>
    </div></div>`,
    wire(node) {
      if (!closed) {
        node.querySelectorAll('[data-opt]').forEach(b => {
          b.onclick = async () => {
            const optId = b.dataset.opt
            const newVotes = { ...(info.votes || {}) }
            if (newVotes[state.session.user.id] === optId) delete newVotes[state.session.user.id]
            else newVotes[state.session.user.id] = optId
            const newMeta = { ...info, votes: newVotes }
            const row = { metadata: newMeta }
            const { error } = await sb.from('messages').update(row).eq('id', m.id)
            if (error) toastError(error.message)
          }
        })
      }
      const closeBtn = node.querySelector('[data-close-poll]')
      if (closeBtn) {
        closeBtn.onclick = async () => {
          const ok = await confirmDialog({
            title: 'Close this poll?',
            message: 'No one will be able to change their vote.',
            confirmText: 'Close poll'
          })
          if (!ok) return
          const newMeta = { ...info, closed: true }
          const row = { metadata: newMeta }
          const { error } = await sb.from('messages').update(row).eq('id', m.id)
          if (error) toastError(error.message)
        }
      }
    }
  }
}

// =========================================================================
// WHEEL
// =========================================================================
STRUCTURED_RENDERERS.wheel = (info, m) => {
  const { entries, winner } = info || {}
  if (!entries?.length) return null
  return {
    html: `<div class="structured-center"><div class="wheel-card">
      <p class="wheel-title">🎡 ${escapeHtml(winner || '?')}</p>
      <p class="wheel-sub">from ${entries.length} option${entries.length===1?'':'s'}</p>
      <div class="wheel-entries">${entries.map(e => `<span class="wheel-chip ${e===winner?'win':''}">${escapeHtml(e)}</span>`).join('')}</div>
      <p class="wheel-time">${formatTime(m.created_at)}</p>
    </div></div>`
  }
}

// =========================================================================
// CAPSULE
// =========================================================================
STRUCTURED_RENDERERS.capsule = (info, m) => {
  const { body, opens_at, title } = info || {}
  const now = Date.now()
  const opensMs = opens_at ? new Date(opens_at).getTime() : 0
  const locked = opensMs > now
  const diff = opensMs - now

  function countdownText() {
    if (!locked) return 'unlocked'
    const s = Math.max(0, Math.floor(diff / 1000))
    const d = Math.floor(s / 86400)
    const h = Math.floor((s % 86400) / 3600)
    const mi = Math.floor((s % 3600) / 60)
    const se = s % 60
    if (d > 0) return `opens in ${d}d ${h}h`
    if (h > 0) return `opens in ${h}h ${mi}m`
    if (mi > 0) return `opens in ${mi}m ${se}s`
    return `opens in ${se}s`
  }

  return {
    html: `<div class="structured-center"><div class="capsule-card">
      <div class="capsule-head">
        <div class="capsule-icon">${ICONS.capsule}</div>
        <div>
          <p class="capsule-title">${escapeHtml(title || 'Time capsule')}</p>
          <p class="capsule-sub">${locked ? `Sealed by ${escapeHtml(info.sender_name || 'someone')}` : 'Unlocked'}</p>
        </div>
      </div>
      ${locked
        ? `<p class="capsule-locked">🔒 Sealed until ${escapeHtml(new Date(opensMs).toLocaleString())}</p>`
        : `<div class="capsule-body">${escapeHtml(body || '')}</div>`}
      <p class="capsule-countdown" data-capsule-countdown="${m.id}">${countdownText()}</p>
    </div></div>`
  }
}

// =========================================================================
// DISPATCHER
// =========================================================================
export function renderStructured(type, info, m) {
  const fn = STRUCTURED_RENDERERS[type]
  if (!fn) return null
  return fn(info, m)
}

// =========================================================================
// MODALS — Bill, Task, Meeting, Location, Poll, Wheel, Capsule
// =========================================================================
export function buildSplitBillModal() {
  const chat = state.activeChat
  if (!chat) { toastError('Open a conversation first'); return }
  const isGroup = chat.type === 'group'
  const people = isGroup
    ? [{ ...state.profile, __self: true }, ...state.groupMembers.filter(m => m.id !== state.session.user.id)]
    : [{ ...state.profile, __self: true }, chat.user]

  const picked = new Set(people.map(p => p.id))

  document.getElementById('modal-title').textContent = 'Split bill'
  document.getElementById('modal-body').innerHTML = `
    <div class="field"><label>Title</label>
      <input id="sb-title" placeholder="Dinner, groceries, taxi…" maxlength="60" />
    </div>
    <div style="display:flex;gap:8px;">
      <div class="field" style="flex:2;"><label>Total amount</label>
        <input id="sb-total" type="number" min="0" step="0.01" placeholder="0.00" />
      </div>
      <div class="field" style="flex:1;"><label>Currency</label>
        <select id="sb-currency">
          ${CURRENCIES.map(([c,s]) => `<option value="${c}">${c} ${s}</option>`).join('')}
        </select>
      </div>
    </div>
    <div style="display:flex;gap:8px;">
      <div class="field" style="flex:1;"><label>Tip %</label>
        <input id="sb-tip" type="number" min="0" step="1" value="0" />
      </div>
      <div class="field" style="flex:2;"><label>Who paid?</label>
        <select id="sb-payer">
          ${people.map(p => `<option value="${p.id}">${escapeHtml(p.display_name || p.username)}${p.__self ? ' (you)' : ''}</option>`).join('')}
        </select>
      </div>
    </div>
    <div class="field"><label>Split between (<span id="sb-count">${picked.size}</span>)</label>
      <div id="sb-people" class="split-people"></div>
    </div>
    <div class="split-summary" id="sb-summary"></div>
    <p class="msg-error hidden" id="sb-error"></p>
    <button class="btn-primary" id="sb-send">Send split</button>`

  function updateSummary() {
    document.getElementById('sb-count').textContent = picked.size
    const total = parseFloat(document.getElementById('sb-total').value) || 0
    const tip = parseFloat(document.getElementById('sb-tip').value) || 0
    const cur = document.getElementById('sb-currency').value
    const sym = currencySymbol(cur)
    const ids = [...picked]
    if (!ids.length || total <= 0) {
      document.getElementById('sb-summary').innerHTML = `<p style="font-size:12px;color:var(--ink-dim);">Enter a total and pick at least one person.</p>`
      return
    }
    const { grand, shares } = computeSplit(total, tip, ids.map(() => 1))
    document.getElementById('sb-summary').innerHTML = `
      <div class="split-summary-row"><span>Subtotal</span><span>${sym}${total.toFixed(2)}</span></div>
      ${tip ? `<div class="split-summary-row"><span>Tip (${tip}%)</span><span>${sym}${(grand-total).toFixed(2)}</span></div>` : ''}
      <div class="split-summary-row total"><span>Total</span><span>${sym}${grand.toFixed(2)}</span></div>
      <div class="split-summary-row"><span>Each</span><span>${sym}${shares[0].toFixed(2)} (${ids.length} way${ids.length===1?'':'s'})</span></div>`
  }

  function paintPeople() {
    document.getElementById('sb-people').innerHTML = people.map(p => `
      <label class="split-person">
        <input type="checkbox" data-pick="${p.id}" ${picked.has(p.id) ? 'checked' : ''} />
        ${avatarHTML(p.display_name || p.username, p.avatar_url, 'xs')}
        <span>${escapeHtml(p.display_name || p.username)}${p.__self ? ' (you)' : ''}</span>
      </label>`).join('')
    document.querySelectorAll('[data-pick]').forEach(cb => {
      cb.onchange = () => {
        if (cb.checked) picked.add(cb.dataset.pick)
        else picked.delete(cb.dataset.pick)
        updateSummary()
      }
    })
    updateSummary()
  }

  document.getElementById('sb-total').addEventListener('input', updateSummary)
  document.getElementById('sb-tip').addEventListener('input', updateSummary)
  document.getElementById('sb-currency').addEventListener('change', updateSummary)
  paintPeople()

  document.getElementById('sb-send').onclick = async () => {
    const errEl = document.getElementById('sb-error')
    errEl.classList.add('hidden')
    const title = document.getElementById('sb-title').value.trim() || 'Split bill'
    const total = parseFloat(document.getElementById('sb-total').value)
    const tip = parseFloat(document.getElementById('sb-tip').value) || 0
    const cur = document.getElementById('sb-currency').value
    const payer = document.getElementById('sb-payer').value
    const ids = [...picked]
    if (!total || total <= 0) { errEl.textContent = 'Enter a total > 0.'; errEl.classList.remove('hidden'); return }
    if (!ids.length) { errEl.textContent = 'Pick at least one person.'; errEl.classList.remove('hidden'); return }

    const { grand, shares } = computeSplit(total, tip, ids.map(() => 1))
    const participants = ids.map((uid, i) => {
      const p = people.find(x => x.id === uid)
      return {
        user_id: uid,
        display_name: p?.display_name || p?.username || 'User',
        avatar_url: p?.avatar_url || null,
        share: shares[i],
        payer: uid === payer
      }
    })
    const info = { title, currency: cur, total, tipPct: tip, grand, payer_id: payer, participants }

    const btn = document.getElementById('sb-send')
    btn.disabled = true; btn.textContent = 'Sending…'
    try {
      const row = buildStructuredRow({
        type: 'bill', info, isGroup,
        groupId: isGroup ? chat.group.id : null,
        recipientId: isGroup ? null : chat.user.id
      })
      const { data: inserted, error } = await sb.from('messages').insert(row).select().single()
      if (error) throw error
      window.__pitchtalk_appendMessage(window.__pitchtalk_normalize(inserted), { silent: true })
      closeModal()
      toastSuccess('Split sent')
    } catch (err) {
      errEl.textContent = err.message; errEl.classList.remove('hidden')
      btn.disabled = false; btn.textContent = 'Send split'
    }
  }
}

export function buildTaskModal() {
  const chat = state.activeChat
  if (!chat) { toastError('Open a conversation first'); return }
  const isGroup = chat.type === 'group'
  const people = isGroup ? state.groupMembers : [state.profile, chat.user]
  document.getElementById('modal-title').textContent = 'Assign task'
  document.getElementById('modal-body').innerHTML = `
    <div class="field"><label>Task</label>
      <input id="tk-title" maxlength="80" placeholder="Review the deck, Buy snacks…" />
    </div>
    <div class="field"><label>Assign to</label>
      <select id="tk-assignee">
        ${people.map(p => `<option value="${p.id}" ${p.id===state.session.user.id?'selected':''}>${escapeHtml(p.display_name||p.username)}${p.id===state.session.user.id?' (you)':''}</option>`).join('')}
      </select>
    </div>
    <div class="field"><label>Due (optional)</label>
      <input id="tk-due" type="datetime-local" />
    </div>
    <div class="field"><label>Note (optional)</label>
      <input id="tk-note" maxlength="120" />
    </div>
    <p class="msg-error hidden" id="tk-error"></p>
    <button class="btn-primary" id="tk-send">Send task</button>`

  document.getElementById('tk-send').onclick = async () => {
    const errEl = document.getElementById('tk-error')
    errEl.classList.add('hidden')
    const title = document.getElementById('tk-title').value.trim()
    if (!title) { errEl.textContent = 'Add a title.'; errEl.classList.remove('hidden'); return }
    const assigneeId = document.getElementById('tk-assignee').value
    const assignee = people.find(p => p.id === assigneeId)
    const dueStr = document.getElementById('tk-due').value
    const note = document.getElementById('tk-note').value.trim()
    const info = {
      title,
      assignee_id: assigneeId,
      assignee_name: assignee?.display_name || assignee?.username,
      assignee_avatar: assignee?.avatar_url || null,
      due_at: dueStr ? new Date(dueStr).toISOString() : null,
      note: note || null,
      status: 'open'
    }
    const btn = document.getElementById('tk-send')
    btn.disabled = true; btn.textContent = 'Sending…'
    try {
      const row = buildStructuredRow({
        type: 'task', info, isGroup,
        groupId: isGroup ? chat.group.id : null,
        recipientId: isGroup ? null : chat.user.id
      })
      const { data: inserted, error } = await sb.from('messages').insert(row).select().single()
      if (error) throw error
      window.__pitchtalk_appendMessage(window.__pitchtalk_normalize(inserted), { silent: true })
      closeModal()
      toastSuccess('Task sent')
    } catch (err) {
      errEl.textContent = err.message; errEl.classList.remove('hidden')
      btn.disabled = false; btn.textContent = 'Send task'
    }
  }
}

export function buildMeetingModal() {
  const chat = state.activeChat
  if (!chat) { toastError('Open a conversation first'); return }
  const isGroup = chat.type === 'group'
  document.getElementById('modal-title').textContent = 'Schedule meeting'
  document.getElementById('modal-body').innerHTML = `
    <div class="field"><label>Title</label>
      <input id="mt-title" maxlength="60" placeholder="Standup, Demo, Sync…" />
    </div>
    <div class="field"><label>Duration (minutes)</label>
      <input id="mt-dur" type="number" min="5" step="5" value="30" />
    </div>
    <div class="field"><label>Proposed slots (up to 5)</label>
      <div id="mt-slots"></div>
      <button type="button" class="btn-secondary" id="mt-add-slot" style="margin-top:8px;">+ Add slot</button>
    </div>
    <p class="msg-error hidden" id="mt-error"></p>
    <button class="btn-primary" id="mt-send">Send</button>`

  const slotsEl = document.getElementById('mt-slots')
  const rows = []
  function addSlot() {
    if (rows.length >= 5) return
    const d = new Date(Date.now() + 3600_000)
    const p = n => String(n).padStart(2,'0')
    const local = `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`
    const row = document.createElement('div')
    row.className = 'meeting-slot-row'
    row.innerHTML = `<input type="datetime-local" value="${local}" /><button type="button">×</button>`
    row.querySelector('button').onclick = () => {
      row.remove()
      const i = rows.indexOf(row)
      if (i > -1) rows.splice(i, 1)
    }
    rows.push(row)
    slotsEl.appendChild(row)
  }
  addSlot()
  document.getElementById('mt-add-slot').onclick = () => addSlot()

  document.getElementById('mt-send').onclick = async () => {
    const errEl = document.getElementById('mt-error')
    errEl.classList.add('hidden')
    const title = document.getElementById('mt-title').value.trim()
    const duration_min = parseInt(document.getElementById('mt-dur').value, 10) || 30
    const slotVals = rows.map(r => r.querySelector('input').value).filter(Boolean)
    if (!title) { errEl.textContent = 'Add a title.'; errEl.classList.remove('hidden'); return }
    if (!slotVals.length) { errEl.textContent = 'Add at least one slot.'; errEl.classList.remove('hidden'); return }
    const slots = slotVals.map((v, i) => ({ id: 's' + i, at: new Date(v).toISOString() }))
    const info = { title, duration_min, slots, votes: {} }
    const btn = document.getElementById('mt-send')
    btn.disabled = true; btn.textContent = 'Sending…'
    try {
      const row = buildStructuredRow({
        type: 'meeting', info, isGroup,
        groupId: isGroup ? chat.group.id : null,
        recipientId: isGroup ? null : chat.user.id
      })
      const { data: inserted, error } = await sb.from('messages').insert(row).select().single()
      if (error) throw error
      window.__pitchtalk_appendMessage(window.__pitchtalk_normalize(inserted), { silent: true })
      closeModal()
      toastSuccess('Meeting sent')
    } catch (err) {
      errEl.textContent = err.message; errEl.classList.remove('hidden')
      btn.disabled = false; btn.textContent = 'Send'
    }
  }
}

export function buildLocationModal() {
  const chat = state.activeChat
  if (!chat) { toastError('Open a conversation first'); return }
  const isGroup = chat.type === 'group'
  document.getElementById('modal-title').textContent = 'Share location'
  document.getElementById('modal-body').innerHTML = `
    <div class="field"><label>Label (optional)</label>
      <input id="loc-label" maxlength="60" placeholder="Meet here, Cafe, Office…" />
    </div>
    <div class="loc-preview" id="loc-preview"><p class="list-empty" style="padding:20px;text-align:center;">Getting your location…</p></div>
    <p class="msg-error hidden" id="loc-error"></p>
    <button class="btn-primary" id="loc-send" disabled>Send location</button>`

  let coords = null
  const errEl = document.getElementById('loc-error')
  const prev = document.getElementById('loc-preview')
  const sendBtn = document.getElementById('loc-send')

  if (!navigator.geolocation) {
    errEl.textContent = 'Geolocation not supported by this browser.'
    errEl.classList.remove('hidden'); return
  }
  navigator.geolocation.getCurrentPosition(
    (pos) => {
      coords = { lat: pos.coords.latitude, lng: pos.coords.longitude, accuracy: pos.coords.accuracy }
      const d = 0.008
      const bbox = `${coords.lng-d},${coords.lat-d},${coords.lng+d},${coords.lat+d}`
      prev.innerHTML = `<iframe class="loc-map" src="https://www.openstreetmap.org/export/embed.html?bbox=${bbox}&layer=mapnik&marker=${coords.lat},${coords.lng}" loading="lazy" referrerpolicy="no-referrer"></iframe>`
      sendBtn.disabled = false
    },
    (err) => {
      errEl.textContent = 'Could not get location: ' + err.message
      errEl.classList.remove('hidden')
    },
    { enableHighAccuracy: true, timeout: 8000 }
  )

  sendBtn.onclick = async () => {
    if (!coords) return
    const label = document.getElementById('loc-label').value.trim() || 'Shared location'
    sendBtn.disabled = true; sendBtn.textContent = 'Sending…'
    try {
      const row = buildStructuredRow({
        type: 'location',
        info: { ...coords, label },
        isGroup,
        groupId: isGroup ? chat.group.id : null,
        recipientId: isGroup ? null : chat.user.id
      })
      const { data: inserted, error } = await sb.from('messages').insert(row).select().single()
      if (error) throw error
      window.__pitchtalk_appendMessage(window.__pitchtalk_normalize(inserted), { silent: true })
      closeModal()
      toastSuccess('Location sent')
    } catch (err) {
      errEl.textContent = err.message; errEl.classList.remove('hidden')
      sendBtn.disabled = false; sendBtn.textContent = 'Send location'
    }
  }
}

export function buildPollModal() {
  const chat = state.activeChat
  if (!chat) { toastError('Open a conversation first'); return }
  const isGroup = chat.type === 'group'
  document.getElementById('modal-title').textContent = 'Create poll'
  document.getElementById('modal-body').innerHTML = `
    <div class="field"><label>Question</label>
      <input id="pl-q" maxlength="120" placeholder="Where should we eat?" />
    </div>
    <div class="field"><label>Options (2–6)</label>
      <div id="pl-opts"></div>
      <button type="button" class="btn-secondary" id="pl-add" style="margin-top:8px;">+ Add option</button>
    </div>
    <label class="poll-anon"><input type="checkbox" id="pl-anon" /> Anonymous</label>
    <p class="msg-error hidden" id="pl-error"></p>
    <button class="btn-primary" id="pl-send">Send poll</button>`

  const optsEl = document.getElementById('pl-opts')
  function addOpt() {
    if (optsEl.children.length >= 6) return
    const row = document.createElement('div')
    row.className = 'poll-opt-row'
    row.innerHTML = `<input maxlength="60" placeholder="Option ${optsEl.children.length+1}" /><button type="button">×</button>`
    row.querySelector('button').onclick = () => row.remove()
    optsEl.appendChild(row)
  }
  addOpt(); addOpt()
  document.getElementById('pl-add').onclick = () => addOpt()

  document.getElementById('pl-send').onclick = async () => {
    const errEl = document.getElementById('pl-error')
    errEl.classList.add('hidden')
    const question = document.getElementById('pl-q').value.trim()
    const texts = [...optsEl.querySelectorAll('input')].map(i => i.value.trim()).filter(Boolean)
    if (!question) { errEl.textContent = 'Add a question.'; errEl.classList.remove('hidden'); return }
    if (texts.length < 2) { errEl.textContent = 'Add at least 2 options.'; errEl.classList.remove('hidden'); return }
    const anonymous = document.getElementById('pl-anon').checked
    const info = { question, options: texts.map((t,i) => ({ id: 'o'+i, text: t })), votes: {}, anonymous, closed: false }
    const btn = document.getElementById('pl-send')
    btn.disabled = true; btn.textContent = 'Sending…'
    try {
      const row = buildStructuredRow({
        type: 'poll', info, isGroup,
        groupId: isGroup ? chat.group.id : null,
        recipientId: isGroup ? null : chat.user.id
      })
      const { data: inserted, error } = await sb.from('messages').insert(row).select().single()
      if (error) throw error
      window.__pitchtalk_appendMessage(window.__pitchtalk_normalize(inserted), { silent: true })
      closeModal()
      toastSuccess('Poll sent')
    } catch (err) {
      errEl.textContent = err.message; errEl.classList.remove('hidden')
      btn.disabled = false; btn.textContent = 'Send poll'
    }
  }
}

export function buildWheelModal() {
  const chat = state.activeChat
  if (!chat) { toastError('Open a conversation first'); return }
  const isGroup = chat.type === 'group'
  const defaultEntries = isGroup
    ? state.groupMembers.map(m => m.display_name || m.username)
    : [state.profile.display_name || state.profile.username, chat.user.display_name || chat.user.username]
  document.getElementById('modal-title').textContent = 'Spin the wheel'
  document.getElementById('modal-body').innerHTML = `
    <div class="field"><label>Entries (one per line)</label>
      <textarea id="wh-entries" style="min-height:120px;resize:vertical;">${escapeHtml(defaultEntries.join('\n'))}</textarea>
    </div>
    <p class="msg-error hidden" id="wh-error"></p>
    <button class="btn-primary" id="wh-send">Spin & send</button>`

  document.getElementById('wh-send').onclick = async () => {
    const errEl = document.getElementById('wh-error')
    errEl.classList.add('hidden')
    const entries = document.getElementById('wh-entries').value.split('\n').map(s => s.trim()).filter(Boolean)
    if (entries.length < 2) { errEl.textContent = 'Need at least 2 entries.'; errEl.classList.remove('hidden'); return }
    const buf = new Uint32Array(1); crypto.getRandomValues(buf)
    const winner = entries[buf[0] % entries.length]
    const info = { entries, winner, spun_at: new Date().toISOString() }
    const btn = document.getElementById('wh-send')
    btn.disabled = true; btn.textContent = 'Spinning…'
    try {
      const row = buildStructuredRow({
        type: 'wheel', info, isGroup,
        groupId: isGroup ? chat.group.id : null,
        recipientId: isGroup ? null : chat.user.id
      })
      const { data: inserted, error } = await sb.from('messages').insert(row).select().single()
      if (error) throw error
      window.__pitchtalk_appendMessage(window.__pitchtalk_normalize(inserted), { silent: true })
      closeModal()
      toastSuccess(`Landed on ${winner}`)
    } catch (err) {
      errEl.textContent = err.message; errEl.classList.remove('hidden')
      btn.disabled = false; btn.textContent = 'Spin & send'
    }
  }
}

export function buildCapsuleModal() {
  const chat = state.activeChat
  if (!chat) { toastError('Open a conversation first'); return }
  const isGroup = chat.type === 'group'
  document.getElementById('modal-title').textContent = 'Time capsule'
  document.getElementById('modal-body').innerHTML = `
    <div class="field"><label>Title (optional)</label>
      <input id="cp-title" maxlength="60" placeholder="Note to future us…" />
    </div>
    <div class="field"><label>Message</label>
      <textarea id="cp-body" maxlength="${MAX_MESSAGE_LENGTH}" placeholder="Write something to seal away…" style="min-height:100px;resize:vertical;"></textarea>
    </div>
    <div class="field"><label>Opens at</label>
      <input id="cp-opens" type="datetime-local" />
    </div>
    <p class="msg-error hidden" id="cp-error"></p>
    <button class="btn-primary" id="cp-send">Seal capsule</button>`

  const tomorrow = new Date()
  tomorrow.setDate(tomorrow.getDate() + 1)
  tomorrow.setHours(12, 0, 0, 0)
  const p = n => String(n).padStart(2, '0')
  document.getElementById('cp-opens').value =
    `${tomorrow.getFullYear()}-${p(tomorrow.getMonth()+1)}-${p(tomorrow.getDate())}T${p(tomorrow.getHours())}:${p(tomorrow.getMinutes())}`

  document.getElementById('cp-send').onclick = async () => {
    const errEl = document.getElementById('cp-error')
    errEl.classList.add('hidden')
    const title = document.getElementById('cp-title').value.trim() || 'Time capsule'
    const body = document.getElementById('cp-body').value.trim()
    const opensStr = document.getElementById('cp-opens').value
    if (!body) { errEl.textContent = 'Write a message.'; errEl.classList.remove('hidden'); return }
    if (!opensStr) { errEl.textContent = 'Pick an open time.'; errEl.classList.remove('hidden'); return }
    const opensAt = new Date(opensStr)
    if (opensAt.getTime() <= Date.now() + 10000) {
      errEl.textContent = 'Opens time must be at least 10 seconds in the future.'
      errEl.classList.remove('hidden'); return
    }
    const info = {
      title, body,
      opens_at: opensAt.toISOString(),
      sender_name: state.profile.display_name || state.profile.username
    }
    const btn = document.getElementById('cp-send')
    btn.disabled = true; btn.textContent = 'Sealing…'
    try {
      const row = buildStructuredRow({
        type: 'capsule', info, isGroup,
        groupId: isGroup ? chat.group.id : null,
        recipientId: isGroup ? null : chat.user.id
      })
      const { data: inserted, error } = await sb.from('messages').insert(row).select().single()
      if (error) throw error
      window.__pitchtalk_appendMessage(window.__pitchtalk_normalize(inserted), { silent: true })
      closeModal()
      toastSuccess('Capsule sealed')
    } catch (err) {
      errEl.textContent = err.message; errEl.classList.remove('hidden')
      btn.disabled = false; btn.textContent = 'Seal capsule'
    }
  }
}