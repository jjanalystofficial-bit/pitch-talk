// =========================================================================
// LIB — supabase client, helpers, toasts, sounds, icons, avatars
// =========================================================================

import {
  SUPABASE_URL, SUPABASE_ANON_KEY, BOOT_TIMEOUT_MS,
  CURRENCIES, LANGUAGES
} from './config.js'

// =========================================================================
// SUPABASE CLIENT
// =========================================================================
if (typeof supabase === 'undefined') {
  const root = document.getElementById('root')
  if (root) root.innerHTML = `
    <div class="boot-msg"><div>
      <p class="err" style="font-size:16px;font-weight:600;margin:0 0 8px">Supabase library failed to load</p>
      <p style="margin:0 0 12px">Your compiler is likely blocking the CDN.</p>
    </div></div>`
  throw new Error('Supabase CDN blocked')
}

export const sb = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: { persistSession: true, autoRefreshToken: true }
})

// =========================================================================
// TIMEOUT WRAPPER (fixed leak)
// =========================================================================
export function withTimeout(promise, ms, label) {
  let timerId
  return Promise.race([
    promise,
    new Promise((_, rej) => {
      timerId = setTimeout(
        () => rej(new Error(`Timeout ${ms}ms: ${label}`)),
        ms
      )
    })
  ]).finally(() => clearTimeout(timerId))
}

// =========================================================================
// STRING / NUMBER HELPERS
// =========================================================================
export function escapeHtml(str = '') {
  return String(str)
    .replaceAll('&','&amp;')
    .replaceAll('<','&lt;')
    .replaceAll('>','&gt;')
    .replaceAll('"','&quot;')
    .replaceAll("'",'&#039;')
}

export function initialsOf(name = '') {
  const p = name.trim().split(/\s+/).filter(Boolean)
  if (!p.length) return '?'
  if (p.length === 1) return p[0].slice(0,2).toUpperCase()
  return (p[0][0] + p[1][0]).toUpperCase()
}

const TINTS = ['#ff5a1f','#c2410c','#9a3412','#e2622a','#b1440e','#d9480f']
export function tintOf(s='') {
  let h=0
  for (let i=0;i<s.length;i++) h=(h*31+s.charCodeAt(i))>>>0
  return TINTS[h%TINTS.length]
}

export function formatBytes(b) {
  if (b==null) return ''
  if (b<1024) return `${b} B`
  if (b<1048576) return `${(b/1024).toFixed(1)} KB`
  if (b<1073741824) return `${(b/1048576).toFixed(1)} MB`
  return `${(b/1073741824).toFixed(2)} GB`
}

export function formatTime(iso) {
  return new Date(iso).toLocaleTimeString([], { hour:'2-digit', minute:'2-digit' })
}

export function formatDay(iso) {
  const d = new Date(iso), t = new Date(), y = new Date()
  y.setDate(t.getDate()-1)
  if (d.toDateString() === t.toDateString()) return 'Today'
  if (d.toDateString() === y.toDateString()) return 'Yesterday'
  return d.toLocaleDateString([], { month:'short', day:'numeric', year:'numeric' })
}

export function formatDuration(seconds) {
  const s = Math.max(0, Math.floor(seconds))
  const h = Math.floor(s / 3600)
  const m = Math.floor((s % 3600) / 60)
  const sec = s % 60
  if (h > 0) return `${h}:${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`
  return `${m}:${String(sec).padStart(2,'0')}`
}

export function formatDurationLong(seconds) {
  const s = Math.max(0, Math.floor(seconds))
  const h = Math.floor(s / 3600)
  const m = Math.floor((s % 3600) / 60)
  const sec = s % 60
  const parts = []
  if (h > 0) parts.push(`${h} hr`)
  if (m > 0) parts.push(`${m} min`)
  if (sec > 0 && h === 0) parts.push(`${sec} sec`)
  return parts.length ? parts.join(' ') : '0 sec'
}

export function scheduleLabel(iso) {
  const d = new Date(iso), now = Date.now()
  const diff = d.getTime() - now
  if (diff < 0) return 'Overdue'
  if (diff < 60_000) return 'in <1 min'
  if (diff < 3600_000) return `in ${Math.round(diff/60_000)} min`
  if (d.toDateString() === new Date().toDateString()) {
    return `today ${d.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}`
  }
  if (d.toDateString() === new Date(Date.now()+86400_000).toDateString()) {
    return `tomorrow ${d.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}`
  }
  return d.toLocaleString([], {month:'short', day:'numeric', hour:'2-digit', minute:'2-digit'})
}

export function debounce(fn, ms) {
  let t
  return (...a) => {
    clearTimeout(t)
    t = setTimeout(() => fn(...a), ms)
  }
}

export function sanitizeFileName(name = '') {
  let base = String(name).replace(/[\\/]/g, '_').replace(/[^a-zA-Z0-9._-]/g, '_')
  base = base.replace(/^[.\-]+/, '')
  if (base.length > 100) {
    const dot = base.lastIndexOf('.')
    const ext = dot > 0 && base.length - dot <= 10 ? base.slice(dot) : ''
    base = base.slice(0, 100 - ext.length) + ext
  }
  if (!base) base = 'file'
  return base
}

export function currencySymbol(code) {
  return (CURRENCIES.find(c => c[0] === code) || [null, code])[1]
}

export function round2(n) { return Math.round(n * 100) / 100 }

export function computeSplit(total, tipPct, weights) {
  const grand = round2(total * (1 + (tipPct || 0) / 100))
  const sumW = weights.reduce((a,b) => a+b, 0) || 1
  const shares = weights.map(w => round2(grand * (w / sumW)))
  const drift = round2(grand - shares.reduce((a,b) => a+b, 0))
  if (shares.length) shares[shares.length - 1] = round2(shares[shares.length - 1] + drift)
  return { grand, shares }
}

// =========================================================================
// FILE TYPE VALIDATION
// =========================================================================
const ALLOWED_MIME_PREFIXES = ['image/', 'audio/', 'video/']
const ALLOWED_MIME_EXACT = new Set([
  'application/pdf','application/zip','application/json','application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.ms-excel',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'application/vnd.ms-powerpoint',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  'text/plain','text/csv','text/markdown'
])
const BLOCKED_MIME_EXACT = new Set([
  'image/svg+xml','text/html','application/xhtml+xml','application/xml','text/xml',
  'application/javascript','text/javascript','application/x-javascript'
])
const BLOCKED_EXTENSIONS = new Set([
  'html','htm','xhtml','svg','xml','js','mjs','cjs',
  'exe','sh','bat','cmd','com','scr','msi','jar',
  'php','phtml','asp','aspx','jsp','cgi','pl'
])

export function isAllowedFileType(file) {
  const mime = (file.type || '').toLowerCase()
  const ext = (file.name.split('.').pop() || '').toLowerCase()
  if (BLOCKED_EXTENSIONS.has(ext)) return false
  if (BLOCKED_MIME_EXACT.has(mime)) return false
  if (mime && ALLOWED_MIME_EXACT.has(mime)) return true
  if (mime && ALLOWED_MIME_PREFIXES.some(p => mime.startsWith(p))) return true
  if (!mime) {
    const safeExt = new Set([
      'png','jpg','jpeg','gif','webp','bmp','pdf','txt','csv','md','zip',
      'mp3','wav','ogg','m4a','mp4','webm','mov',
      'doc','docx','xls','xlsx','ppt','pptx'
    ])
    return safeExt.has(ext)
  }
  return false
}

// =========================================================================
// ICONS (inline SVG strings)
// =========================================================================
export const ICONS = {
  phone: `<svg viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>`,
  video: `<svg viewBox="0 0 24 24"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg>`,
  micOn: `<svg viewBox="0 0 24 24"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg>`,
  micOff: `<svg viewBox="0 0 24 24"><line x1="1" y1="1" x2="23" y2="23"/><path d="M9 9v3a3 3 0 0 0 5.12 2.12M15 9.34V4a3 3 0 0 0-5.94-.6"/><path d="M17 16.95A7 7 0 0 1 5 12v-2m14 0v2a7 7 0 0 1-.11 1.23"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg>`,
  camOn: `<svg viewBox="0 0 24 24"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg>`,
  camOff: `<svg viewBox="0 0 24 24"><line x1="1" y1="1" x2="23" y2="23"/><path d="M21 6.5l-5 3.5v7l5 3.5"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg>`,
  end: `<svg viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" transform="rotate(135 12 12)"/></svg>`,
  edit: `<svg viewBox="0 0 24 24" style="width:14px;height:14px;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>`,
  trash: `<svg viewBox="0 0 24 24" style="width:14px;height:14px;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>`,
  phoneIn: `<svg viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>`,
  phoneOut: `<svg viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" transform="rotate(45 12 12)"/></svg>`,
  phoneMissed: `<svg viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" transform="rotate(135 12 12)"/></svg>`,
  videoCall: `<svg viewBox="0 0 24 24"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg>`,
  paperclip: `<svg viewBox="0 0 24 24" style="width:18px;height:18px;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg>`,
  search: `<svg viewBox="0 0 24 24" style="width:18px;height:18px;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>`,
  clock: `<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>`,
  bomb: `<svg viewBox="0 0 24 24"><circle cx="11" cy="13" r="7"/><path d="M17 7l2-2"/><path d="M20.5 3.5l.5.5"/><path d="M19 6l1.5-1.5"/></svg>`,
  chat: `<svg viewBox="0 0 24 24" style="width:15px;height:15px;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>`,
  receipt: `<svg viewBox="0 0 24 24"><path d="M4 2v20l2-2 2 2 2-2 2 2 2-2 2 2 2-2 2 2V2l-2 2-2-2-2 2-2-2-2 2-2-2-2 2-2-2z"/><line x1="8" y1="9" x2="16" y2="9"/><line x1="8" y1="13" x2="16" y2="13"/></svg>`,
  taskIcon: `<svg viewBox="0 0 24 24"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>`,
  calendar: `<svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>`,
  pin: `<svg viewBox="0 0 24 24"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>`,
  poll: `<svg viewBox="0 0 24 24"><line x1="6" y1="20" x2="6" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="18" y1="20" x2="18" y2="14"/></svg>`,
  wheel: `<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="3"/><line x1="12" y1="2" x2="12" y2="9"/><line x1="12" y1="15" x2="12" y2="22"/><line x1="2" y1="12" x2="9" y2="12"/><line x1="15" y1="12" x2="22" y2="12"/></svg>`,
  capsule: `<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/><path d="M8 3h8"/></svg>`,
  translate: `<svg viewBox="0 0 24 24" style="width:14px;height:14px;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>`,
  tools: `<svg viewBox="0 0 24 24" style="width:18px;height:18px;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>`
}

export function stackedLogo() {
  return `<span class="logo-stack"><span></span><span></span><span></span></span>`
}

export function toolIconStack(svgInner) {
  return `<span class="tool-icon-stack">
    <span class="tis-layer">${svgInner}</span>
    <span class="tis-layer">${svgInner}</span>
    <span class="tis-layer">${svgInner}</span>
  </span>`
}

// =========================================================================
// AVATARS
// =========================================================================
export function avatarHTML(name, url, size='md', { online, square, clickable, userId } = {}) {
  const shape = square ? 'square' : 'round'
  const dot = online === undefined ? '' : `<span class="avatar-dot ${online ? 'online' : 'offline'}"></span>`
  const inner = url
    ? `<img src="${escapeHtml(url)}" alt="" class="avatar-${size}" />`
    : `<div class="avatar-fallback avatar-${size}" style="background:${tintOf(name)}">${initialsOf(name)}</div>`
  const clickAttr = clickable && userId ? `data-avatar-user="${userId}"` : ''
  const cls = `avatar ${shape} ${clickable ? 'clickable' : ''}`
  return `<div class="${cls}" ${clickAttr}>${inner}${dot}</div>`
}

export function avatarStackHTML(members = [], max = 5, { clickable = false } = {}) {
  const s = members.slice(0, max)
  const o = members.length - s.length
  let h = '<div class="avatar-stack">'
  s.forEach((m, i) => {
    h += `<div class="avatar-stack-item" style="margin-left:${i===0?0:-8}px;z-index:${s.length-i}">${avatarHTML(m.display_name||m.username||'You', m.avatar_url, 'xs', { clickable, userId: m.id })}</div>`
  })
  if (o > 0) h += `<div class="avatar-stack-overflow">+${o}</div>`
  h += '</div>'
  return h
}

// =========================================================================
// TOASTS
// =========================================================================
const TOAST_ICONS = {
  info: `<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>`,
  success: `<svg viewBox="0 0 24 24"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>`,
  error: `<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`
}

export function showToast(message, kind = 'info', opts = {}) {
  const host = document.getElementById('toast-host')
  if (!host) return
  const el = document.createElement('div')
  el.className = `toast toast-${kind}`
  const icon = TOAST_ICONS[kind] || TOAST_ICONS.info
  el.innerHTML = `
    <span class="toast-icon">${icon}</span>
    <span class="toast-msg">${escapeHtml(String(message))}</span>
    <button class="toast-close" aria-label="Close">&times;</button>`
  const ttl = opts.ttl ?? (kind === 'error' ? 6000 : 3500)
  let removed = false
  const remove = () => {
    if (removed) return
    removed = true
    el.classList.add('leaving')
    setTimeout(() => { try { el.remove() } catch (e) {} }, 180)
  }
  el.querySelector('.toast-close').onclick = remove
  host.appendChild(el)
  if (ttl > 0) setTimeout(remove, ttl)
  return remove
}

export const toastInfo = (m, o) => showToast(m, 'info', o)
export const toastSuccess = (m, o) => showToast(m, 'success', o)
export const toastError = (m, o) => showToast(m, 'error', o)

// =========================================================================
// SOUNDS
// =========================================================================
export const SOUNDS = {
  incoming:    'https://cdrvltvzirabnetaauiz.supabase.co/storage/v1/object/public/sounds/incoming%20call.mp3',
  outgoing:    'https://cdrvltvzirabnetaauiz.supabase.co/storage/v1/object/public/sounds/incoming%20call.mp3',
  drop:        'https://cdrvltvzirabnetaauiz.supabase.co/storage/v1/object/public/sounds/incoming%20message.mp3',
  msgSent:     'https://cdrvltvzirabnetaauiz.supabase.co/storage/v1/object/public/sounds/message%20sent.mp3',
  msgReceived: 'https://cdrvltvzirabnetaauiz.supabase.co/storage/v1/object/public/sounds/incoming%20message.mp3'
}
const soundPlayers = {}
let audioUnlocked = false

export function playSound(id, kind, loop = false) {
  stopSound(id)
  try {
    const src = SOUNDS[kind]
    const audio = new Audio(src)
    audio.loop = loop
    audio.volume = 0.6
    const p = audio.play()
    if (p && p.catch) p.catch(() => {})
    soundPlayers[id] = audio
  } catch (e) {}
}

export function stopSound(id) {
  const a = soundPlayers[id]
  if (a) {
    try { a.pause(); a.currentTime = 0 } catch (e) {}
    delete soundPlayers[id]
  }
}

export function stopAllSounds() {
  Object.keys(soundPlayers).forEach(stopSound)
}

export function initAudioUnlock() {
  const unlock = () => {
    if (audioUnlocked) return
    try {
      const AC = window.AudioContext || window.webkitAudioContext
      if (AC) { const ctx = new AC(); if (ctx.state === 'suspended') ctx.resume() }
      const s = new Audio(); s.volume = 0; s.play().catch(() => {})
      audioUnlocked = true
    } catch (e) {}
    document.removeEventListener('click', unlock)
    document.removeEventListener('touchstart', unlock)
    document.removeEventListener('keydown', unlock)
  }
  document.addEventListener('click', unlock)
  document.addEventListener('touchstart', unlock)
  document.addEventListener('keydown', unlock)
}

// =========================================================================
// FALLBACK EXPORTS (re-export config for convenience)
// =========================================================================
export { LANGUAGES, CURRENCIES, BOOT_TIMEOUT_MS }