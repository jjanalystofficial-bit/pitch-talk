// =========================================================================
// CALLS — WebRTC, overlay, flow, summary
// =========================================================================

import { state, TAB_ID, ICE_SERVERS } from './config.js'
import {
  sb, escapeHtml, avatarHTML, formatDuration,
  formatDurationLong, playSound, stopSound, stopAllSounds,
  toastError, ICONS, withTimeout, BOOT_TIMEOUT_MS
} from './lib.js'
import { buildCallRow, normalizeMessage } from './messages.js'
import { refreshGroupMembers } from './social.js'

let callStatusChannel = null
let callChannel = null
let readyChannel = null
let incomingCallsChannel = null
let myLocalStream = null
let outgoingRingTimeout = null
let callTimerInterval = null

function getPeerLabel(uid) {
  if (state.profile && uid === state.profile.id) return 'You'
  const f = state.directChats.find(u => u.id === uid)
  if (f) return f.display_name || f.username
  const g = state.groupMembers.find(m => m.id === uid)
  if (g) return g.display_name || g.username
  if (state.call && state.call.caller && state.call.caller.id === uid) {
    return state.call.caller.display_name || state.call.caller.username
  }
  return 'User'
}
function getPeerAvatar(uid) {
  if (state.profile && uid === state.profile.id) return state.profile.avatar_url
  const f = state.directChats.find(u => u.id === uid)
  if (f) return f.avatar_url
  const g = state.groupMembers.find(m => m.id === uid)
  if (g) return g.avatar_url
  if (state.call && state.call.caller && state.call.caller.id === uid) return state.call.caller.avatar_url
  return null
}

export function setupReadyChannel(callId) {
  if (readyChannel) { try { sb.removeChannel(readyChannel) } catch (e) {} readyChannel = null }
  readyChannel = sb.channel(`call-ready-${callId}-${TAB_ID}`, {
    config: { broadcast: { self: false } }
  })
    .on('broadcast', { event: 'ready' }, ({ payload }) => {
      if (!state.call || state.call.id !== callId) return
      if (payload?.user_id === state.session.user.id) return
      initPeers().catch(() => {})
    })
    .subscribe((status) => {
      if (status === 'SUBSCRIBED' && state.call && state.call.localStream) {
        try {
          readyChannel.send({
            type: 'broadcast', event: 'ready',
            payload: { user_id: state.session.user.id }
          })
        } catch (e) {}
      }
    })
}

export function broadcastReady() {
  if (!readyChannel || !state.call) return
  try {
    readyChannel.send({
      type: 'broadcast', event: 'ready',
      payload: { user_id: state.session.user.id }
    })
  } catch (e) {}
}

export async function startCall(kind) {
  if (state.call) { toastError('Already in a call'); return }
  const chat = state.activeChat
  if (!chat) { toastError('Open a conversation first'); return }
  const isGroup = chat.type === 'group'
  const calleeId = isGroup ? null : chat.user.id
  const groupId = isGroup ? chat.group.id : null
  if (!isGroup && !state.onlineUsers.has(calleeId)) {
    toastError(`${getPeerLabel(calleeId)} is offline`); return
  }
  try {
    if (isGroup) await refreshGroupMembers()
    myLocalStream = await navigator.mediaDevices.getUserMedia({
      audio: true, video: kind === 'video'
    })
    const { data: callRow, error } = await sb.from('calls').insert({
      caller_id: state.session.user.id, callee_id: calleeId,
      group_id: groupId, kind, status: 'ringing'
    }).select().single()
    if (error) throw error
    state.call = {
      id: callRow.id, kind, isGroup,
      outgoing: true, incoming: false, status: 'ringing',
      callerId: state.session.user.id, calleeId,
      caller: state.profile,
      localStream: myLocalStream,
      peers: {}, muted: false, camOff: kind === 'audio',
      startedAt: null, endedAt: null, endedPosted: false
    }
    renderCallOverlay()
    subscribeCallSignals(callRow.id)
    subscribeCallStatus(callRow.id)
    setupReadyChannel(callRow.id)
    attachLocalVideo()
    playSound('outgoing', 'outgoing', true)
    if (!isGroup) {
      outgoingRingTimeout = setTimeout(() => {
        if (state.call && state.call.status === 'ringing') endCall(true)
      }, 30000)
    }
  } catch (err) {
    toastError('Could not start call: ' + err.message)
    if (myLocalStream) {
      try { myLocalStream.getTracks().forEach(t => t.stop()) } catch (e) {}
      myLocalStream = null
    }
    cleanupCall()
  }
}

function startCallTimer() {
  if (callTimerInterval) return
  if (!state.call) return
  if (!state.call.startedAt) state.call.startedAt = Date.now()
  callTimerInterval = setInterval(() => {
    const el = document.getElementById('call-timer')
    if (!el || !state.call || !state.call.startedAt) return
    const secs = (Date.now() - state.call.startedAt) / 1000
    el.textContent = formatDuration(secs)
  }, 500)
  const el = document.getElementById('call-timer')
  if (el) el.textContent = formatDuration(0)
}
function stopCallTimer() {
  if (callTimerInterval) { clearInterval(callTimerInterval); callTimerInterval = null }
}

function subscribeCallStatus(callId) {
  if (callStatusChannel) {
    try { sb.removeChannel(callStatusChannel) } catch (e) {}
  }
  callStatusChannel = sb.channel(`call-status-${callId}`)
    .on('postgres_changes',
      { event: 'UPDATE', schema: 'public', table: 'calls', filter: `id=eq.${callId}` },
      async (payload) => {
        const row = payload.new
        if (!state.call) return
        if (row.status === 'accepted') {
          state.call.status = 'accepted'
          state.call.startedAt = Date.now()
          stopSound('outgoing'); stopSound('incoming')
          if (outgoingRingTimeout) { clearTimeout(outgoingRingTimeout); outgoingRingTimeout = null }
          renderCallOverlay()
          startCallTimer()
        } else if (row.status === 'declined' || row.status === 'ended') {
          stopAllSounds(); playSound('drop', 'drop', false)
          if (state.call && !state.call.endedPosted) {
            const wasConnected = !!state.call.startedAt
            const myId = state.session.user.id
            const amCallee = state.call.calleeId && myId === state.call.calleeId
            if (wasConnected && amCallee) {
              await postCallSummary({ missed: false })
            }
            state.call.endedPosted = true
          }
          cleanupCall()
        }
      }).subscribe()
}

export function subscribeIncomingCalls() {
  if (incomingCallsChannel) return
  incomingCallsChannel = sb.channel('incoming-calls-' + TAB_ID)
    .on('postgres_changes',
      { event: 'INSERT', schema: 'public', table: 'calls' },
      async (payload) => {
        const row = payload.new
        if (!row || row.caller_id === state.session.user.id || row.status !== 'ringing') return
        const isForMe = row.callee_id === state.session.user.id
        const isForMyGroup = row.group_id && state.groupChats.some(g => g.id === row.group_id)
        if (!isForMe && !isForMyGroup) return
        if (state.call) return
        let caller = null
        try {
          const { data } = await sb.from('profiles')
            .select('id, username, display_name, avatar_url')
            .eq('id', row.caller_id).maybeSingle()
          caller = data
        } catch (e) {}
        if (!caller) caller = { id: row.caller_id, username: 'Unknown', display_name: 'Unknown caller', avatar_url: null }
        const group = row.group_id ? state.groupChats.find(g => g.id === row.group_id) : null
        state.call = {
          id: row.id, kind: row.kind, isGroup: !!row.group_id,
          outgoing: false, incoming: true, status: 'ringing',
          callerId: row.caller_id, caller, group,
          localStream: null, peers: {}, muted: false, camOff: row.kind === 'audio',
          startedAt: null, endedAt: null, endedPosted: false
        }
        renderCallOverlay()
        playSound('incoming', 'incoming', true)
      }).subscribe()
}

export async function teardownIncomingCalls() {
  if (incomingCallsChannel) {
    try { await sb.removeChannel(incomingCallsChannel) } catch (e) {}
    incomingCallsChannel = null
  }
}

export async function acceptIncomingCall() {
  if (!state.call || !state.call.incoming) return
  try {
    stopSound('incoming')
    if (state.call.isGroup) await refreshGroupMembers()
    myLocalStream = await navigator.mediaDevices.getUserMedia({
      audio: true, video: state.call.kind === 'video'
    })
    state.call.localStream = myLocalStream
    state.call.camOff = state.call.kind === 'audio'
    const { error } = await sb.from('calls').update({ status: 'accepted' }).eq('id', state.call.id)
    if (error) throw error
    state.call.status = 'accepted'; state.call.incoming = false
    state.call.startedAt = Date.now()
    renderCallOverlay()
    subscribeCallSignals(state.call.id)
    subscribeCallStatus(state.call.id)
    setupReadyChannel(state.call.id)
    attachLocalVideo()
    startCallTimer()
    broadcastReady()
  } catch (err) {
    toastError('Could not accept call: ' + err.message)
    try { await endCall(true) } catch (e) { cleanupCall() }
  }
}

export async function declineIncomingCall() {
  if (!state.call) return
  stopAllSounds()
  stopCallTimer()
  await postCallSummary({ missed: true })
  try { await sb.from('calls').update({ status: 'declined' }).eq('id', state.call.id) } catch (e) {}
  cleanupCall()
}

function shouldIOffer(peerId) {
  return state.session.user.id < peerId
}

function initPeers() {
  if (!state.call) return Promise.resolve()
  const myId = state.session.user.id
  let peerIds = []
  if (state.call.isGroup) peerIds = state.groupMembers.map(m => m.id).filter(id => id !== myId)
  else {
    const o = state.call.callerId === myId ? state.call.calleeId : state.call.callerId
    if (o) peerIds = [o]
  }
  peerIds.forEach(peerId => {
    if (!state.call.peers[peerId]) createPeerConnection(peerId, shouldIOffer(peerId))
  })
  renderCallOverlay()
  return Promise.resolve()
}

function createPeerConnection(peerId, isOfferer) {
  const existing = state.call.peers[peerId]
  if (existing && existing.pc) return existing.pc
  const pc = new RTCPeerConnection(ICE_SERVERS)
  const peerEntry = {
    pc, stream: new MediaStream(), userId: peerId,
    muted: false, isOfferer: !!isOfferer, makingOffer: false
  }
  state.call.peers[peerId] = peerEntry
  if (state.call.localStream) {
    state.call.localStream.getTracks().forEach(t => pc.addTrack(t, state.call.localStream))
  }
  pc.onicecandidate = (e) => {
    if (e.candidate && state.call) {
      sb.from('call_signals').insert({
        call_id: state.call.id, from_user: state.session.user.id,
        to_user: peerId, kind: 'ice', payload: e.candidate.toJSON()
      }).then(({ error }) => { if (error) console.error(error) })
    }
  }
  pc.ontrack = (e) => {
    e.streams[0].getTracks().forEach(t => {
      if (!peerEntry.stream.getTracks().find(x => x.id === t.id)) peerEntry.stream.addTrack(t)
    })
    renderCallOverlay()
  }
  pc.onconnectionstatechange = () => {
    if (pc.connectionState === 'failed' || pc.connectionState === 'disconnected') {
      console.warn('[PitchTalk] peer connection', peerId, 'state:', pc.connectionState)
    }
  }
  if (isOfferer) {
    setTimeout(async () => {
      try {
        if (peerEntry.makingOffer) return
        peerEntry.makingOffer = true
        const offer = await pc.createOffer()
        await pc.setLocalDescription(offer)
        const { error } = await sb.from('call_signals').insert({
          call_id: state.call.id, from_user: state.session.user.id,
          to_user: peerId, kind: 'offer',
          payload: { sdp: pc.localDescription.sdp, type: pc.localDescription.type }
        })
        if (error) console.error(error)
      } catch (e) {
        console.error(e)
      } finally {
        peerEntry.makingOffer = false
      }
    }, 500)
  }
  return pc
}

function subscribeCallSignals(callId) {
  if (callChannel) {
    try { sb.removeChannel(callChannel) } catch (e) {}
  }
  callChannel = sb.channel(`call-signals-${callId}`)
    .on('postgres_changes',
      { event: 'INSERT', schema: 'public', table: 'call_signals', filter: `call_id=eq.${callId}` },
      async (payload) => {
        const sig = payload.new
        if (!sig || sig.to_user !== state.session.user.id || !state.call) return
        const fromId = sig.from_user
        let peer = state.call.peers[fromId]
        if (!peer && sig.kind === 'offer') {
          const pc = createPeerConnection(fromId, false)
          peer = state.call.peers[fromId]
          if (!peer) {
            peer = { pc, stream: new MediaStream(), userId: fromId, muted: false, isOfferer: false }
            state.call.peers[fromId] = peer
          }
        }
        if (!peer) return
        try {
          if (sig.kind === 'offer') {
            await peer.pc.setRemoteDescription(new RTCSessionDescription(sig.payload))
            const ans = await peer.pc.createAnswer()
            await peer.pc.setLocalDescription(ans)
            const { error } = await sb.from('call_signals').insert({
              call_id: state.call.id, from_user: state.session.user.id,
              to_user: fromId, kind: 'answer',
              payload: { sdp: peer.pc.localDescription.sdp, type: peer.pc.localDescription.type }
            })
            if (error) console.error(error)
          } else if (sig.kind === 'answer') {
            await peer.pc.setRemoteDescription(new RTCSessionDescription(sig.payload))
          } else if (sig.kind === 'ice') {
            await peer.pc.addIceCandidate(new RTCIceCandidate(sig.payload))
          }
        } catch (e) { console.error(e) }
      }).subscribe()
}

function attachLocalVideo() {
  const v = document.getElementById('call-local-video')
  if (v && state.call && state.call.localStream) {
    v.srcObject = state.call.localStream
    v.play().catch(() => {})
  }
}

export function renderCallOverlay() {
  if (!state.call) return
  document.getElementById('call-overlay')?.remove()
  const myId = state.session.user.id
  const isIncoming = state.call.incoming
  const isVideo = state.call.kind === 'video'
  const peerIds = Object.keys(state.call.peers || {})
  const tileCount = 1 + peerIds.length
  const gridClass = tileCount <= 1 ? 'g1' : tileCount === 2 ? 'g2' : tileCount === 3 ? 'g3' : 'g4'

  let tilesHTML = `<div class="call-tile">
    ${isVideo && !state.call.camOff
      ? `<video id="call-local-video" autoplay muted playsinline></video>`
      : `<div class="tile-fallback">${avatarHTML(state.profile.display_name||state.profile.username, state.profile.avatar_url, 'xl')}</div>`}
    <div class="tile-label">You ${state.call.muted ? '🔇' : ''}</div>
  </div>`
  peerIds.forEach(pid => {
    const name = getPeerLabel(pid), av = getPeerAvatar(pid)
    tilesHTML += `<div class="call-tile" data-peer="${pid}">
      <video class="peer-video" data-peer="${pid}" autoplay playsinline></video>
      <div class="tile-fallback" data-fallback="${pid}">${avatarHTML(name, av, 'xl')}</div>
      <div class="tile-label">${escapeHtml(name)}</div>
    </div>`
  })

  let title = '', subtitle = ''
  if (isIncoming) {
    title = state.call.isGroup
      ? `${state.call.group?.name || 'Group'} call`
      : `${state.call.caller?.display_name || state.call.caller?.username || 'Someone'} is calling`
    subtitle = state.call.kind === 'video' ? 'Incoming video call…' : 'Incoming audio call…'
  } else {
    title = state.call.isGroup
      ? (state.call.group?.name || 'Group call')
      : getPeerLabel(state.call.callerId === myId ? state.call.calleeId : state.call.callerId)
    subtitle = state.call.status === 'ringing'
      ? 'Ringing…'
      : (state.call.kind === 'video' ? 'Video call' : 'Audio call')
  }

  const incomingName = state.call.isGroup
    ? (state.call.group?.name || 'Group')
    : (state.call.caller?.display_name || state.call.caller?.username || 'Unknown caller')
  const incomingAvatar = state.call.isGroup ? null : state.call.caller?.avatar_url

  const showTimer = !isIncoming && state.call.status === 'accepted' && state.call.startedAt
  const initialTimerText = showTimer ? formatDuration((Date.now() - state.call.startedAt) / 1000) : '0:00'

  const overlay = document.createElement('div')
  overlay.id = 'call-overlay'
  overlay.className = 'call-overlay'
  overlay.innerHTML = `
    <div class="call-top">
      <p class="call-name">${escapeHtml(title)}</p>
      <p class="call-status ${state.call.status === 'ringing' ? 'ringing' : ''}">${escapeHtml(subtitle)}</p>
      <p class="call-timer ${showTimer ? '' : 'hidden'}" id="call-timer">${initialTimerText}</p>
    </div>
    ${isIncoming
      ? `<div class="call-avatar">${avatarHTML(incomingName, incomingAvatar, 'xl')}</div>
         <div class="incoming-actions">
           <button class="call-ctrl end" id="call-decline" title="Decline">${ICONS.end}</button>
           <button class="call-ctrl active" id="call-accept" title="Accept">${ICONS.phone}</button>
         </div>`
      : `<div class="call-grid ${gridClass}">${tilesHTML}</div>
         <div class="call-controls">
           <button class="call-ctrl ${state.call.muted ? 'active' : ''}" id="call-mute">${state.call.muted ? ICONS.micOff : ICONS.micOn}</button>
           ${state.call.kind === 'video' ? `<button class="call-ctrl ${state.call.camOff ? 'active' : ''}" id="call-cam">${state.call.camOff ? ICONS.camOff : ICONS.camOn}</button>` : ''}
           <button class="call-ctrl end" id="call-end">${ICONS.end}</button>
         </div>`}`
  document.body.appendChild(overlay)

  document.getElementById('call-accept')?.addEventListener('click', acceptIncomingCall)
  document.getElementById('call-decline')?.addEventListener('click', declineIncomingCall)
  document.getElementById('call-end')?.addEventListener('click', () => endCall(true))
  document.getElementById('call-mute')?.addEventListener('click', (e) => {
    state.call.muted = !state.call.muted
    state.call.localStream?.getAudioTracks().forEach(t => t.enabled = !state.call.muted)
    const btn = e.currentTarget
    btn.classList.toggle('active', state.call.muted)
    btn.innerHTML = state.call.muted ? ICONS.micOff : ICONS.micOn
  })
  document.getElementById('call-cam')?.addEventListener('click', (e) => {
    state.call.camOff = !state.call.camOff
    state.call.localStream?.getVideoTracks().forEach(t => t.enabled = !state.call.camOff)
    const btn = e.currentTarget
    btn.classList.toggle('active', state.call.camOff)
    btn.innerHTML = state.call.camOff ? ICONS.camOff : ICONS.camOn
    const localTile = document.querySelector('.call-tile:first-child')
    if (localTile) {
      const existingVideo = localTile.querySelector('#call-local-video')
      const existingFallback = localTile.querySelector('.tile-fallback')
      if (state.call.camOff && existingVideo) {
        existingVideo.remove()
        if (!existingFallback) {
          localTile.insertAdjacentHTML('afterbegin',
            `<div class="tile-fallback">${avatarHTML(state.profile.display_name||state.profile.username, state.profile.avatar_url, 'xl')}</div>`)
        }
      } else if (!state.call.camOff && !existingVideo) {
        existingFallback?.remove()
        localTile.insertAdjacentHTML('afterbegin',
          `<video id="call-local-video" autoplay muted playsinline></video>`)
        attachLocalVideo()
      }
    }
  })
  requestAnimationFrame(() => {
    attachLocalVideo()
    peerIds.forEach(pid => {
      const p = state.call.peers[pid]
      const v = document.querySelector(`video[data-peer="${pid}"]`)
      if (v && p.stream) {
        v.srcObject = p.stream
        v.play().catch(() => {})
        if (p.stream.getVideoTracks().length > 0) {
          document.querySelector(`[data-fallback="${pid}"]`)?.style.setProperty('display', 'none')
        }
      }
    })
  })
  if (showTimer) startCallTimer()
}

async function postCallSummary(opts = {}) {
  const call = state.call
  if (!call || call.endedPosted) return
  const myId = state.session.user.id
  const amCaller = myId === call.callerId
  const amCallee = !amCaller && !!call.calleeId && myId === call.calleeId

  if (call.isGroup && call.group) {
    call.endedPosted = true
    const duration = call.startedAt ? Math.floor((Date.now() - call.startedAt) / 1000) : 0
    const info = {
      kind: call.kind, duration,
      missed: !!opts.missed, outgoing: !!amCaller,
      caller_id: call.callerId, group: true
    }
    const row = buildCallRow({ info, isGroup: true, groupId: call.group.id })
    try {
      const { data, error } = await sb.from('messages').insert(row).select().single()
      if (error) console.warn(error)
      else if (state.activeChat && state.activeChat.type === 'group' && state.activeChat.group.id === call.group.id) {
        window.__pitchtalk_appendMessage(normalizeMessage(data), { silent: true })
      }
    } catch (e) { console.warn(e) }
    return
  }

  const callerPostingMissed = amCaller && !!opts.missed
  if (!amCallee && !callerPostingMissed) { call.endedPosted = true; return }
  call.endedPosted = true
  const duration = call.startedAt ? Math.floor((Date.now() - call.startedAt) / 1000) : 0
  const recipientId = amCallee ? call.callerId : call.calleeId
  if (!recipientId) return
  const info = {
    kind: call.kind, duration,
    missed: !!opts.missed, outgoing: false,
    caller_id: call.callerId
  }
  const row = buildCallRow({ info, isGroup: false, recipientId })
  try {
    const { data, error } = await sb.from('messages').insert(row).select().single()
    if (error) console.warn(error)
    else if (state.activeChat && state.activeChat.type === 'dm' && state.activeChat.user.id === recipientId) {
      window.__pitchtalk_appendMessage(normalizeMessage(data), { silent: true })
    }
  } catch (e) { console.warn(e) }
}

export async function endCall(notifyOthers = true, fromRemote = false) {
  if (!state.call) return
  stopAllSounds()
  stopCallTimer()
  if (outgoingRingTimeout) { clearTimeout(outgoingRingTimeout); outgoingRingTimeout = null }
  const callId = state.call.id
  const wasConnected = !!state.call.startedAt
  const myId = state.session.user.id
  const amCaller = myId === state.call.callerId

  if (!state.call.endedPosted) {
    if (wasConnected) {
      if (!amCaller) await postCallSummary({ missed: false })
      else state.call.endedPosted = true
    } else {
      if (amCaller) await postCallSummary({ missed: true })
      else state.call.endedPosted = true
    }
  }

  document.getElementById('call-overlay')?.remove()
  try {
    if (notifyOthers && !fromRemote) {
      await sb.from('calls').update({ status: 'ended' }).eq('id', callId)
    }
  } catch (e) {}
  playSound('drop', 'drop', false)
  cleanupCall()
}

export async function cleanupCall() {
  stopCallTimer()
  if (state.call) {
    try { state.call.localStream?.getTracks().forEach(t => t.stop()) } catch (e) {}
    Object.values(state.call.peers || {}).forEach(p => {
      try { p.pc.close() } catch (e) {}
    })
    state.call.peers = {}
  }
  if (callChannel) { try { await sb.removeChannel(callChannel) } catch (e) {} callChannel = null }
  if (callStatusChannel) { try { await sb.removeChannel(callStatusChannel) } catch (e) {} callStatusChannel = null }
  if (readyChannel) { try { await sb.removeChannel(readyChannel) } catch (e) {} readyChannel = null }
  if (outgoingRingTimeout) { clearTimeout(outgoingRingTimeout); outgoingRingTimeout = null }
  if (myLocalStream) {
    try { myLocalStream.getTracks().forEach(t => t.stop()) } catch (e) {}
    myLocalStream = null
  }
  state.call = null
  document.getElementById('call-overlay')?.remove()
}