// =========================================================================
// TYPING + READ RECEIPTS
// =========================================================================

import { state, TAB_ID } from './config.js'
import { sb, escapeHtml } from './lib.js'

let typingChannel = null
let typingSweeper = null
let typingBroadcastThrottle = null
let typingStopTimer = null
let lastSentTypingFalse = true
let readsChannel = null
let readHeartbeat = null

// =========================================================================
// CONVERSATION KEY HELPERS
// =========================================================================
export function dmKey(a, b) {
  return `dm-${[a, b].sort().join('-')}`
}

export function groupKey(gid) {
  return `group-${gid}`
}

export function currentConversationKey() {
  if (!state.activeChat || !state.session) return null
  if (state.activeChat.type === 'dm') {
    return dmKey(state.session.user.id, state.activeChat.user.id)
  }
  return groupKey(state.activeChat.group.id)
}

// =========================================================================
// TYPING
// =========================================================================
export async function teardownTypingChannel() {
  if (typingSweeper) { clearInterval(typingSweeper); typingSweeper = null }
  if (typingChannel) {
    try { await sb.removeChannel(typingChannel) } catch (e) {}
    typingChannel = null
  }
  state.typing = {}
}

export function subscribeTyping() {
  teardownTypingChannel().then(() => {
    if (!state.activeChat) return
    const key = currentConversationKey()
    if (!key) return
    typingChannel = sb.channel(`typing-${key}-${TAB_ID}`, {
      config: { broadcast: { self: false, ack: false } }
    })
      .on('broadcast', { event: 'typing' }, (msg) => {
        const uid = msg?.payload?.user_id
        const isTyping = msg?.payload?.typing
        if (!uid || uid === state.session.user.id) return
        if (isTyping) state.typing[uid] = Date.now() + 3500
        else delete state.typing[uid]
        renderTypingIndicator()
      })
      .subscribe((status) => {
        if (status === 'SUBSCRIBED') {
          if (typingSweeper) clearInterval(typingSweeper)
          typingSweeper = setInterval(() => {
            const now = Date.now()
            let changed = false
            Object.keys(state.typing).forEach(uid => {
              if (state.typing[uid] < now) { delete state.typing[uid]; changed = true }
            })
            if (changed) renderTypingIndicator()
          }, 1000)
        }
      })
  })
}

export function broadcastTyping(isTyping) {
  if (!typingChannel) return
  if (isTyping === lastSentTypingFalse && !isTyping) return
  lastSentTypingFalse = !isTyping
  try {
    typingChannel.send({
      type: 'broadcast',
      event: 'typing',
      payload: { user_id: state.session.user.id, typing: !!isTyping }
    })
  } catch (e) {}
}

export function handleComposerTyping() {
  if (typingBroadcastThrottle) return
  broadcastTyping(true)
  typingBroadcastThrottle = setTimeout(() => { typingBroadcastThrottle = null }, 600)
  if (typingStopTimer) clearTimeout(typingStopTimer)
  typingStopTimer = setTimeout(() => {
    typingStopTimer = null
    broadcastTyping(false)
  }, 2200)
}

export function stopComposerTyping() {
  broadcastTyping(false)
  if (typingBroadcastThrottle) { clearTimeout(typingBroadcastThrottle); typingBroadcastThrottle = null }
  if (typingStopTimer) { clearTimeout(typingStopTimer); typingStopTimer = null }
}

function typingNames() {
  const now = Date.now()
  const ids = Object.keys(state.typing).filter(uid => state.typing[uid] > now)
  return ids.map(uid => {
    if (state.activeChat?.type === 'group') {
      const m = state.groupMembers.find(x => x.id === uid)
      return m ? (m.display_name || m.username) : null
    }
    const u = state.activeChat?.user
    return u && u.id === uid ? (u.display_name || u.username) : null
  }).filter(Boolean)
}

export function renderTypingIndicator() {
  const sub = document.getElementById('chat-header-sub')
  if (!sub || !state.activeChat) return
  const names = typingNames()
  if (names.length === 0) {
    if (state.activeChat.type === 'dm') {
      sub.classList.remove('is-typing')
      const online = state.onlineUsers.has(state.activeChat.user.id)
      sub.innerHTML = online ? 'Online' : 'Offline'
    } else {
      sub.classList.remove('is-typing')
      sub.innerHTML = `${state.groupMembers.length} member${state.groupMembers.length === 1 ? '' : 's'}`
    }
    return
  }
  sub.classList.add('is-typing')
  let text = ''
  if (names.length === 1) text = `${names[0]} is typing`
  else if (names.length === 2) text = `${names[0]} and ${names[1]} are typing`
  else if (names.length === 3) text = `${names[0]}, ${names[1]} and ${names[2]} are typing`
  else text = `${names.length} people are typing`
  sub.innerHTML = `${escapeHtml(text)}<span class="typing-dots"><span></span><span></span><span></span></span>`
}

// =========================================================================
// READ RECEIPTS
// =========================================================================
export async function teardownReadsChannel() {
  if (readsChannel) {
    try { await sb.removeChannel(readsChannel) } catch (e) {}
    readsChannel = null
  }
  state.reads = {}
}

export async function loadConversationReads() {
  const key = currentConversationKey()
  if (!key) { state.reads = {}; return }
  try {
    const { data, error } = await sb.from('conversation_reads')
      .select('user_id, last_read_at')
      .eq('conversation_key', key)
    if (error) { console.warn('[PitchTalk] loadConversationReads error:', error); return }
    const fresh = {}
    ;(data || []).forEach(r => { fresh[r.user_id] = new Date(r.last_read_at).getTime() })
    Object.keys(fresh).forEach(uid => {
      const current = state.reads[uid]
      if (!current || fresh[uid] > current) state.reads[uid] = fresh[uid]
    })
  } catch (e) { console.warn(e) }
}

export function subscribeConversationReads() {
  teardownReadsChannel().then(() => {
    const key = currentConversationKey()
    if (!key) return
    readsChannel = sb.channel(`reads-${key}-${TAB_ID}`)
      .on('postgres_changes',
        { event: '*', schema: 'public', table: 'conversation_reads', filter: `conversation_key=eq.${key}` },
        (payload) => {
          const row = payload.new || payload.old
          if (!row) return
          if (payload.eventType === 'DELETE') delete state.reads[row.user_id]
          else state.reads[row.user_id] = new Date(row.last_read_at).getTime()
          window.dispatchEvent(new CustomEvent('pitchtalk:reads-changed'))
        }
      )
      .subscribe()
  })
}

export async function markConversationRead(key) {
  if (!key || !state.session) return
  const now = new Date().toISOString()
  try {
    await sb.from('conversation_reads').upsert(
      { user_id: state.session.user.id, conversation_key: key, last_read_at: now },
      { onConflict: 'user_id,conversation_key' }
    )
    state.reads[state.session.user.id] = new Date(now).getTime()
  } catch (e) {}
}

export function startReadHeartbeat() {
  if (readHeartbeat) clearInterval(readHeartbeat)
  readHeartbeat = setInterval(() => {
    const ck = currentConversationKey()
    if (ck && document.visibilityState === 'visible' && document.hasFocus()) {
      markConversationRead(ck)
    }
  }, 10000)
}

export function stopReadHeartbeat() {
  if (readHeartbeat) { clearInterval(readHeartbeat); readHeartbeat = null }
}

export async function stopTypingAndReads() {
  stopComposerTyping()
  await teardownTypingChannel()
  await teardownReadsChannel()
  state.typing = {}
  state.reads = {}
}