// =========================================================================
// SOCIAL — profiles, DM hides, message hides, join requests, groups
// =========================================================================

import { state, TAB_ID, BOOT_TIMEOUT_MS } from './config.js'
import {
  sb, withTimeout, toastSuccess, toastError, toastInfo,
  formatDay, formatTime, avatarHTML
} from './lib.js'
import {
  buildSystemRow, normalizeMessage, unreadKeyForMessage, cutoffIso
} from './messages.js'

// =========================================================================
// PROFILE
// =========================================================================
export async function loadProfile() {
  const uid = state.session.user.id
  const { data, error } = await withTimeout(
    sb.from('profiles').select('*').eq('id', uid).maybeSingle(),
    BOOT_TIMEOUT_MS, 'loadProfile'
  )
  if (error) console.warn('[PitchTalk] profile select error:', error)
  if (data) { state.profile = data; return data }

  const meta = state.session.user.user_metadata || {}
  const fallbackUsername = (meta.username || (state.session.user.email || '').split('@')[0] || 'user').toLowerCase()
  const fallbackDisplay = (meta.display_name || fallbackUsername).slice(0, 15)
  const insertRes = await withTimeout(
    sb.from('profiles').insert({
      id: uid,
      username: fallbackUsername,
      display_name: fallbackDisplay,
      status_text: 'Available'
    }).select().single(),
    BOOT_TIMEOUT_MS, 'createProfile'
  )
  if (insertRes.error) {
    console.error('Profile row missing:', insertRes.error.message)
    return null
  }
  state.profile = insertRes.data
  return state.profile
}

export async function loadDirectChats() {
  try {
    const myId = state.session.user.id
    const cutoff = cutoffIso()
    const { data, error } = await withTimeout(
      sb.from('messages')
        .select('sender_id, recipient_id, created_at')
        .or(`sender_id.eq.${myId},recipient_id.eq.${myId}`)
        .not('recipient_id', 'is', null)
        .gte('created_at', cutoff)
        .order('created_at', { ascending: false })
        .limit(200),
      BOOT_TIMEOUT_MS, 'loadDirectChats'
    )
    if (error) console.warn(error)
    const seen = new Map()
    for (const r of data || []) {
      const o = r.sender_id === myId ? r.recipient_id : r.sender_id
      if (!seen.has(o)) seen.set(o, r.created_at)
    }
    const ids = [...seen.keys()]
    if (!ids.length) {
      state.directChats = []
      window.dispatchEvent(new CustomEvent('pitchtalk:sidebar-rerender'))
      return
    }
    const { data: profs } = await withTimeout(
      sb.from('profiles').select('*').in('id', ids),
      BOOT_TIMEOUT_MS, 'loadDirectProfiles'
    )
    state.directChats = ids.map(id => profs?.find(p => p.id === id)).filter(Boolean)
    window.dispatchEvent(new CustomEvent('pitchtalk:sidebar-rerender'))
  } catch (err) {
    state.directChats = []
    window.dispatchEvent(new CustomEvent('pitchtalk:sidebar-rerender'))
  }
}

export async function loadGroupChats() {
  try {
    const { data, error } = await withTimeout(
      sb.from('group_members')
        .select('groups:group_id (id, name, description, is_public)')
        .eq('user_id', state.session.user.id),
      BOOT_TIMEOUT_MS, 'loadGroupChats'
    )
    if (error) console.warn(error)
    state.groupChats = (data || []).map(r => r.groups).filter(Boolean)
    window.dispatchEvent(new CustomEvent('pitchtalk:sidebar-rerender'))
    for (const g of state.groupChats) {
      loadPendingRequests(g.id, { silent: true }).then(() => {
        window.dispatchEvent(new CustomEvent('pitchtalk:sidebar-rerender'))
      })
    }
  } catch (err) {
    state.groupChats = []
    window.dispatchEvent(new CustomEvent('pitchtalk:sidebar-rerender'))
  }
}

export async function refreshGroupMembers() {
  if (!state.activeChat || state.activeChat.type !== 'group') return
  try {
    const { data } = await withTimeout(
      sb.from('group_members')
        .select('user_id, role, profiles:user_id (id, username, display_name, avatar_url)')
        .eq('group_id', state.activeChat.group.id),
      BOOT_TIMEOUT_MS, 'refreshGroupMembers'
    )
    state.groupMembers = (data || [])
      .map(r => ({ ...r.profiles, role: r.role }))
      .filter(m => m && m.id)
  } catch (e) {}
}

// =========================================================================
// DM HIDES (delete conversation per-user)
// =========================================================================
let dmHidesChannel = null

export async function loadDmHides() {
  try {
    const myId = state.session.user.id
    const { data, error } = await sb.from('dm_hides')
      .select('other_user_id')
      .eq('user_id', myId)
    if (error) {
      console.warn('[PitchTalk] loadDmHides error:', error)
      return
    }
    state.hiddenDms = new Set((data || []).map(r => r.other_user_id))
  } catch (e) {
    console.warn('[PitchTalk] loadDmHides failed:', e)
    state.hiddenDms = new Set()
  }
}

export function subscribeDmHides() {
  if (dmHidesChannel) return
  dmHidesChannel = sb.channel('dm-hides-global-' + TAB_ID)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'dm_hides' }, (payload) => {
      const row = payload.new || payload.old
      if (!row) return
      const myId = state.session.user.id
      if (row.user_id !== myId) return
      if (payload.eventType === 'DELETE') state.hiddenDms.delete(row.other_user_id)
      else state.hiddenDms.add(row.other_user_id)
      window.dispatchEvent(new CustomEvent('pitchtalk:sidebar-rerender'))
    })
    .subscribe()
}

export async function teardownDmHides() {
  if (dmHidesChannel) {
    try { await sb.removeChannel(dmHidesChannel) } catch (e) {}
    dmHidesChannel = null
  }
}

export async function hideDmConversation(otherUserId) {
  const myId = state.session.user.id
  try {
    const { error } = await sb.from('dm_hides').upsert(
      { user_id: myId, other_user_id: otherUserId, hidden_at: new Date().toISOString() },
      { onConflict: 'user_id,other_user_id' }
    )
    if (error) throw error
    state.hiddenDms.add(otherUserId)
    if (state.activeChat?.type === 'dm' && state.activeChat.user.id === otherUserId) {
      state.activeChat = null
      window.dispatchEvent(new CustomEvent('pitchtalk:clear-active-chat'))
    }
    window.dispatchEvent(new CustomEvent('pitchtalk:sidebar-rerender'))
    const other = state.directChats.find(u => u.id === otherUserId)
    const name = other?.display_name || other?.username || 'the conversation'
    toastSuccess(`Deleted conversation with ${name}`)
  } catch (err) {
    toastError('Could not delete conversation: ' + err.message)
  }
}

// =========================================================================
// MESSAGE HIDES (delete-on-sight per-user)
// =========================================================================
let messageHidesChannel = null

export async function loadMessageHides() {
  if (!state.session) return
  try {
    const { data, error } = await sb.from('message_hides')
      .select('message_id')
      .eq('user_id', state.session.user.id)
    if (error) {
      console.warn('[PitchTalk] loadMessageHides error:', error)
      return
    }
    state.hiddenMessages = new Set((data || []).map(r => r.message_id))
  } catch (e) {
    console.warn('[PitchTalk] loadMessageHides failed:', e)
    state.hiddenMessages = new Set()
  }
}

export function subscribeMessageHides() {
  if (messageHidesChannel) return
  messageHidesChannel = sb.channel('message-hides-mine-' + TAB_ID)
    .on('postgres_changes',
      { event: '*', schema: 'public', table: 'message_hides', filter: `user_id=eq.${state.session.user.id}` },
      (payload) => {
        const row = payload.new || payload.old
        if (!row) return
        if (payload.eventType === 'DELETE') state.hiddenMessages.delete(row.message_id)
        else {
          state.hiddenMessages.add(row.message_id)
          const c = document.getElementById('chat-messages')
          const el = c?.querySelector(`[data-msg-id="${row.message_id}"]`)
          if (el) {
            el.classList.add('msg-expiring')
            setTimeout(() => {
              el.remove()
              window.__pitchtalk_renderedIds?.delete(row.message_id)
              window.__pitchtalk_msgCache?.delete(row.message_id)
            }, 620)
          }
        }
      })
    .subscribe()
}

export async function teardownMessageHides() {
  if (messageHidesChannel) {
    try { await sb.removeChannel(messageHidesChannel) } catch (e) {}
    messageHidesChannel = null
  }
}

// =========================================================================
// JOIN REQUESTS
// =========================================================================
let joinReqGlobalChannel = null

export function subscribeJoinRequestsGlobal() {
  if (joinReqGlobalChannel) return
  joinReqGlobalChannel = sb.channel('join-requests-global-' + TAB_ID)
    .on('postgres_changes',
      { event: '*', schema: 'public', table: 'group_join_requests' },
      async (payload) => {
        const row = payload.new || payload.old
        if (!row) return
        const myId = state.session.user.id
        const myGroupIds = state.groupChats.map(g => g.id)
        const inMyGroup = myGroupIds.includes(row.group_id)

        if (row.user_id === myId) {
          if (payload.eventType === 'DELETE') delete state.myPendingReqStatus[row.group_id]
          else state.myPendingReqStatus[row.group_id] = row.status
          return
        }

        if (inMyGroup) {
          await loadPendingRequests(row.group_id, { silent: true })
          window.dispatchEvent(new CustomEvent('pitchtalk:sidebar-rerender'))
          if (document.getElementById('gi-members-list')) {
            window.dispatchEvent(new CustomEvent('pitchtalk:render-pending-requests', {
              detail: { groupId: row.group_id }
            }))
          }
        }
      })
    .subscribe()
}

export async function teardownJoinRequests() {
  if (joinReqGlobalChannel) {
    try { await sb.removeChannel(joinReqGlobalChannel) } catch (e) {}
    joinReqGlobalChannel = null
  }
}

export async function loadPendingRequests(groupId, { silent = false } = {}) {
  try {
    const { data: reqs, error } = await sb.from('group_join_requests')
      .select('id, user_id, status, created_at')
      .eq('group_id', groupId)
      .eq('status', 'pending')
      .order('created_at', { ascending: true })
    if (error) throw error
    const ids = (reqs || []).map(r => r.user_id)
    let profMap = {}
    if (ids.length) {
      const { data: profs } = await sb.from('profiles')
        .select('id, username, display_name, avatar_url')
        .in('id', ids)
      profMap = Object.fromEntries((profs || []).map(p => [p.id, p]))
    }
    state.pendingRequests[groupId] = (reqs || [])
      .map(r => ({ ...r, profile: profMap[r.user_id] }))
  } catch (e) {
    if (!silent) console.warn('[PitchTalk] loadPendingRequests failed:', e)
    if (!state.pendingRequests[groupId]) state.pendingRequests[groupId] = []
  }
}

export async function loadMyPendingRequests() {
  try {
    const myId = state.session.user.id
    const { data, error } = await sb.from('group_join_requests')
      .select('group_id, status')
      .eq('user_id', myId)
    if (error) throw error
    state.myPendingReqStatus = {}
    ;(data || []).forEach(r => { state.myPendingReqStatus[r.group_id] = r.status })
  } catch (e) {
    console.warn('[PitchTalk] loadMyPendingRequests failed:', e)
  }
}

export async function requestJoinGroup(group) {
  const myId = state.session.user.id
  try {
    const { error } = await sb.from('group_join_requests').insert({
      group_id: group.id, user_id: myId, status: 'pending'
    })
    if (error) {
      if (/duplicate|unique/i.test(error.message)) {
        state.myPendingReqStatus[group.id] = 'pending'
        return
      }
      throw error
    }
    state.myPendingReqStatus[group.id] = 'pending'
    toastSuccess(`Request sent to "${group.name}"`)
  } catch (err) {
    toastError('Could not send request: ' + err.message)
  }
}

export async function approveJoinRequest(requestId, groupId) {
  const myId = state.session.user.id
  const req = (state.pendingRequests[groupId] || []).find(r => r.id === requestId)
  if (!req) return
  const prof = req.profile || { username: 'user', display_name: 'User' }
  const group = state.groupChats.find(g => g.id === groupId)
  const groupName = group?.name || 'the group'
  try {
    const { error: me } = await sb.from('group_members').insert({
      group_id: groupId, user_id: req.user_id, role: 'member'
    })
    if (me && !/duplicate|unique/i.test(me.message)) throw me

    const { error: de } = await sb.from('group_join_requests').delete().eq('id', requestId)
    if (de) throw de

    const sysGroup = buildSystemRow({
      text: `${prof.display_name || prof.username} was added to the group`,
      isGroup: true, groupId
    })
    await sb.from('messages').insert(sysGroup)

    const sysDm = buildSystemRow({
      text: `${prof.display_name || prof.username}'s request to join "${groupName}" was approved`,
      isGroup: false, recipientId: req.user_id, senderId: myId
    })
    await sb.from('messages').insert(sysDm)

    state.pendingRequests[groupId] = (state.pendingRequests[groupId] || [])
      .filter(r => r.id !== requestId)
    window.dispatchEvent(new CustomEvent('pitchtalk:sidebar-rerender'))
    if (document.getElementById('gi-members-list')) {
      window.dispatchEvent(new CustomEvent('pitchtalk:render-pending-requests', {
        detail: { groupId }
      }))
    }
    toastSuccess(`Approved ${prof.display_name || prof.username}`)
  } catch (err) {
    toastError('Approve failed: ' + err.message)
  }
}

export async function denyJoinRequest(requestId, groupId) {
  const myId = state.session.user.id
  const req = (state.pendingRequests[groupId] || []).find(r => r.id === requestId)
  if (!req) return
  const prof = req.profile || { username: 'user', display_name: 'User' }
  const group = state.groupChats.find(g => g.id === groupId)
  const groupName = group?.name || 'the group'
  try {
    const { error: de } = await sb.from('group_join_requests').delete().eq('id', requestId)
    if (de) throw de

    const sysDm = buildSystemRow({
      text: `${prof.display_name || prof.username}'s request to join "${groupName}" was denied`,
      isGroup: false, recipientId: req.user_id, senderId: myId
    })
    await sb.from('messages').insert(sysDm)

    state.pendingRequests[groupId] = (state.pendingRequests[groupId] || [])
      .filter(r => r.id !== requestId)
    window.dispatchEvent(new CustomEvent('pitchtalk:sidebar-rerender'))
    if (document.getElementById('gi-members-list')) {
      window.dispatchEvent(new CustomEvent('pitchtalk:render-pending-requests', {
        detail: { groupId }
      }))
    }
    toastInfo(`Denied ${prof.display_name || prof.username}`)
  } catch (err) {
    toastError('Deny failed: ' + err.message)
  }
}

export function pendingCountFor(groupId) {
  return (state.pendingRequests[groupId] || []).length
}

// =========================================================================
// GROUPS REALTIME (DELETE)
// =========================================================================
let groupsRealtimeChannel = null

export function subscribeGroupsRealtime() {
  if (groupsRealtimeChannel) return
  groupsRealtimeChannel = sb.channel('groups-realtime-' + TAB_ID)
    .on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'groups' }, (payload) => {
      const gid = payload.old?.id
      if (!gid) return
      const wasIn = state.groupChats.some(g => g.id === gid)
      if (!wasIn) return
      const activeWasThis = state.activeChat?.type === 'group' && state.activeChat.group.id === gid
      state.groupChats = state.groupChats.filter(g => g.id !== gid)
      delete state.pendingRequests[gid]
      if (activeWasThis) {
        state.activeChat = null
        window.dispatchEvent(new CustomEvent('pitchtalk:clear-active-chat'))
      }
      window.dispatchEvent(new CustomEvent('pitchtalk:sidebar-rerender'))
      toastInfo('A group you were in was deleted')
    })
    .subscribe()
}

export async function teardownGroupsRealtime() {
  if (groupsRealtimeChannel) {
    try { await sb.removeChannel(groupsRealtimeChannel) } catch (e) {}
    groupsRealtimeChannel = null
  }
}