// =========================================================================
// AUTH — renderAuthScreen and sign in/up flow
// =========================================================================

import { state, BOOT_TIMEOUT_MS } from './config.js'
import { sb, withTimeout, escapeHtml } from './lib.js'

let authMode = 'signin'
let authError = ''
let authNotice = ''

export function renderAuthScreen() {
  const root = document.getElementById('root')
  if (!root) return

  root.innerHTML = `
    <div class="auth-wrap">
      <div class="auth-card-outer">
        <div class="auth-brand">
          <div class="auth-brand-row">
            <div class="brand-mark"></div>
            <span class="brand-name font-display">PitchTalk</span>
          </div>
          <p class="auth-tag">Team chat, kept dark and to the point.<br/>Every message clears at midnight.</p>
        </div>
        <div class="auth-card">
          <div class="tabbar">
            <button id="tab-signin" class="${authMode==='signin'?'active':''}">Sign in</button>
            <button id="tab-signup" class="${authMode==='signup'?'active':''}">Create account</button>
          </div>
          <form id="auth-form">
            <div class="field">
              <label>Username</label>
              <input id="f-username" required placeholder="jane_doe" autocomplete="username" />
            </div>
            ${authMode==='signup' ? `
              <div class="field">
                <label>Display name (max 15)</label>
                <input id="f-displayname" maxlength="15" placeholder="Jane Doe" autocomplete="name" />
              </div>` : ''}
            <div class="field">
              <label>Password</label>
              <input id="f-password" required type="password" minlength="6" placeholder="••••••••"
                autocomplete="${authMode==='signup'?'new-password':'current-password'}" />
            </div>
            ${authError ? `<p class="msg-error">${escapeHtml(authError)}</p>` : ''}
            ${authNotice ? `<p class="msg-notice">${escapeHtml(authNotice)}</p>` : ''}
            <button type="submit" class="btn-primary" id="auth-submit">
              ${authMode==='signup' ? 'Create account' : 'Sign in'}
            </button>
          </form>
        </div>
      </div>
    </div>`

  document.getElementById('tab-signin').onclick = () => {
    authMode = 'signin'; authError = ''; authNotice = ''
    renderAuthScreen()
  }
  document.getElementById('tab-signup').onclick = () => {
    authMode = 'signup'; authError = ''; authNotice = ''
    renderAuthScreen()
  }

  document.getElementById('f-username')?.addEventListener('input', e => {
    e.target.value = e.target.value.replace(/[^a-zA-Z0-9_]/g, '').toLowerCase()
  })

  document.getElementById('auth-form').addEventListener('submit', async e => {
    e.preventDefault()
    const btn = document.getElementById('auth-submit')
    btn.disabled = true
    btn.textContent = 'Please wait…'
    authError = ''; authNotice = ''

    const username = document.getElementById('f-username').value.trim().toLowerCase()
    const password = document.getElementById('f-password').value

    if (!/^[a-z0-9_]{3,20}$/.test(username)) {
      authError = 'Username must be 3–20 chars: letters, numbers, underscore.'
      renderAuthScreen(); return
    }
    if (password.length < 6) {
      authError = 'Password must be at least 6 characters.'
      renderAuthScreen(); return
    }

    const fakeEmail = `${username}@pitchtalk.local`

    try {
      if (authMode === 'signup') {
        const displayName = (document.getElementById('f-displayname')?.value.trim() || username).slice(0,15)
        const { error } = await withTimeout(
          sb.auth.signUp({
            email: fakeEmail,
            password,
            options: { data: { username, display_name: displayName } }
          }),
          BOOT_TIMEOUT_MS, 'signUp'
        )
        if (error) throw error
        authMode = 'signin'
        authNotice = 'Account created! Please sign in.'
        renderAuthScreen()
        return
      } else {
        const { error } = await withTimeout(
          sb.auth.signInWithPassword({ email: fakeEmail, password }),
          BOOT_TIMEOUT_MS, 'signIn'
        )
        if (error) throw error
      }
    } catch (err) {
      let msg = err.message || 'Something went wrong.'
      if (/invalid login credentials/i.test(msg)) msg = 'Wrong username or password.'
      if (/already registered|already exists|duplicate/i.test(msg)) msg = 'That username is already taken.'
      authError = msg
      renderAuthScreen()
    }
  })
}