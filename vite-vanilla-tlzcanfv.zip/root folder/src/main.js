// =========================================================================
// MAIN — boot, render, auth listener, global hooks
// =========================================================================

import {
  state, BOOT_TIMEOUT_MS, SUPABASE_URL, LAST_CHAT_KEY, UNREAD_KEY_PREFIX,
  schema
} from './config.js'
import {
  sb, withTimeout, escapeHtml, toastInfo, initAudioUnlock,
  ICONS, playSound, stopAllSounds, formatDurationLong
} from './lib.js'
import { renderAuthScreen } from './auth.js'
import {
  initPresence, teardownPresence, installPresenceListeners,
  resetPresenceOfflineFlag, isUserOnline
} from './presence.js'
import {
  extractMentions, renderMessageBody, currentMentionContext
} from './mentions.js'
import {
  currentConversationKey, dmKey, groupKey,
  markConversationRead, stopTypingAndReads,
  stopReadHeartbeat
} from './typing-reads.js'
import {
  loadMessages, loadOlderMessages, loadScheduled,
  fireDueScheduledMessages, startScheduledPoller, stopScheduledPoller,
  subscribeGlobalMessages, teardownGlobalMessages,
  subscribeSidebarRefresh, teardownSidebarRefresh,
  subscribeScheduledRealtime, teardownScheduledRealtime,
  loadPersistedUnread, updateTabTitle,
  reconcileUnreadFromReads, normalizeMessage,
  appendMessage, teardownMessagesChannel,
  renderedMessageIds, messageCache, pendingSends,
  clearLastChat, saveLastChat
} from './messages.js'
import {
  loadProfile, loadDirectChats, loadGroupChats,
  loadDmHides, loadMessageHides, loadMyPendingRequests,
  subscribeDmHides, teardownDmHides,
  subscribeMessageHides, teardownMessageHides,
  subscribeJoinRequestsGlobal, teardownJoinRequests,
  subscribeGroupsRealtime, teardownGroupsRealtime
} from './social.js'
import {
  startCall, acceptIncomingCall, declineIncomingCall,
  endCall, cleanupCall, subscribeIncomingCalls, teardownIncomingCalls
} from './calls.js'
import {
  renderStructured,
  buildSplitBillModal, buildTaskModal, buildMeetingModal,
  buildPollModal, buildWheelModal, buildCapsuleModal, buildLocationModal
} from './structured.js'
import {
  openModal, closeModal, closeAllModals, confirmDialog,
  openUserProfileModal
} from './modals.js'
import {
  renderApp, renderChatPaneEmpty, renderSidebarLists,
  scheduleSidebarRerender, activeKey
} from './sidebar.js'
import {
  mountChatPane, buildMessageNode, wireMessageRow,
  scrollToMessage, refreshSeenMarkers
} from './chat.js'

// =========================================================================
// WINDOW HOOKS (para maiwasan circular imports sa messages.js)
// =========================================================================
window.__pitchtalk_lib = {
  ICONS,
  playSound,
  formatDurationLong,
  formatTime: (iso) => new Date(iso).toLocaleTimeString([], { hour:'2-digit', minute:'2-digit' })
}
window.__pitchtalk_buildMessageNode = buildMessageNode
window.__pitchtalk_wireMessageRow = wireMessageRow
window.__pitchtalk_renderStructured = renderStructured
window.__pitchtalk_appendMessage = appendMessage
window.__pitchtalk_normalize = normalizeMessage
window.__pitchtalk_extractMentions = extractMentions
window.__pitchtalk_renderBody = renderMessageBody
window.__pitchtalk_mentionCtx = currentMentionContext
window.__pitchtalk_markRead = markConversationRead
window.__pitchtalk_confirmDialog = confirmDialog
window.__pitchtalk_openUserProfile = openUserProfileModal
window.__pitchtalk_startCall = startCall
window.__pitchtalk_buildSplitBillModal = buildSplitBillModal
window.__pitchtalk_buildTaskModal = buildTaskModal
window.__pitchtalk_buildMeetingModal = buildMeetingModal
window.__pitchtalk_buildPollModal = buildPollModal
window.__pitchtalk_buildWheelModal = buildWheelModal
window.__pitchtalk_buildCapsuleModal = buildCapsuleModal
window.__pitchtalk_buildLocationModal = buildLocationModal
window.__pitchtalk_formatDurationLong = formatDurationLong
window.__pitchtalk_renderedIds = renderedMessageIds
window.__pitchtalk_msgCache = messageCache
window.__pitchtalk_SUPABASE_URL = SUPABASE_URL

// =========================================================================
// GLOBAL EVENT LISTENERS (from sidebar.js modals.js etc)
// =========================================================================
window.addEventListener('pitchtalk:open-dm', async (e) => {
  const u = e.detail.user
  await openDirectChat(u)
})
window.addEventListener('pitchtalk:open-group', async (e) => {
  const g = e.detail.group
  await openGroupChat(g)
})
window.addEventListener('pitchtalk:remount-chat', async () => {
  await mountChatPane()
})
window.addEventListener('pitchtalk:render-empty', () => {
  state.activeChat = null
  clearLastChat()
  renderChatPaneEmpty()
})
window.addEventListener('pitchtalk:clear-active-chat', () => {
  state.activeChat = null
  clearLastChat()
  renderChatPaneEmpty()
})
window.addEventListener('pitchtalk:rerender-app', () => {
  renderApp()
})
window.addEventListener('pitchtalk:no-messages', () => {
  const c = document.getElementById('chat-messages')
  if (!c) return
  const anyReal = c.querySelector('.msg-row[data-msg-id]:not(.msg-expiring)')
  if (!anyReal && !c.querySelector('.ephemeral-empty')) {
    const div = document.createElement('div')
    div.className = 'ephemeral-empty'
    div.innerHTML = `
      <div class="ee-icon">${ICONS.bomb}</div>
      <h3>Nothing here (yet)</h3>
      <p>Every message clears at midnight. Your conversation is a clean slate.</p>`
    c.appendChild(div)
  }
})

// =========================================================================
// CHAT OPEN
// =========================================================================
async function openDirectChat(u) {
  stopTypingAndReads()
  state.activeChat = { type: 'dm', user: u }
  const key = `dm-${u.id}`
  if (state.unread[key]) {
    delete state.unread[key]
    updateTabTitle()
    window.dispatchEvent(new CustomEvent('pitchtalk:sidebar-rerender'))
  }
  saveLastChat()
  window.dispatchEvent(new CustomEvent('pitchtalk:sidebar-rerender'))
  await mountChatPane()
}

async function openGroupChat(g) {
  stopTypingAndReads()
  state.activeChat = { type: 'group', group: g }
  const key = `group-${g.id}`
  if (state.unread[key]) {
    delete state.unread[key]
    updateTabTitle()
    window.dispatchEvent(new CustomEvent('pitchtalk:sidebar-rerender'))
  }
  saveLastChat()
  window.dispatchEvent(new CustomEvent('pitchtalk:sidebar-rerender'))
  await mountChatPane()
  loadPendingRequests(g.id, { silent: true }).then(() => {
    window.dispatchEvent(new CustomEvent('pitchtalk:sidebar-rerender'))
  })
}

// =========================================================================
// RESTORE LAST CHAT
// =========================================================================
async function tryRestoreLastChat() {
  const key = state.restoreKey
  if (!key) return
  try {
    if (key.startsWith('dm-')) {
      const uid = key.slice(3)
      if (state.hiddenDms.has(uid)) { clearLastChat(); return }
      let user = state.directChats.find(u => u.id === uid)
      if (!user) {
        const { data } = await sb.from('profiles')
          .select('id, username, display_name, avatar_url')
          .eq('id', uid).maybeSingle()
        if (data) { user = data; state.directChats = [user, ...state.directChats] }
      }
      if (user) { await openDirectChat(user); return }
    } else if (key.startsWith('group-')) {
      const gid = key.slice(6)
      const group = state.groupChats.find(g => g.id === gid)
      if (group) { await openGroupChat(group); return }
    }
  } catch (err) {}
  clearLastChat()
}

// =========================================================================
// RENDER
// =========================================================================
async function render() {
  if (!state.session) { renderAuthScreen(); return }
  if (!state.profile) {
    const root = document.getElementById('root')
    if (root) root.innerHTML = '<div class="boot-msg">Setting up your profile…</div>'
    const p = await loadProfile()
    if (!p) return
  }
  renderApp()
  await Promise.all([
    loadGroupChats(),
    loadDirectChats(),
    loadDmHides(),
    loadMessageHides(),
    loadMyPendingRequests()
  ])
  if (state.session) loadPersistedUnread()
  updateTabTitle()
  scheduleSidebarRerender()
  subscribeSidebarRefresh(loadDirectChats)
  if (!state.presenceChannel) await initPresence()
  subscribeIncomingCalls()
  subscribeGlobalMessages()
  subscribeJoinRequestsGlobal()
  subscribeGroupsRealtime()
  subscribeDmHides()
  subscribeMessageHides()
  subscribeScheduledRealtime()
  await reconcileUnreadFromReads()
  await loadScheduled()
  startScheduledPoller()
  if (state.restoreKey && !state.activeChat) await tryRestoreLastChat()
}

// =========================================================================
// AUTH LISTENER
// =========================================================================
function attachAuthListener() {
  sb.auth.onAuthStateChange(async (_e, session) => {
    const prevUserId = state.session?.user?.id
    const had = !!state.session
    state.session = session

    if (!session) {
      closeAllModals()
      state.profile = null
      state.activeChat = null
      state.groupMembers = []
      state.unread = {}
      state.pendingRequests = {}
      state.myPendingReqStatus = {}
      state.hiddenDms = new Set()
      state.hiddenMessages = new Set()
      const wmLayer = document.getElementById('watermark-layer')
      if (wmLayer) wmLayer.innerHTML = ''
      if (window.__wmTimer) { clearInterval(window.__wmTimer); window.__wmTimer = null }
      if (prevUserId) {
        try { localStorage.removeItem(UNREAD_KEY_PREFIX + prevUserId) } catch (e) {}
      }
      try { localStorage.removeItem(LAST_CHAT_KEY) } catch (e) {}
      state.restoreKey = null
      await teardownMessagesChannel()
      renderedMessageIds.clear()
      messageCache.clear()
      pendingSends.clear()
      updateTabTitle()
      stopTypingAndReads()
      stopReadHeartbeat()
      stopScheduledPoller()
      await teardownSidebarRefresh()
      await teardownGlobalMessages()
      await teardownJoinRequests()
      await teardownDmHides()
      await teardownMessageHides()
      await teardownScheduledRealtime()
      await teardownGroupsRealtime()
      await teardownPresence()
      await teardownIncomingCalls()
      await cleanupCall()
      clearLastChat()
      render()
      return
    }
    if (!had) await render()
  })
}

// =========================================================================
// SCHEMA DETECTION
// =========================================================================
async function detectSchema() {
  try {
    const { error } = await sb.from('messages')
      .select('id, message_type, metadata, expires_at').limit(1)
    if (error) {
      console.warn('[PitchTalk] new schema not detected, using legacy prefixes:', error.message)
      schema.hasMessageType = false
      schema.hasMetadata = false
    } else {
      schema.hasMessageType = true
      schema.hasMetadata = true
    }
  } catch (e) {
    schema.hasMessageType = false
    schema.hasMetadata = false
  }
}

// =========================================================================
// FATAL ERROR
// =========================================================================
function showFatal(title, details) {
  const root = document.getElementById('root')
  if (!root) return
  root.innerHTML = `<div class="boot-msg"><div>
    <p class="err" style="font-size:16px;font-weight:600;margin:0 0 8px">${title}</p>
    <p style="margin:0 0 12px">${details}</p>
    <p style="font-size:12px;opacity:.7">Open console (F12) for logs.</p>
  </div></div>`
}

// =========================================================================
// BOOT
// =========================================================================
async function boot() {
  const root = document.getElementById('root')
  if (root) root.innerHTML = '<div class="boot-msg">Loading…</div>'
  try {
    initAudioUnlock()
    installPresenceListeners()
    const { data, error } = await withTimeout(sb.auth.getSession(), BOOT_TIMEOUT_MS, 'getSession')
    if (error) console.warn('[PitchTalk] getSession error:', error)
    state.session = data?.session ?? null
    await detectSchema()
    attachAuthListener()
    await render()
  } catch (err) {
    showFatal('Could not connect to Supabase', `<code>${escapeHtml(err.message)}</code>`)
  }
}

boot()