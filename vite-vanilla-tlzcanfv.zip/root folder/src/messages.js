// =========================================================================
// MESSAGES — load, send, optimistic, pagination, scheduled, realtime
// =========================================================================

import {
  state, TAB_ID, MESSAGE_PAGE_SIZE, BOOT_TIMEOUT_MS,
  LAST_CHAT_KEY, UNREAD_KEY_PREFIX, schema
} from './config.js'
import {
  sb, withTimeout, escapeHtml, debounce,
  toastError, showToast, isAllowedFileType, sanitizeFileName
} from './lib.js'
import { currentConversationKey, dmKey } from './typing-reads.js'

// =========================================================================
// STATE MAPS (module-local)
// =========================================================================
export const renderedMessageIds = new Set()
export const messageCache = new Map()
export const pendingSends = new Map()

let oldestLoadedAt = null
let hasMoreMessages = true
let loadingOlder = false
let lastRenderedDay = null

let messagesChannel = null
let globalMessagesChannel = null
let sidebarChannel = null
let scheduledChannel = null
let rerenderSidebarDebounced = null

// =========================================================================
// TIME HELPERS
// =========================================================================
export function startOfToday() {
  const d = new Date()
  d.setHours(0, 0, 0, 0)
  return d
}

export function startOfTomorrow() {
  const d = startOfToday()
  d.setDate(d.getDate() + 1)
  return d
}

export function isExpired(m) {
  if (!m) return true
  if (m.expires_at) return new Date(m.expires_at).getTime() <= Date.now()
  if (m.created_at) return new Date(m.created_at).getTime() < startOfToday().getTime()
  return false
}

export function cutoffIso() {
  return startOfToday().toISOString()
}

// =========================================================================
// UNREAD
// =========================================================================
export function unreadKeyFor(chat) {
  if (!chat) return null
  return chat.type === 'dm' ? `dm-${chat.user.id}` : `group-${chat.group.id}`
}

export function unreadKeyForMessage(m) {
  if (m.group_id) return `group-${m.group_id}`
  if (m.recipient_id === state.session.user.id) return `dm-${m.sender_id}`
  if (m.sender_id === state.session.user.id) return `dm-${m.recipient_id}`
  return null
}

export function getUnread(k) { return state.unread[k] || 0 }

export function incrementUnread(k) {
  if (!k) return
  state.unread[k] = (state.unread[k] || 0) + 1
  updateTabTitle()
  persistUnread()
}

export function clearUnread(k) {
  if (!k) return
  if (state.unread[k]) {
    delete state.unread[k]
    updateTabTitle()
    persistUnread()
  }
}

export function totalUnread() {
  return Object.values(state.unread).reduce((a,b) => a+b, 0)
}

export function updateTabTitle() {
  const n = totalUnread()
  document.title = n > 0 ? `(${n}) PitchTalk` : 'PitchTalk'
}

export function isChatCurrentlyOpen(k) {
  if (!state.activeChat) return false
  return unreadKeyFor(state.activeChat) === k
}

export function isWindowFocused() {
  return document.visibilityState === 'visible' && document.hasFocus()
}

export function persistUnread() {
  try {
    if (!state.session) return
    const keys = Object.keys(state.unread)
    const payload = { keys, data: {}, ts: Date.now() }
    keys.forEach(k => { payload.data[k] = state.unread[k] })
    localStorage.setItem(UNREAD_KEY_PREFIX + state.session.user.id, JSON.stringify(payload))
  } catch (e) {}
}

export function loadPersistedUnread() {
  try {
    if (!state.session) return
    const raw = localStorage.getItem(UNREAD_KEY_PREFIX + state.session.user.id)
    if (!raw) return
    const parsed = JSON.parse(raw)
    if (!parsed?.data) return
    if (parsed.ts && Date.now() - parsed.ts > 7 * 24 * 3600 * 1000) {
      localStorage.removeItem(UNREAD_KEY_PREFIX + state.session.user.id)
      return
    }
    Object.entries(parsed.data).forEach(([k, v]) => {
      if (typeof v === 'number' && v > 0) state.unread[k] = v
    })
  } catch (e) {}
}

// =========================================================================
// CHAT RESTORE KEY
// =========================================================================
export function saveLastChat() {
  const k = activeKeyLocal()
  if (k) {
    localStorage.setItem(LAST_CHAT_KEY, k)
    state.restoreKey = k
  }
}

export function clearLastChat() {
  localStorage.removeItem(LAST_CHAT_KEY)
  state.restoreKey = null
}

function activeKeyLocal() {
  if (!state.activeChat) return null
  return state.activeChat.type === 'dm'
    ? `dm-${state.activeChat.user.id}`
    : `group-${state.activeChat.group.id}`
}

// =========================================================================
// MESSAGE NORMALIZATION
// =========================================================================
const STRUCTURED_PREFIX = {
  call: '__CALL__',
  bill: '__BILL__',
  task: '__TASK__',
  meeting: '__MEET__',
  poll: '__POLL__',
  wheel: '__WHEEL__',
  capsule: '__CAPSULE__',
  location: '__LOC__',
}

export { STRUCTURED_PREFIX }

export function normalizeMessage(m) {
  if (!m) return m
  let meta = m.metadata
  if (typeof meta === 'string') {
    try { meta = JSON.parse(meta) } catch (e) { meta = null }
  }
  if (m.message_type) return { ...m, metadata: meta }
  if (typeof m.body === 'string') {
    for (const [type, prefix] of Object.entries(STRUCTURED_PREFIX)) {
      if (m.body.startsWith(prefix)) {
        let parsed = null
        try { parsed = JSON.parse(m.body.slice(prefix.length)) } catch (e) { parsed = null }
        return { ...m, message_type: type, metadata: parsed, body: null }
      }
    }
    if (m.body.startsWith('__SYS__')) {
      return { ...m, message_type: 'system', body: m.body.replace('__SYS__', '') }
    }
  }
  return { ...m, message_type: 'text', metadata: meta }
}

// =========================================================================
// MESSAGE ROW BUILDERS
// =========================================================================
export function buildMessageRow({ body, file, isGroup, groupId, recipientId, mentions }) {
  const row = {
    sender_id: state.session.user.id,
    body: body || null,
    ...(isGroup ? { group_id: groupId } : { recipient_id: recipientId })
  }
  if (file) {
    row.file_url = file.url
    row.file_name = file.name
    row.file_size = file.size
    row.file_type = file.type
  }
  if (schema.hasMessageType) row.message_type = 'text'
  if (schema.hasMetadata && mentions && (mentions.all || (mentions.userIds && mentions.userIds.length))) {
    row.metadata = { mentions }
  }
  return row
}

export function buildSystemRow({ text, isGroup, groupId, recipientId, senderId }) {
  const row = {
    sender_id: senderId || state.session.user.id,
    ...(isGroup ? { group_id: groupId } : { recipient_id: recipientId })
  }
  if (schema.hasMessageType) {
    row.message_type = 'system'
    row.body = text
  } else {
    row.body = `__SYS__${text}`
  }
  return row
}

export function buildStructuredRow({ type, info, isGroup, groupId, recipientId }) {
  const row = {
    sender_id: state.session.user.id,
    ...(isGroup ? { group_id: groupId } : { recipient_id: recipientId })
  }
  if (schema.hasMessageType) {
    row.message_type = type
    row.metadata = info
    row.body = null
  } else {
    row.body = `${STRUCTURED_PREFIX[type] || '__SYS__'}${JSON.stringify(info)}`
  }
  return row
}

export function buildCallRow({ info, isGroup, groupId, recipientId }) {
  return buildStructuredRow({ type: 'call', info, isGroup, groupId, recipientId })
}

// =========================================================================
// LOAD MESSAGES
// =========================================================================
function buildMessagesQuery({ before = null, limit = MESSAGE_PAGE_SIZE } = {}) {
  const chat = state.activeChat
  const isGroup = chat.type === 'group'
  const cutoff = cutoffIso()
  let q = sb.from('messages').select('*')
    .gte('created_at', cutoff)
    .order('created_at', { ascending: false })
    .limit(limit)
  if (before) q = q.lt('created_at', before)
  q = isGroup
    ? q.eq('group_id', chat.group.id)
    : q.or(`and(sender_id.eq.${state.session.user.id},recipient_id.eq.${chat.user.id}),and(sender_id.eq.${chat.user.id},recipient_id.eq.${state.session.user.id})`)
  return q
}

export function renderLoadOlderButton() {
  const c = document.getElementById('chat-messages')
  if (!c) return
  const existing = document.getElementById('load-older-wrap')
  if (existing) existing.remove()
  if (!hasMoreMessages) return
  const wrap = document.createElement('div')
  wrap.id = 'load-older-wrap'
  wrap.style.cssText = 'text-align:center;padding:12px 0;'
  wrap.innerHTML = `<button id="load-older-btn" class="btn-soft" style="flex:none;padding:6px 14px;">Load older (today only)</button>`
  c.insertBefore(wrap, c.firstChild)
  document.getElementById('load-older-btn').onclick = loadOlderMessages
}

export async function loadMessages() {
  const c = document.getElementById('chat-messages')
  if (!c) return
  try {
    const { data, error } = await withTimeout(buildMessagesQuery(), BOOT_TIMEOUT_MS, 'loadMessages')
    if (error) console.warn('[PitchTalk] loadMessages error:', error)
    c.innerHTML = ''
    lastRenderedDay = null
    renderedMessageIds.clear()
    messageCache.clear()
    oldestLoadedAt = null
    hasMoreMessages = true

    const rows = (data || []).slice().reverse()
      .filter(m => !isExpired(m))
      .filter(m => !state.hiddenMessages.has(m.id))
    rows.forEach(raw => {
      const m = normalizeMessage(raw)
      appendMessageInternal(m, { scroll: false, silent: true })
    })
    if (rows.length) oldestLoadedAt = rows[0].created_at
    hasMoreMessages = (data || []).length === MESSAGE_PAGE_SIZE
    renderLoadOlderButton()
    c.scrollTop = c.scrollHeight

    if (!rows.length) {
      window.dispatchEvent(new CustomEvent('pitchtalk:no-messages'))
    }
  } catch (err) {
    if (c) c.innerHTML = `<p class="list-empty" style="padding:20px;text-align:center;color:#ff8a52;">Could not load messages: ${escapeHtml(err.message)}</p>`
  }
}

export async function loadOlderMessages() {
  if (loadingOlder || !hasMoreMessages || !oldestLoadedAt || !state.activeChat) return
  loadingOlder = true
  const c = document.getElementById('chat-messages')
  const btn = document.getElementById('load-older-btn')
  if (btn) { btn.disabled = true; btn.textContent = 'Loading…' }

  const prevScrollHeight = c.scrollHeight
  const prevScrollTop = c.scrollTop

  try {
    const { data, error } = await withTimeout(
      buildMessagesQuery({ before: oldestLoadedAt }),
      BOOT_TIMEOUT_MS, 'loadOlderMessages'
    )
    if (error) throw error

    const rows = (data || []).slice().reverse()
      .filter(m => !isExpired(m))
      .filter(m => !state.hiddenMessages.has(m.id))
    if (!rows.length) {
      hasMoreMessages = false
      document.getElementById('load-older-wrap')?.remove()
      return
    }

    const fragment = document.createDocumentFragment()
    let lastDay = null
    rows.forEach(raw => {
      const m = normalizeMessage(raw)
      if (renderedMessageIds.has(m.id)) return
      renderedMessageIds.add(m.id)
      const day = new Date(m.created_at).toDateString()
      if (day !== lastDay) {
        const d = document.createElement('div')
        d.className = 'day-divider'
        d.innerHTML = `<span>${escapeHtml(day)}<span class="dd-ephemeral">· clears at midnight</span></span>`
        fragment.appendChild(d)
        lastDay = day
      }
      const node = window.__pitchtalk_buildMessageNode(m)
      if (node) {
        fragment.appendChild(node)
        window.__pitchtalk_wireMessageRow(node, m)
      }
      messageCache.set(m.id, m)
    })

    if (btn) btn.parentElement.remove()
    c.insertBefore(fragment, c.firstChild)

    oldestLoadedAt = rows[0].created_at
    hasMoreMessages = (data || []).length === MESSAGE_PAGE_SIZE
    renderLoadOlderButton()

    const newScrollHeight = c.scrollHeight
    c.scrollTop = prevScrollTop + (newScrollHeight - prevScrollHeight)
  } catch (err) {
    console.warn('[PitchTalk] loadOlderMessages failed:', err)
    toastError('Could not load older messages')
    if (btn) { btn.disabled = false; btn.textContent = 'Load older (today only)' }
  } finally {
    loadingOlder = false
  }
}

// =========================================================================
// APPEND MESSAGE (delegates to chat.js via window hook)
// =========================================================================
export function appendMessage(m, opts = {}) {
  return appendMessageInternal(m, opts)
}

function appendMessageInternal(m, { scroll = true, silent = false } = {}) {
  const c = document.getElementById('chat-messages')
  if (!c) return
  if (m.id && renderedMessageIds.has(m.id)) return
  if (isExpired(m)) return
  if (state.hiddenMessages.has(m.id)) return
  if (m.id) renderedMessageIds.add(m.id)

  const stick = isNearBottomInternal(c)
  const day = new Date(m.created_at).toDateString()
  const type = m.message_type || 'text'

  let prefixHTML = ''
  if (day !== lastRenderedDay) {
    prefixHTML = `<div class="day-divider"><span>${escapeHtml(day)}<span class="dd-ephemeral">· clears at midnight</span></span></div>`
    lastRenderedDay = day
  }
  if (prefixHTML) c.insertAdjacentHTML('beforeend', prefixHTML)

  if (type === 'call') {
    renderCallSummaryInto(c, m)
    if (scroll && stick) c.scrollTop = c.scrollHeight
    return
  }

  if (type !== 'text' && type !== 'system') {
    const custom = window.__pitchtalk_renderStructured(type, m.metadata || {}, m)
    if (custom) {
      const tmp = document.createElement('div')
      tmp.innerHTML = custom.html
      const node = tmp.firstElementChild
      c.appendChild(node)
      custom.wire?.(node)
      if (scroll && stick) c.scrollTop = c.scrollHeight
      return
    }
  }

  if (type === 'system') {
    c.insertAdjacentHTML('beforeend', `<div class="system-msg msg-in"><span>${escapeHtml(m.body || '')}</span></div>`)
    if (scroll && stick) c.scrollTop = c.scrollHeight
    return
  }

  const node = window.__pitchtalk_buildMessageNode(m)
  if (node) {
    c.appendChild(node)
    window.__pitchtalk_wireMessageRow(node, m)
    if (scroll && stick) c.scrollTop = c.scrollHeight
  }
}

function renderCallSummaryInto(c, m) {
  const info = m.metadata || {}
  const dur = Number(info.duration) || 0
  const isVideo = info.kind === 'video'
  const missed = !!info.missed
  const myId = state.session.user.id
  const iAmCaller = info.caller_id && info.caller_id === myId
  const outgoing = iAmCaller
  const { ICONS, formatTime, formatDurationLong } = window.__pitchtalk_lib
  const iconSvg = isVideo
    ? ICONS.videoCall
    : (missed ? ICONS.phoneMissed : (outgoing ? ICONS.phoneOut : ICONS.phoneIn))
  const label = missed ? 'Missed' : (outgoing ? 'Outgoing' : 'Incoming')
  const kindLabel = isVideo ? 'video call' : 'audio call'
  const durText = missed ? 'No answer' : formatDurationLong(dur)
  c.insertAdjacentHTML('beforeend', `<div class="call-summary-msg msg-in">
    <div class="call-summary-card">
      <div class="call-summary-icon">${iconSvg}</div>
      <p class="call-summary-title">${label} ${kindLabel}</p>
      <p class="call-summary-dur">${escapeHtml(durText)}</p>
      <p class="call-summary-time">${formatTime(m.created_at)}</p>
    </div>
  </div>`)
}

export function isNearBottomInternal(el, threshold = 120) {
  if (!el) return true
  return (el.scrollHeight - el.scrollTop - el.clientHeight) < threshold
}

// =========================================================================
// SEND (optimistic)
// =========================================================================
function makeOptimisticMessage({ body, file }) {
  const chat = state.activeChat, isGroup = chat.type === 'group'
  const tempId = `temp-${Date.now()}-${Math.random().toString(36).slice(2,7)}`
  return {
    id: tempId,
    sender_id: state.session.user.id,
    body: body || null,
    file_url: file ? URL.createObjectURL(file) : null,
    file_name: file ? file.name : null,
    file_size: file ? file.size : null,
    file_type: file ? file.type : null,
    created_at: new Date().toISOString(),
    group_id: isGroup ? chat.group.id : null,
    recipient_id: isGroup ? null : chat.user.id,
    message_type: 'text',
    metadata: null,
    __status: 'sending',
    __tempId: tempId
  }
}

export function appendOptimistic(opt) {
  const c = document.getElementById('chat-messages')
  if (!c) return
  const stick = isNearBottomInternal(c)
  const day = new Date(opt.created_at).toDateString()
  if (day !== lastRenderedDay) {
    c.insertAdjacentHTML('beforeend', `<div class="day-divider"><span>${escapeHtml(day)}<span class="dd-ephemeral">· clears at midnight</span></span></div>`)
    lastRenderedDay = day
  }
  const node = window.__pitchtalk_buildMessageNode(opt, { isOptimistic: true })
  if (node) {
    c.appendChild(node)
    messageCache.set(opt.id, opt)
    window.__pitchtalk_wireMessageRow(node, opt, { isOptimistic: true })
    if (stick) c.scrollTop = c.scrollHeight
  }
}

export function replaceOptimistic(tempId, realMsg) {
  const c = document.getElementById('chat-messages')
  const row = c?.querySelector(`[data-msg-id="${tempId}"]`)
  messageCache.delete(tempId)
  pendingSends.delete(tempId)
  if (row) {
    const stick = isNearBottomInternal(c)
    const newNode = window.__pitchtalk_buildMessageNode(realMsg)
    row.replaceWith(newNode)
    window.__pitchtalk_wireMessageRow(newNode, realMsg)
    messageCache.set(realMsg.id, realMsg)
    renderedMessageIds.add(realMsg.id)
    if (stick) c.scrollTop = c.scrollHeight
  } else {
    appendMessage(realMsg, { silent: true })
  }
}

export function markOptimisticFailed(tempId) {
  const opt = messageCache.get(tempId)
  if (!opt) return
  opt.__status = 'failed'
  const c = document.getElementById('chat-messages')
  const row = c?.querySelector(`[data-msg-id="${tempId}"]`)
  if (row) {
    const newNode = window.__pitchtalk_buildMessageNode(opt, { isOptimistic: true })
    row.replaceWith(newNode)
    window.__pitchtalk_wireMessageRow(newNode, opt, { isOptimistic: true })
  }
}

async function performSend(payload) {
  const { body, file, isGroup, groupId, recipientId, mentions } = payload
  let fileMeta = null
  if (file) {
    if (file.size > 10 * 1024 * 1024) throw new Error('File too large (max 10 MB)')
    if (!isAllowedFileType(file)) {
      throw new Error('File type not allowed. Images, PDFs, docs, audio and video only.')
    }
    const safe = sanitizeFileName(file.name)
    const path = `${state.session.user.id}/${Date.now()}-${safe}`
    const { error: ue } = await withTimeout(
      sb.storage.from('chat-files').upload(path, file, {
        cacheControl: '3600',
        upsert: false,
        contentType: file.type || 'application/octet-stream'
      }),
      BOOT_TIMEOUT_MS, 'uploadFile'
    )
    if (ue) throw ue
    const { data } = sb.storage.from('chat-files').getPublicUrl(path)
    fileMeta = {
      url: data.publicUrl, name: file.name,
      size: file.size, type: file.type || 'application/octet-stream'
    }
  }
  const row = buildMessageRow({ body, file: fileMeta, isGroup, groupId, recipientId, mentions })
  const { data: inserted, error } = await withTimeout(
    sb.from('messages').insert(row).select().single(),
    BOOT_TIMEOUT_MS, 'sendMessage'
  )
  if (error) throw error
  return normalizeMessage(inserted)
}

export async function sendMessage({ body, file }) {
  const chat = state.activeChat, isGroup = chat.type === 'group'
  const mentionInfo = window.__pitchtalk_extractMentions(body)
  const opt = makeOptimisticMessage({ body, file })
  appendOptimistic(opt)
  const payload = {
    body: body || null,
    file: file || null,
    isGroup,
    groupId: isGroup ? chat.group.id : null,
    recipientId: isGroup ? null : chat.user.id,
    mentions: mentionInfo
  }
  pendingSends.set(opt.id, { payload, retries: 0 })
  try {
    const inserted = await performSend(payload)
    if (!inserted) throw new Error('No row returned')
    if (opt.file_url && String(opt.file_url).startsWith('blob:')) {
      try { URL.revokeObjectURL(opt.file_url) } catch (e) {}
    }
    replaceOptimistic(opt.id, inserted)
    const { playSound } = window.__pitchtalk_lib
    playSound('msgSent', 'msgSent', false)
    const ck = currentConversationKey()
    if (ck) window.__pitchtalk_markRead(ck)
  } catch (err) {
    markOptimisticFailed(opt.id)
    console.warn('[PitchTalk] send failed:', err)
  }
}

export async function retryPendingSend(tempId) {
  const entry = pendingSends.get(tempId)
  const opt = messageCache.get(tempId)
  if (!entry || !opt) return
  opt.__status = 'sending'
  const c = document.getElementById('chat-messages')
  const row = c?.querySelector(`[data-msg-id="${tempId}"]`)
  if (row) {
    const newNode = window.__pitchtalk_buildMessageNode(opt, { isOptimistic: true })
    row.replaceWith(newNode)
    window.__pitchtalk_wireMessageRow(newNode, opt, { isOptimistic: true })
  }
  try {
    const inserted = await performSend(entry.payload)
    if (!inserted) throw new Error('No row returned')
    if (opt.file_url && String(opt.file_url).startsWith('blob:')) {
      try { URL.revokeObjectURL(opt.file_url) } catch (e) {}
    }
    replaceOptimistic(tempId, inserted)
    const { playSound } = window.__pitchtalk_lib
    playSound('msgSent', 'msgSent', false)
    const ck = currentConversationKey()
    if (ck) window.__pitchtalk_markRead(ck)
  } catch (err) {
    markOptimisticFailed(tempId)
    console.warn('[PitchTalk] retry failed:', err)
  }
}

// =========================================================================
// REALTIME — per-conversation messages
// =========================================================================
export function subscribeMessages() {
  const chat = state.activeChat, isGroup = chat.type === 'group'
  const base = isGroup
    ? `msgs-group-${chat.group.id}`
    : `msgs-dm-${[state.session.user.id, chat.user.id].sort().join('-')}`
  const name = `${base}-${TAB_ID}`
  messagesChannel = sb.channel(name)
    .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, payload => {
      const m = normalizeMessage(payload.new)
      const rel = isGroup
        ? m.group_id === chat.group.id
        : (m.sender_id === state.session.user.id && m.recipient_id === chat.user.id) ||
          (m.sender_id === chat.user.id && m.recipient_id === state.session.user.id)
      if (!rel) return
      if (isExpired(m)) return
      if (state.hiddenMessages.has(m.id)) return
      if (m.sender_id === state.session.user.id) {
        const stillPending = [...pendingSends.entries()].find(([tid, entry]) => {
          const o = messageCache.get(tid)
          return o && o.body === m.body && o.__status === 'sending'
        })
        if (stillPending) return
      }
      appendMessage(m, { silent: true })
    })
    .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'messages' }, payload => {
      const m = normalizeMessage(payload.new)
      const rel = isGroup
        ? m.group_id === chat.group.id
        : (m.sender_id === state.session.user.id && m.recipient_id === chat.user.id) ||
          (m.sender_id === chat.user.id && m.recipient_id === state.session.user.id)
      if (!rel) return
      if (state.hiddenMessages.has(m.id)) return
      const c = document.getElementById('chat-messages')
      const row = c?.querySelector(`[data-msg-id="${m.id}"]`)
      if (!row) return
      if (m.message_type && m.message_type !== 'text' && m.message_type !== 'system' && m.message_type !== 'call') {
        const custom = window.__pitchtalk_renderStructured(m.message_type, m.metadata || {}, m)
        if (custom) {
          const tmp = document.createElement('div')
          tmp.innerHTML = custom.html
          const newNode = tmp.firstElementChild
          row.replaceWith(newNode)
          custom.wire?.(newNode)
        }
      } else {
        const bubble = row.querySelector(`[data-body="${m.id}"]`)
        if (bubble) {
          if (m.is_deleted) bubble.outerHTML = `<div class="msg-bubble deleted">This message was deleted</div>`
          else bubble.innerHTML = window.__pitchtalk_renderBody(m.body, window.__pitchtalk_mentionCtx())
        }
      }
      const cached = messageCache.get(m.id) || {}
      messageCache.set(m.id, { ...cached, ...m })
    })
    .on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'messages' }, payload => {
      const id = payload.old?.id
      if (!id) return
      handleRemoteMessageDeleted(id)
    })
    .subscribe()
}

export async function teardownMessagesChannel() {
  if (messagesChannel) {
    try { await sb.removeChannel(messagesChannel) } catch (e) {}
    messagesChannel = null
  }
  pendingSends.forEach((entry, tid) => {
    const opt = messageCache.get(tid)
    if (opt?.file_url && String(opt.file_url).startsWith('blob:')) {
      try { URL.revokeObjectURL(opt.file_url) } catch (e) {}
    }
  })
  pendingSends.clear()
}

export function handleRemoteMessageDeleted(msgId) {
  const c = document.getElementById('chat-messages')
  if (!c) return
  const row = c.querySelector(`[data-msg-id="${msgId}"]`)
  if (row) {
    row.classList.add('msg-expiring')
    setTimeout(() => {
      row.remove()
      renderedMessageIds.delete(msgId)
      messageCache.delete(msgId)
    }, 620)
  }
}

// =========================================================================
// REALTIME — global (for sidebar unread)
// =========================================================================
export function subscribeGlobalMessages() {
  if (globalMessagesChannel) return
  globalMessagesChannel = sb.channel('global-messages-' + TAB_ID)
    .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, async (payload) => {
      const raw = payload.new
      if (!raw) return
      const m = normalizeMessage(raw)
      const myId = state.session.user.id
      if (m.sender_id === myId) return
      const isDmForMe = m.recipient_id === myId
      const isGroupForMe = m.group_id && state.groupChats.some(g => g.id === m.group_id)
      if (!isDmForMe && !isGroupForMe) return
      const key = unreadKeyForMessage(m)
      if (!key) return

      if (isDmForMe && state.hiddenDms.has(m.sender_id)) {
        state.hiddenDms.delete(m.sender_id)
        sb.from('dm_hides').delete()
          .eq('user_id', myId).eq('other_user_id', m.sender_id)
          .then(() => {})
        if (!state.directChats.some(u => u.id === m.sender_id)) {
          const { data: prof } = await sb.from('profiles')
            .select('id, username, display_name, avatar_url')
            .eq('id', m.sender_id).maybeSingle()
          if (prof) state.directChats = [prof, ...state.directChats]
        }
        window.dispatchEvent(new CustomEvent('pitchtalk:sidebar-rerender'))
      }

      const chatOpen = isChatCurrentlyOpen(key)
      const focused = isWindowFocused()
      const isCallSummary = m.message_type === 'call'
      if (!(chatOpen && focused)) {
        if (!isCallSummary) incrementUnread(key)
        if (isDmForMe && !state.directChats.some(u => u.id === m.sender_id)) {
          const { data: prof } = await sb.from('profiles')
            .select('id, username, display_name, avatar_url')
            .eq('id', m.sender_id).maybeSingle()
          if (prof) state.directChats = [prof, ...state.directChats]
        }
        window.dispatchEvent(new CustomEvent('pitchtalk:sidebar-rerender'))
        if (!isCallSummary) {
          const { playSound } = window.__pitchtalk_lib
          playSound('msgReceived', 'msgReceived', false)
        }
      }
      if (chatOpen) window.__pitchtalk_markRead(key)
    })
    .on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'messages' }, (payload) => {
      const id = payload.old?.id
      if (!id) return
      handleRemoteMessageDeleted(id)
    })
    .subscribe()
}

export async function teardownGlobalMessages() {
  if (globalMessagesChannel) {
    try { await sb.removeChannel(globalMessagesChannel) } catch (e) {}
    globalMessagesChannel = null
  }
}

// =========================================================================
// SIDEBAR REFRESH
// =========================================================================
export function subscribeSidebarRefresh(onRefresh) {
  if (sidebarChannel) return
  const debounced = debounce(onRefresh, 500)
  sidebarChannel = sb.channel('sidebar-refresh-' + TAB_ID)
    .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, () => {
      debounced()
    })
    .subscribe()
}

export async function teardownSidebarRefresh() {
  if (sidebarChannel) {
    try { await sb.removeChannel(sidebarChannel) } catch (e) {}
    sidebarChannel = null
  }
}

// =========================================================================
// SCHEDULED MESSAGES
// =========================================================================
export async function loadScheduled() {
  if (!state.session) return
  try {
    const { data, error } = await sb.from('scheduled_messages')
      .select('*')
      .eq('sender_id', state.session.user.id)
      .eq('is_sent', false)
      .order('send_at', { ascending: true })
    if (error) throw error
    state.scheduled = data || []
    window.dispatchEvent(new CustomEvent('pitchtalk:scheduled-changed'))
  } catch (e) {
    state.scheduled = []
  }
}

export async function fireDueScheduledMessages() {
  if (!state.session) return
  const now = new Date().toISOString()
  try {
    const { data: due, error } = await sb.from('scheduled_messages')
      .select('*')
      .eq('sender_id', state.session.user.id)
      .eq('is_sent', false)
      .lte('send_at', now)
      .limit(20)
    if (error) throw error
    if (!due || !due.length) return
    for (const s of due) {
      try {
        const isGroup = !!s.group_id
        const row = {
          sender_id: s.sender_id,
          body: s.body || null,
          ...(isGroup ? { group_id: s.group_id } : { recipient_id: s.recipient_id })
        }
        if (schema.hasMessageType) row.message_type = 'text'
        const { data: inserted, error: ie } = await sb.from('messages').insert(row).select().single()
        if (ie) throw ie
        await sb.from('scheduled_messages').update({ is_sent: true, sent_message_id: inserted.id }).eq('id', s.id)
        const isThisOpen =
          (state.activeChat?.type === 'group' && state.activeChat.group.id === s.group_id) ||
          (state.activeChat?.type === 'dm' && state.activeChat.user.id === s.recipient_id)
        if (isThisOpen) {
          appendMessage(normalizeMessage(inserted), { silent: true })
        }
      } catch (e) {
        console.warn('[PitchTalk] scheduled fire failed for', s.id, e)
      }
    }
    await loadScheduled()
  } catch (e) {
    console.warn('[PitchTalk] fireDueScheduledMessages failed:', e)
  }
}

export function startScheduledPoller() {
  if (state.scheduledPollTimer) return
  state.scheduledPollTimer = setInterval(fireDueScheduledMessages, 30000)
  setTimeout(fireDueScheduledMessages, 3000)
}

export function stopScheduledPoller() {
  if (state.scheduledPollTimer) {
    clearInterval(state.scheduledPollTimer)
    state.scheduledPollTimer = null
  }
}

export function subscribeScheduledRealtime() {
  if (scheduledChannel || !state.session) return
  scheduledChannel = sb.channel('scheduled-mine-' + TAB_ID)
    .on('postgres_changes',
      { event: '*', schema: 'public', table: 'scheduled_messages', filter: `sender_id=eq.${state.session.user.id}` },
      async () => {
        await loadScheduled()
        if (document.getElementById('modal-overlay') &&
            document.getElementById('modal-title')?.textContent === 'Scheduled messages') {
          window.dispatchEvent(new CustomEvent('pitchtalk:rebuild-scheduled-modal'))
        }
      })
    .subscribe()
}

export async function teardownScheduledRealtime() {
  if (scheduledChannel) {
    try { await sb.removeChannel(scheduledChannel) } catch (e) {}
    scheduledChannel = null
  }
}

// =========================================================================
// UNREAD RECONCILE
// =========================================================================
export async function reconcileUnreadFromReads() {
  const myId = state.session.user.id
  try {
    const cutoff = cutoffIso()
    const { data: reads } = await sb.from('conversation_reads')
      .select('conversation_key, last_read_at')
      .eq('user_id', myId)
    const readsMap = Object.fromEntries(
      (reads || []).map(r => [r.conversation_key, new Date(r.last_read_at).getTime()])
    )

    const fresh = {}

    const { data: dmRows } = await sb.from('messages')
      .select('sender_id, created_at')
      .eq('recipient_id', myId)
      .eq('is_deleted', false)
      .gte('created_at', cutoff)
      .order('created_at', { ascending: false })
      .limit(500)

    ;(dmRows || []).forEach(m => {
      const key = `dm-${m.sender_id}`
      const lastRead = readsMap[key] || 0
      if (new Date(m.created_at).getTime() > lastRead) {
        fresh[key] = (fresh[key] || 0) + 1
      }
    })

    const groupIds = state.groupChats.map(g => g.id)
    if (groupIds.length) {
      const { data: grpRows } = await sb.from('messages')
        .select('group_id, created_at, sender_id')
        .in('group_id', groupIds)
        .neq('sender_id', myId)
        .eq('is_deleted', false)
        .gte('created_at', cutoff)
        .order('created_at', { ascending: false })
        .limit(1000)
      ;(grpRows || []).forEach(m => {
        const key = `group-${m.group_id}`
        const lastRead = readsMap[key] || 0
        if (new Date(m.created_at).getTime() > lastRead) {
          fresh[key] = (fresh[key] || 0) + 1
        }
      })
    }

    Object.entries(state.unread).forEach(([k, v]) => {
      if (!fresh[k] && v > 0) fresh[k] = v
    })

    state.unread = fresh
    persistUnread()
    updateTabTitle()
    window.dispatchEvent(new CustomEvent('pitchtalk:sidebar-rerender'))
  } catch (e) {
    console.warn('[PitchTalk] reconcileUnreadFromReads failed:', e)
  }
}