// =========================================================================
// CONFIG — constants, state, theme
// =========================================================================

export const SUPABASE_URL = 'https://cdrvltvzirabnetaauiz.supabase.co'
export const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNkcnZsdHZ6aXJhYm5ldGFhdWl6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODkyODM5ODIsImV4cCI6MjEwNDg1OTk4Mn0.8YJGcsuc3TuVyx9eAQtrVfvTkgfo31wWghlOi1SOkfg'

export const BOOT_TIMEOUT_MS = 8000
export const MAX_MESSAGE_LENGTH = 4000
export const LANG_KEY = 'pitchtalk:translateTo'
export const THEME_KEY = 'pitchtalk:theme'
export const LAST_CHAT_KEY = 'pitchtalk:lastChat'
export const UNREAD_KEY_PREFIX = 'pitchtalk:unread:'
export const MESSAGE_PAGE_SIZE = 50

export const CURRENCIES = [
  ['PHP','₱'],['USD','$'],['EUR','€'],['GBP','£'],
  ['JPY','¥'],['SGD','S$'],['AUD','A$']
]

export const LANGUAGES = [
  ['en','English'],['tl','Tagalog'],['es','Spanish'],['fr','French'],
  ['de','German'],['ja','Japanese'],['ko','Korean'],
  ['zh','Chinese (Simplified)'],['ar','Arabic'],['hi','Hindi'],
  ['pt','Portuguese'],['ru','Russian'],['id','Indonesian'],['vi','Vietnamese']
]

export const ICE_SERVERS = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' }
  ]
}

// Per-tab ID so multiple tabs don't collide on realtime channel names
export const TAB_ID = Math.random().toString(36).slice(2, 10)

// Schema detection (will be filled at boot)
export const schema = {
  hasMessageType: null,
  hasMetadata: null
}

// Application state
export const state = {
  session: null,
  profile: null,
  directChats: [],
  groupChats: [],
  activeChat: null,
  groupMembers: [],
  presenceChannel: null,
  onlineUsers: new Set(),
  call: null,
  unread: {},
  restoreKey: localStorage.getItem(LAST_CHAT_KEY) || null,
  typing: {},
  reads: {},
  pendingRequests: {},
  myPendingReq: {},
  myPendingReqStatus: {},
  hiddenDms: new Set(),
  hiddenMessages: new Set(),
  scheduled: [],
  scheduledPollTimer: null,
  capsuleTickTimer: null,
  translating: {},
  showTranslation: {},
  translateTo: localStorage.getItem(LANG_KEY) || 'en'
}

// =========================================================================
// THEME
// =========================================================================
export function applyTheme(theme) {
  document.body.classList.remove('theme-light', 'theme-dark', 'theme-system')
  document.body.classList.add('theme-' + (theme || 'dark'))
}
applyTheme(localStorage.getItem(THEME_KEY) || 'dark')