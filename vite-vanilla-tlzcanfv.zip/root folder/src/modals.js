// =========================================================================
// MODALS — host, confirm, profile, new chat/group, search, tools, schedule
// =========================================================================

import {
  state, LANG_KEY, THEME_KEY, MAX_MESSAGE_LENGTH,
  applyTheme, LANGUAGES
} from './config.js'
import {
  sb, escapeHtml, avatarHTML, avatarStackHTML,
  toastError, toastSuccess, toastInfo,
  formatDay, formatTime, scheduleLabel, stackedLogo, ICONS,
  debounce, isAllowedFileType
} from './lib.js'
import {
  buildSystemRow, normalizeMessage, loadScheduled,
  clearLastChat, buildMessageRow
} from './messages.js'
import {
  loadPendingRequests, requestJoinGroup, approveJoinRequest,
  denyJoinRequest, loadMyPendingRequests
} from './social.js'

// =========================================================================
// MODAL HOST
// =========================================================================
export function openModal(name, data) {
  closeModal()
  const o = document.createElement('div')
  o.className = 'modal-overlay'
  o.id = 'modal-overlay'
  o.innerHTML = `<div class="modal-box">
    <div class="modal-head">
      <h2 id="modal-title"></h2>
      <button class="modal-close" id="modal-close">&times;</button>
    </div>
    <div class="modal-body" id="modal-body"></div>
  </div>`
  o.addEventListener('mousedown', e => { if (e.target === o) closeModal() })
  document.body.appendChild(o)
  document.getElementById('modal-close').onclick = closeModal

  const builders = {
    profile: buildProfileModal,
    newChat: buildNewChatModal,
    newGroup: buildNewGroupModal,
    newGroupMembersForExisting: buildAddMembersToExisting,
    groupInfo: buildGroupInfoModal,
    search: () => buildSearchModal(data),
    userProfile: () => buildUserProfileModal(data),
    splitBill: window.__pitchtalk_buildSplitBillModal,
    task: window.__pitchtalk_buildTaskModal,
    meeting: window.__pitchtalk_buildMeetingModal,
    location: window.__pitchtalk_buildLocationModal,
    poll: window.__pitchtalk_buildPollModal,
    wheel: window.__pitchtalk_buildWheelModal,
    capsule: window.__pitchtalk_buildCapsuleModal,
    schedule: () => buildScheduleModal(data),
    scheduledList: buildScheduledListModal,
    tools: buildToolsModal
  }
  builders[name]?.(data)
}

export function closeModal() {
  document.getElementById('modal-overlay')?.remove()
}

export function closeAllModals() {
  document.querySelectorAll('.modal-overlay').forEach(el => {
    if (el.id === 'confirm-overlay' && typeof el.__resolveCancel === 'function') {
      try { el.__resolveCancel() } catch (e) {}
    }
    el.remove()
  })
}

export function confirmDialog({ title, message, confirmText = 'Confirm', cancelText = 'Cancel', danger = false } = {}) {
  return new Promise(resolve => {
    const o = document.createElement('div')
    o.className = 'modal-overlay'
    o.id = 'confirm-overlay'
    o.innerHTML = `
      <div class="modal-box" style="max-width:380px;">
        <div class="modal-head">
          <h2>${escapeHtml(title || 'Are you sure?')}</h2>
          <button class="modal-close" id="confirm-close" aria-label="Close">&times;</button>
        </div>
        <div class="modal-body">
          <p style="margin:0 0 16px;font-size:14px;line-height:1.5;color:var(--ink);">${escapeHtml(message || '')}</p>
          <div style="display:flex;gap:8px;justify-content:flex-end;">
            <button class="btn-secondary" id="confirm-cancel" style="width:auto;margin:0;padding:10px 16px;">${escapeHtml(cancelText)}</button>
            <button class="btn-primary" id="confirm-ok" style="width:auto;margin:0;padding:10px 16px;${danger ? 'background:#c81e1e;color:#fff;' : ''}">${escapeHtml(confirmText)}</button>
          </div>
        </div>
      </div>`
    const finish = (val) => { o.remove(); document.removeEventListener('keydown', onKey); resolve(val) }
    const onKey = (e) => { if (e.key === 'Escape') finish(false) }
    o.addEventListener('mousedown', e => { if (e.target === o) finish(false) })
    document.addEventListener('keydown', onKey)
    document.body.appendChild(o)
    o.__resolveCancel = () => finish(false)
    o.querySelector('#confirm-close').onclick = () => finish(false)
    o.querySelector('#confirm-cancel').onclick = () => finish(false)
    o.querySelector('#confirm-ok').onclick = () => finish(true)
    o.querySelector('#confirm-ok').focus()
  })
}

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    if (document.getElementById('modal-overlay')) closeModal()
  }
})

// =========================================================================
// PROFILE MODAL
// =========================================================================
function buildProfileModal() {
  document.getElementById('modal-title').textContent = 'My Profile'
  const p = state.profile
  let avatarUrl = p.avatar_url || ''
  document.getElementById('modal-body').innerHTML = `
    <div class="avatar-upload-row">
      <div id="avatar-preview">${avatarHTML(p.display_name||p.username, avatarUrl, 'xl')}</div>
      <label id="avatar-upload-label">Change photo<input type="file" accept="image/*" class="hidden" id="avatar-file-input" /></label>
    </div>
    <div class="field"><label>Username</label><input value="${escapeHtml(p.username)}" disabled /></div>
    <div class="field"><label>Display name (max 15)</label><input id="pf-display-name" maxlength="15" value="${escapeHtml(p.display_name||'')}" /></div>
    <div class="field"><label>Status</label>
      <select id="pf-status">
        <option value="Available">Available</option>
        <option value="Busy">Busy</option>
        <option value="On Meeting">On Meeting</option>
      </select>
    </div>
    <div class="field"><label>Theme</label>
      <select id="pf-theme">
        <option value="dark">Dark</option>
        <option value="light">Light</option>
        <option value="system">System</option>
      </select>
    </div>
    <div class="field"><label>Translate messages to</label>
      <select id="pf-lang">
        ${LANGUAGES.map(([c, n]) => `<option value="${c}">${n}</option>`).join('')}
      </select>
    </div>
    <p class="msg-error hidden" id="pf-error"></p>
    <button class="btn-primary" id="pf-save">Save changes</button>
    <button class="btn-secondary" id="pf-signout">Sign out</button>`

  setTimeout(() => {
    document.getElementById('pf-status').value = p.status_text || 'Available'
    document.getElementById('pf-theme').value = localStorage.getItem(THEME_KEY) || 'dark'
    document.getElementById('pf-lang').value = state.translateTo
  }, 0)

  document.getElementById('avatar-file-input').addEventListener('change', async e => {
    const f = e.target.files?.[0]
    if (!f) return
    try {
      const ext = f.name.split('.').pop()
      const path = `${p.id}/${Date.now()}.${ext}`
      const { error: ue } = await sb.storage.from('avatars').upload(path, f, { upsert: true })
      if (ue) throw ue
      const { data } = sb.storage.from('avatars').getPublicUrl(path)
      avatarUrl = data.publicUrl
      document.getElementById('avatar-preview').innerHTML = avatarHTML(
        document.getElementById('pf-display-name').value || p.username, avatarUrl, 'xl'
      )
    } catch (err) {
      const el = document.getElementById('pf-error')
      el.textContent = err.message; el.classList.remove('hidden')
    }
  })

  document.getElementById('pf-save').addEventListener('click', async () => {
    const btn = document.getElementById('pf-save')
    btn.disabled = true; btn.textContent = 'Saving…'
    try {
      const dn = (document.getElementById('pf-display-name').value.trim() || p.username).slice(0, 15)
      const st = document.getElementById('pf-status').value
      const theme = document.getElementById('pf-theme').value
      const lang = document.getElementById('pf-lang').value
      const { error } = await sb.from('profiles').update({
        display_name: dn, status_text: st, avatar_url: avatarUrl,
        updated_at: new Date().toISOString()
      }).eq('id', p.id)
      if (error) throw error
      state.profile = { ...p, display_name: dn, status_text: st, avatar_url: avatarUrl }
      state.translateTo = lang
      localStorage.setItem(LANG_KEY, lang)
      localStorage.setItem(THEME_KEY, theme)
      applyTheme(theme)
      window.dispatchEvent(new CustomEvent('pitchtalk:profile-updated'))
      closeModal()
      window.dispatchEvent(new CustomEvent('pitchtalk:rerender-app'))
    } catch (err) {
      const el = document.getElementById('pf-error')
      el.textContent = err.message; el.classList.remove('hidden')
      btn.disabled = false; btn.textContent = 'Save changes'
    }
  })

  document.getElementById('pf-signout').addEventListener('click', async () => {
    closeAllModals()
    await sb.auth.signOut()
  })
}

// =========================================================================
// USER PROFILE MODAL
// =========================================================================
export async function openUserProfileModal(userId) {
  const { data: prof } = await sb.from('profiles')
    .select('id, username, display_name, avatar_url, status_text')
    .eq('id', userId).maybeSingle()
  if (!prof) { toastError('Profile not found'); return }
  openModal('userProfile', prof)
}

function buildUserProfileModal(prof) {
  document.getElementById('modal-title').textContent = 'Profile'
  const online = state.onlineUsers.has(prof.id)
  document.getElementById('modal-body').innerHTML = `
    <div class="profile-view-card">
      ${avatarHTML(prof.display_name || prof.username, prof.avatar_url, 'xl', { online })}
      <p class="profile-view-name">${escapeHtml(prof.display_name || prof.username)}</p>
      <p class="profile-view-status">${escapeHtml(prof.status_text || 'Available')}</p>
      <p class="profile-view-presence"><span class="dot ${online ? 'online' : 'offline'}"></span>${online ? 'Online' : 'Offline'}</p>
      <div class="profile-view-actions">
        <button class="btn-primary" id="up-dm" style="margin:0">Direct message</button>
        <button class="btn-secondary" id="up-group" style="margin:0">Create group</button>
      </div>
    </div>`
  document.getElementById('up-dm').onclick = async () => {
    closeModal()
    let user = state.directChats.find(u => u.id === prof.id)
    if (!user) { user = prof; state.directChats = [user, ...state.directChats] }
    window.dispatchEvent(new CustomEvent('pitchtalk:open-dm', { detail: { user } }))
  }
  document.getElementById('up-group').onclick = () => {
    closeModal()
    openModal('newGroup')
    setTimeout(() => {
      const nameEl = document.getElementById('ng-name')
      if (nameEl) {
        nameEl.value = `Group with ${prof.display_name || prof.username}`
        nameEl.focus()
      }
    }, 50)
  }
}

// =========================================================================
// NEW CHAT MODAL
// =========================================================================
function buildNewChatModal() {
  document.getElementById('modal-title').textContent = 'New direct message'
  document.getElementById('modal-body').innerHTML = `
    <input id="nc-search" placeholder="Search people by name…"
      style="width:100%;background:var(--raised);border:1px solid var(--hairline);border-radius:8px;padding:9px 12px;font-size:14px;color:var(--ink);outline:none;margin-bottom:12px;" />
    <div class="search-results" id="nc-results"></div>`
  const inp = document.getElementById('nc-search')
  inp.focus()
  const go = debounce(async q => {
    const r = document.getElementById('nc-results')
    if (!q) { r.innerHTML = ''; return }
    r.innerHTML = '<p class="search-hint">Searching…</p>'
    const { data, error } = await sb.from('profiles')
      .select('id, username, display_name, avatar_url')
      .neq('id', state.session.user.id)
      .or(`username.ilike.%${q}%,display_name.ilike.%${q}%`)
      .limit(20)
    if (error) { r.innerHTML = `<p class="search-hint">${escapeHtml(error.message)}</p>`; return }
    if (!data?.length) { r.innerHTML = `<p class="search-hint">No one matches.</p>`; return }
    r.innerHTML = data.map(u => `<button class="search-result-row" data-id="${u.id}">
      ${avatarHTML(u.display_name||u.username,u.avatar_url,'sm')}
      <div class="row-text">
        <p class="row-title">${escapeHtml(u.display_name||u.username)}</p>
        <p class="row-sub">${state.onlineUsers.has(u.id)?'Online':'Offline'}</p>
      </div>
    </button>`).join('')
    r.querySelectorAll('[data-id]').forEach(b => b.onclick = () => {
      const u = data.find(x => x.id === b.dataset.id)
      if (!state.directChats.some(p => p.id === u.id)) state.directChats = [u, ...state.directChats]
      closeModal()
      window.dispatchEvent(new CustomEvent('pitchtalk:open-dm', { detail: { user: u } }))
    })
  }, 250)
  inp.addEventListener('input', () => go(inp.value.trim()))
}

// =========================================================================
// NEW GROUP MODAL
// =========================================================================
function buildNewGroupModal() {
  document.getElementById('modal-title').textContent = 'Create group'
  const picked = []
  document.getElementById('modal-body').innerHTML = `
    <div class="field"><label>Group name</label><input id="ng-name" placeholder="Design Team" maxlength="30" /></div>
    <div class="field"><label>Visibility</label>
      <select id="ng-public">
        <option value="false">Private (people must request to join)</option>
        <option value="true">Public (anyone can join)</option>
      </select>
    </div>
    <div id="ng-members-preview"></div>
    <div class="field"><label>Add people</label>
      <input id="ng-search" placeholder="Search by name…" />
      <div class="search-results" id="ng-results"></div>
    </div>
    <p class="msg-error hidden" id="ng-error"></p>
    <button class="btn-primary" id="ng-create">Create group</button>`
  document.getElementById('ng-name').focus()

  function rp() {
    const el = document.getElementById('ng-members-preview')
    if (!picked.length) { el.innerHTML = ''; return }
    el.innerHTML = `<div class="field"><label>Members</label>
      <div style="display:flex;align-items:center;justify-content:space-between;background:var(--raised);border:1px solid var(--hairline);border-radius:8px;padding:8px 12px;">
        ${avatarStackHTML([{display_name:'You'}, ...picked])}
        <span style="font-size:12px;color:var(--ink-dim);">${picked.length + 1} people</span>
      </div>
      <div style="margin-top:8px;">${picked.map(u => `<span class="member-chip">${avatarHTML(u.display_name||u.username,u.avatar_url,'xs')}${escapeHtml(u.display_name||u.username)}<button data-remove="${u.id}">&times;</button></span>`).join('')}</div>
    </div>`
    el.querySelectorAll('[data-remove]').forEach(b => b.onclick = () => {
      const i = picked.findIndex(u => u.id === b.dataset.remove)
      if (i > -1) picked.splice(i, 1)
      rp()
    })
  }

  const go = debounce(async q => {
    const r = document.getElementById('ng-results')
    if (!q) { r.innerHTML = ''; return }
    const { data } = await sb.from('profiles')
      .select('id, username, display_name, avatar_url')
      .neq('id', state.session.user.id)
      .or(`username.ilike.%${q}%,display_name.ilike.%${q}%`)
      .limit(20)
    const f = (data || []).filter(u => !picked.some(p => p.id === u.id))
    r.innerHTML = f.map(u => `<button class="search-result-row" data-id="${u.id}">
      ${avatarHTML(u.display_name||u.username,u.avatar_url,'xs')}
      <div class="row-text">
        <p class="row-title">${escapeHtml(u.display_name||u.username)}</p>
        <p class="row-sub">${state.onlineUsers.has(u.id)?'Online':'Offline'}</p>
      </div>
    </button>`).join('')
    r.querySelectorAll('[data-id]').forEach(b => b.onclick = () => {
      const u = f.find(x => x.id === b.dataset.id)
      picked.push(u); rp()
      document.getElementById('ng-search').value = ''
      r.innerHTML = ''
    })
  }, 250)

  document.getElementById('ng-search').addEventListener('input', e => go(e.target.value.trim()))

  document.getElementById('ng-create').addEventListener('click', async () => {
    const name = document.getElementById('ng-name').value.trim()
    const isPublic = document.getElementById('ng-public').value === 'true'
    if (!name) {
      const el = document.getElementById('ng-error')
      el.textContent = 'Give the group a name.'
      el.classList.remove('hidden')
      return
    }
    const b = document.getElementById('ng-create')
    b.disabled = true; b.textContent = 'Creating…'
    try {
      const { data: g, error: ge } = await sb.from('groups').insert({
        name, created_by: state.session.user.id, is_public: isPublic
      }).select().single()
      if (ge) throw ge
      const rows = [
        { group_id: g.id, user_id: state.session.user.id, role: 'owner' },
        ...picked.map(u => ({ group_id: g.id, user_id: u.id, role: 'member' }))
      ]
      const { error: me } = await sb.from('group_members').insert(rows)
      if (me) throw me
      state.groupChats = [g, ...state.groupChats]
      closeModal()
      window.dispatchEvent(new CustomEvent('pitchtalk:open-group', { detail: { group: g } }))
      window.dispatchEvent(new CustomEvent('pitchtalk:sidebar-rerender'))
    } catch (err) {
      const el = document.getElementById('ng-error')
      el.textContent = err.message
      el.classList.remove('hidden')
      b.disabled = false; b.textContent = 'Create group'
    }
  })
}

// =========================================================================
// GROUP INFO MODAL
// =========================================================================
let _groupInfoGroup = null
let _groupInfoCanManage = false

async function buildGroupInfoModal() {
  const g = state.activeChat.group
  const myId = state.session.user.id
  const myRole = state.groupMembers.find(m => m.id === myId)?.role || 'member'
  const canManage = myRole === 'owner' || myRole === 'admin'
  const isOwner = myRole === 'owner'
  const isLastMember = state.groupMembers.length === 1
  _groupInfoGroup = g
  _groupInfoCanManage = canManage

  await loadPendingRequests(g.id, { silent: true })

  const leaveLabel = isLastMember ? 'Leave & delete group' : 'Leave group'

  document.getElementById('modal-title').textContent = g.name
  document.getElementById('modal-body').innerHTML = `
    ${canManage ? `
      <div class="field">
        <label>Group name (owner/admin)</label>
        <input id="gi-name" maxlength="30" value="${escapeHtml(g.name)}" />
      </div>` : ''}
    <div id="gi-pending" class="hidden"></div>
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
      <label style="font-size:12px;color:var(--ink-dim);">Members (${state.groupMembers.length})</label>
      ${canManage ? `<button class="btn-soft" id="gi-add-members" style="flex:none;padding:6px 12px;">+ Add</button>` : ''}
    </div>
    <div id="gi-members-list"></div>
    ${canManage ? `<button class="btn-primary" id="gi-save">Save name</button>` : ''}
    <button class="btn-secondary" id="gi-leave" style="color:#e02424;border-color:rgba(200,30,30,.4);margin-top:8px;">${leaveLabel}</button>
    ${isOwner ? `<button class="btn-secondary" id="gi-delete" style="color:#fff;background:#c81e1e;border-color:#c81e1e;margin-top:8px;font-weight:700;">🗑 Delete group</button>` : ''}
    <p class="msg-error hidden" id="gi-error"></p>`

  renderPendingRequests()
  renderMembersList()

  if (canManage) {
    document.getElementById('gi-add-members').onclick = () => {
      closeModal()
      openModal('newGroupMembersForExisting')
    }
    document.getElementById('gi-save').onclick = async () => {
      const newName = document.getElementById('gi-name').value.trim()
      if (!newName || newName === g.name) return
      try {
        const { error } = await sb.from('groups').update({ name: newName }).eq('id', g.id)
        if (error) throw error
        const oldName = g.name
        g.name = newName
        state.groupChats = state.groupChats.map(x => x.id === g.id ? { ...x, name: newName } : x)
        const sysRow = buildSystemRow({
          text: `${state.profile.display_name || state.profile.username} renamed the group from "${oldName}" to "${newName}"`,
          isGroup: true, groupId: g.id
        })
        await sb.from('messages').insert(sysRow)
        closeModal()
        window.dispatchEvent(new CustomEvent('pitchtalk:sidebar-rerender'))
        window.dispatchEvent(new CustomEvent('pitchtalk:remount-chat'))
      } catch (err) {
        const el = document.getElementById('gi-error')
        el.textContent = err.message; el.classList.remove('hidden')
      }
    }
  }

  document.getElementById('gi-leave').onclick = async () => {
    const lastMemberNow = state.groupMembers.length === 1
    const confirmed = await confirmDialog({
      title: lastMemberNow ? `Leave & delete "${g.name}"?` : 'Leave group?',
      message: lastMemberNow
        ? `You're the last member. Leaving will permanently delete this group and all its messages. This cannot be undone.`
        : `You will stop receiving messages from "${g.name}". You can request to rejoin later.`,
      confirmText: lastMemberNow ? 'Leave & delete' : 'Leave',
      danger: true
    })
    if (!confirmed) return
    const btn = document.getElementById('gi-leave')
    btn.disabled = true; btn.textContent = 'Leaving…'
    try {
      const res = await leaveGroupSmart(g.id)
      state.groupChats = state.groupChats.filter(x => x.id !== g.id)
      if (state.activeChat?.type === 'group' && state.activeChat.group.id === g.id) {
        state.activeChat = null
        clearLastChat()
        window.dispatchEvent(new CustomEvent('pitchtalk:render-empty'))
      }
      closeModal()
      window.dispatchEvent(new CustomEvent('pitchtalk:sidebar-rerender'))
      if (res.action === 'deleted') toastSuccess(`Deleted "${g.name}"`)
      else toastSuccess(`You left "${g.name}"`)
    } catch (err) {
      btn.disabled = false; btn.textContent = leaveLabel
      const errEl = document.getElementById('gi-error')
      errEl.textContent = err.message; errEl.classList.remove('hidden')
    }
  }

  if (isOwner) {
    document.getElementById('gi-delete').onclick = async () => {
      const ok = await confirmDialog({
        title: `Delete "${g.name}"?`,
        message: 'This will permanently delete the group, all its members, and all messages. This cannot be undone.',
        confirmText: 'Delete forever',
        danger: true
      })
      if (!ok) return
      const btn = document.getElementById('gi-delete')
      btn.disabled = true; btn.textContent = 'Deleting…'
      try {
        await deleteGroupPermanently(g.id)
        state.groupChats = state.groupChats.filter(x => x.id !== g.id)
        delete state.pendingRequests[g.id]
        if (state.activeChat?.type === 'group' && state.activeChat.group.id === g.id) {
          state.activeChat = null
          clearLastChat()
          window.dispatchEvent(new CustomEvent('pitchtalk:render-empty'))
        }
        closeModal()
        window.dispatchEvent(new CustomEvent('pitchtalk:sidebar-rerender'))
        toastSuccess(`Deleted "${g.name}"`)
      } catch (err) {
        btn.disabled = false; btn.textContent = '🗑 Delete group'
        const errEl = document.getElementById('gi-error')
        errEl.textContent = err.message; errEl.classList.remove('hidden')
      }
    }
  }
}

function renderPendingRequests() {
  const el = document.getElementById('gi-pending')
  if (!el || !_groupInfoGroup) return
  const list = state.pendingRequests[_groupInfoGroup.id] || []
  if (!list.length) { el.innerHTML = ''; el.classList.add('hidden'); return }
  el.classList.remove('hidden')
  el.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:center;margin:16px 0 8px;">
      <label style="font-size:12px;color:var(--ink-dim);">Pending join requests (${list.length})</label>
    </div>
    ${list.map(r => {
      const p = r.profile || { username: 'user', display_name: 'User' }
      return `<div class="req-card" data-req="${r.id}">
        <div class="req-user">
          ${avatarHTML(p.display_name || p.username, p.avatar_url, 'sm', { clickable: true, userId: r.user_id })}
          <div class="row-text" style="min-width:0;">
            <p class="row-title">${escapeHtml(p.display_name || p.username)}</p>
            <p class="row-sub">${formatDay(r.created_at)} · ${formatTime(r.created_at)}</p>
          </div>
        </div>
        <div class="req-actions">
          <button class="approve" data-approve="${r.id}">Approve</button>
          <button class="deny" data-deny="${r.id}">Deny</button>
        </div>
      </div>`
    }).join('')}`
  el.querySelectorAll('[data-avatar-user]').forEach(av => {
    av.onclick = (e) => {
      e.stopPropagation()
      const uid = av.dataset.avatarUser
      if (uid === state.session.user.id) { closeModal(); openModal('profile'); return }
      closeModal()
      openUserProfileModal(uid)
    }
  })
  el.querySelectorAll('[data-approve]').forEach(b => b.onclick = async () => {
    const id = b.dataset.approve
    b.disabled = true; b.textContent = 'Approving…'
    await approveJoinRequest(id, _groupInfoGroup.id)
    b.disabled = false; b.textContent = 'Approve'
  })
  el.querySelectorAll('[data-deny]').forEach(b => b.onclick = async () => {
    const id = b.dataset.deny
    b.disabled = true; b.textContent = 'Denying…'
    await denyJoinRequest(id, _groupInfoGroup.id)
    b.disabled = false; b.textContent = 'Deny'
  })
}

function renderMembersList() {
  const el = document.getElementById('gi-members-list')
  if (!el || !_groupInfoGroup) return
  const myId = state.session.user.id
  el.innerHTML = state.groupMembers.map(m => {
    const online = state.onlineUsers.has(m.id)
    const roleLabel = m.role === 'owner' ? '<span class="role-badge owner">Owner</span>'
      : m.role === 'admin' ? '<span class="role-badge admin">Admin</span>' : ''
    const isSelf = m.id === myId
    return `<div class="join-row" data-mem="${m.id}">
      <div style="display:flex;align-items:center;gap:10px;min-width:0;">
        ${avatarHTML(m.display_name||m.username, m.avatar_url, 'sm', { online, clickable: true, userId: m.id })}
        <div class="row-text">
          <p class="row-title">${escapeHtml(m.display_name||m.username)} ${isSelf ? '(you)' : ''} ${roleLabel}</p>
          <p class="row-sub">${online ? 'Online' : 'Offline'}</p>
        </div>
      </div>
      ${_groupInfoCanManage && !isSelf && m.role !== 'owner' ? `
        <div style="display:flex;gap:4px;">
          <button class="btn-soft" style="flex:none;padding:4px 8px;font-size:11px;" data-toggle-admin="${m.id}" data-role="${m.role}">${m.role === 'admin' ? 'Demote' : 'Make admin'}</button>
          <button class="btn-soft" style="flex:none;padding:4px 8px;font-size:11px;color:var(--ember-glow);" data-remove="${m.id}">Remove</button>
        </div>` : ''}
    </div>`
  }).join('')

  el.querySelectorAll('[data-avatar-user]').forEach(av => {
    av.onclick = (e) => {
      e.stopPropagation()
      const uid = av.dataset.avatarUser
      if (uid === state.session.user.id) { closeModal(); openModal('profile'); return }
      closeModal()
      openUserProfileModal(uid)
    }
  })

  el.querySelectorAll('[data-toggle-admin]').forEach(b => b.onclick = async (e) => {
    e.stopPropagation()
    const uid = b.dataset.toggleAdmin
    const newRole = b.dataset.role === 'admin' ? 'member' : 'admin'
    try {
      const { error } = await sb.from('group_members')
        .update({ role: newRole })
        .eq('group_id', _groupInfoGroup.id).eq('user_id', uid)
      if (error) throw error
      const target = state.groupMembers.find(m => m.id === uid)
      target.role = newRole
      const displayName = target.display_name || target.username
      const sysRow = buildSystemRow({
        text: newRole === 'admin' ? `${displayName} was promoted to admin` : `${displayName} is no longer admin`,
        isGroup: true, groupId: _groupInfoGroup.id
      })
      await sb.from('messages').insert(sysRow)
      renderMembersList()
    } catch (err) { toastError(err.message) }
  })

  el.querySelectorAll('[data-remove]').forEach(b => b.onclick = async (e) => {
    e.stopPropagation()
    const uid = b.dataset.remove
    const target0 = state.groupMembers.find(m => m.id === uid)
    const ok = await confirmDialog({
      title: 'Remove member?',
      message: `${target0?.display_name || target0?.username || 'This member'} will be removed from the group.`,
      confirmText: 'Remove',
      danger: true
    })
    if (!ok) return
    try {
      const { error } = await sb.from('group_members')
        .delete().eq('group_id', _groupInfoGroup.id).eq('user_id', uid)
      if (error) throw error
      const target = state.groupMembers.find(m => m.id === uid)
      state.groupMembers = state.groupMembers.filter(m => m.id !== uid)
      const sysRow = buildSystemRow({
        text: `${target.display_name || target.username} was removed from the group`,
        isGroup: true, groupId: _groupInfoGroup.id
      })
      await sb.from('messages').insert(sysRow)
      renderMembersList()
      window.dispatchEvent(new CustomEvent('pitchtalk:remount-chat'))
    } catch (err) { toastError(err.message) }
  })
}

async function deleteGroupPermanently(groupId) {
  const { error } = await sb.from('groups').delete().eq('id', groupId)
  if (error) throw error
}

async function leaveGroupSmart(groupId) {
  const myId = state.session.user.id
  const member = state.groupMembers.find(m => m.id === myId)
  if (!member) return { action: 'noop' }

  if (state.groupMembers.length === 1) {
    await deleteGroupPermanently(groupId)
    return { action: 'deleted' }
  }

  if (member.role === 'owner') {
    const others = state.groupMembers.filter(m => m.id !== myId)
    const nextOwner = others.find(m => m.role === 'admin') || others[0]
    const { error: oe } = await sb.from('group_members')
      .update({ role: 'owner' }).eq('group_id', groupId).eq('user_id', nextOwner.id)
    if (oe) throw oe
    const { error: ge } = await sb.from('groups')
      .update({ created_by: nextOwner.id }).eq('id', groupId)
    if (ge) throw ge
  }

  const displayName = state.profile.display_name || state.profile.username
  const sysRow = buildSystemRow({ text: `${displayName} left the group`, isGroup: true, groupId })
  await sb.from('messages').insert(sysRow)

  const { error } = await sb.from('group_members')
    .delete().eq('group_id', groupId).eq('user_id', myId)
  if (error) throw error
  return { action: 'left' }
}

// =========================================================================
// ADD MEMBERS TO EXISTING
// =========================================================================
function buildAddMembersToExisting() {
  document.getElementById('modal-title').textContent = 'Add members'
  const g = state.activeChat.group
  document.getElementById('modal-body').innerHTML = `
    <input id="am-search" placeholder="Search by name…"
      style="width:100%;background:var(--raised);border:1px solid var(--hairline);border-radius:8px;padding:9px 12px;font-size:14px;color:var(--ink);outline:none;margin-bottom:12px;" />
    <div class="search-results" id="am-results"></div>`
  document.getElementById('am-search').focus()
  const existing = new Set(state.groupMembers.map(m => m.id))
  const go = debounce(async q => {
    const r = document.getElementById('am-results')
    if (!q) { r.innerHTML = ''; return }
    const { data } = await sb.from('profiles')
      .select('id, username, display_name, avatar_url')
      .or(`username.ilike.%${q}%,display_name.ilike.%${q}%`)
      .limit(20)
    const f = (data || []).filter(u => !existing.has(u.id))
    r.innerHTML = f.map(u => `<div class="join-row" data-row="${u.id}">
      <div style="display:flex;align-items:center;gap:10px;min-width:0;">
        ${avatarHTML(u.display_name||u.username,u.avatar_url,'sm')}
        <div class="row-text">
          <p class="row-title">${escapeHtml(u.display_name||u.username)}</p>
          <p class="row-sub">${state.onlineUsers.has(u.id)?'Online':'Offline'}</p>
        </div>
      </div>
      <button class="btn-join" data-add="${u.id}">Add</button>
    </div>`).join('')
    r.querySelectorAll('[data-add]').forEach(b => b.onclick = async () => {
      const u = f.find(x => x.id === b.dataset.add)
      b.disabled = true; b.textContent = 'Adding…'
      try {
        const { error } = await sb.from('group_members')
          .insert({ group_id: g.id, user_id: u.id, role: 'member' })
        if (error) throw error
        existing.add(u.id)
        state.groupMembers.push({ ...u, role: 'member' })
        const sysRow = buildSystemRow({
          text: `${state.profile.display_name || state.profile.username} added ${u.display_name || u.username} to the group`,
          isGroup: true, groupId: g.id
        })
        await sb.from('messages').insert(sysRow)
        document.querySelector(`[data-row="${u.id}"]`)?.remove()
        window.dispatchEvent(new CustomEvent('pitchtalk:remount-chat'))
      } catch (err) {
        toastError(err.message)
        b.disabled = false; b.textContent = 'Add'
      }
    })
  }, 250)
  document.getElementById('am-search').addEventListener('input', e => go(e.target.value.trim()))
}

// =========================================================================
// SEARCH MODAL
// =========================================================================
function buildSearchModal(data = {}) {
  const scope = data?.scope || 'global'
  const isChatScope = scope === 'chat' && state.activeChat
  const chat = state.activeChat

  document.getElementById('modal-title').textContent = isChatScope
    ? `Search in ${chat.type === 'group' ? chat.group.name : (chat.user.display_name || chat.user.username)}`
    : 'Search (today)'
  document.getElementById('modal-body').classList.add('with-tabs')

  const body = document.getElementById('modal-body')
  body.innerHTML = `
    ${isChatScope ? '' : `
      <div class="search-tabs">
        <button data-tab="messages" class="active">Messages</button>
        <button data-tab="groups">Groups</button>
      </div>`}
    <div class="search-tab-body" id="search-tab-body"></div>`

  function paintMessagesTab() {
    const container = document.getElementById('search-tab-body')
    const placeholder = isChatScope ? 'Search in this conversation (today)…' : 'Search messages from today…'
    container.innerHTML = `
      <input id="ms-search" placeholder="${placeholder}"
        style="width:100%;background:var(--raised);border:1px solid var(--hairline);border-radius:8px;padding:9px 12px;font-size:14px;color:var(--ink);outline:none;margin-bottom:12px;" />
      <p class="search-hint" id="ms-hint">Type at least 2 characters. Only messages from today.</p>
      <div class="search-results" id="ms-results"></div>`
    const inp = document.getElementById('ms-search')
    inp.focus()
    const go = debounce(async q => {
      const r = document.getElementById('ms-results')
      const hint = document.getElementById('ms-hint')
      if (!q || q.length < 2) {
        r.innerHTML = ''
        hint.textContent = 'Type at least 2 characters. Only messages from today.'
        hint.style.display = ''
        return
      }
      hint.textContent = 'Searching…'; hint.style.display = ''

      const myId = state.session.user.id
      const cutoff = new Date(); cutoff.setHours(0,0,0,0)
      const cutoffIso = cutoff.toISOString()
      let scopeClause
      if (isChatScope) {
        if (chat.type === 'group') {
          scopeClause = `group_id.eq.${chat.group.id}`
        } else {
          scopeClause = `and(sender_id.eq.${myId},recipient_id.eq.${chat.user.id}),and(sender_id.eq.${chat.user.id},recipient_id.eq.${myId})`
        }
      } else {
        const groupIds = state.groupChats.map(g => g.id)
        const dmClause = `and(sender_id.eq.${myId},recipient_id.not.is.null),and(recipient_id.eq.${myId})`
        const groupClause = groupIds.length ? `group_id.in.(${groupIds.join(',')})` : ''
        scopeClause = groupClause ? `${dmClause},${groupClause}` : dmClause
      }

      const { data, error } = await sb.from('messages')
        .select('id, body, sender_id, recipient_id, group_id, created_at, is_deleted')
        .or(scopeClause)
        .ilike('body', `%${q}%`)
        .eq('is_deleted', false)
        .not('body', 'is', null)
        .gte('created_at', cutoffIso)
        .order('created_at', { ascending: false })
        .limit(40)

      if (error) { hint.textContent = error.message; return }
      if (!data?.length) { hint.textContent = 'No matches in today messages.'; r.innerHTML = ''; return }
      hint.style.display = 'none'

      const senderIds = [...new Set(data.map(m => m.sender_id))]
      const { data: profs } = await sb.from('profiles')
        .select('id, username, display_name, avatar_url').in('id', senderIds)
      const profMap = Object.fromEntries((profs || []).map(p => [p.id, p]))

      r.innerHTML = data.map(m => {
        const sender = profMap[m.sender_id]
        const sName = sender?.display_name || sender?.username || 'User'
        const isGroupMsg = !!m.group_id
        let chatLabel
        if (isChatScope) {
          chatLabel = chat.type === 'group' ? `#${chat.group.name}` : (chat.user.display_name || chat.user.username)
        } else {
          chatLabel = isGroupMsg
            ? (state.groupChats.find(g => g.id === m.group_id)?.name || 'Group')
            : (m.sender_id === myId
                ? `to ${(state.directChats.find(u => u.id === m.recipient_id)?.display_name) || 'someone'}`
                : `from ${sName}`)
        }
        return `<button class="search-result-row" data-msg-id="${m.id}" data-group="${m.group_id || ''}" data-peer="${m.sender_id === myId ? m.recipient_id : m.sender_id}">
          ${avatarHTML(sName, sender?.avatar_url, 'sm')}
          <div class="row-text">
            <p class="row-title">${isGroupMsg ? '#' : ''}${escapeHtml(chatLabel)}</p>
            <p class="row-sub">${escapeHtml(sName)} · ${formatDay(m.created_at)} · ${formatTime(m.created_at)}</p>
            <p class="row-sub" style="color:var(--ink);white-space:normal;margin-top:2px;">${highlightMatch(m.body, q)}</p>
          </div>
        </button>`
      }).join('')

      r.querySelectorAll('[data-msg-id]').forEach(b => b.onclick = async () => {
        const gid = b.dataset.group
        const peerId = b.dataset.peer
        const msgId = b.dataset.msgId
        closeModal()
        if (gid) {
          const g = state.groupChats.find(x => x.id === gid)
          if (g) window.dispatchEvent(new CustomEvent('pitchtalk:open-group', { detail: { group: g } }))
        } else if (peerId) {
          let u = state.directChats.find(x => x.id === peerId)
          if (!u) {
            const { data: prof } = await sb.from('profiles').select('*').eq('id', peerId).maybeSingle()
            if (prof) { u = prof; state.directChats = [u, ...state.directChats] }
          }
          if (u) window.dispatchEvent(new CustomEvent('pitchtalk:open-dm', { detail: { user: u } }))
        }
        setTimeout(() => window.dispatchEvent(new CustomEvent('pitchtalk:scroll-to', { detail: { msgId } })), 400)
      })
    }, 300)
    inp.addEventListener('input', e => go(e.target.value.trim()))
  }

  function paintGroupsTab() {
    const container = document.getElementById('search-tab-body')
    container.innerHTML = `
      <input id="gs-search" placeholder="Search groups by name…"
        style="width:100%;background:var(--raised);border:1px solid var(--hairline);border-radius:8px;padding:9px 12px;font-size:14px;color:var(--ink);outline:none;margin-bottom:12px;" />
      <p class="search-hint" id="gs-hint">Type to search.</p>
      <div class="search-results" id="gs-results"></div>`
    const inp = document.getElementById('gs-search')
    inp.focus()
    const myMembership = new Set(state.groupChats.map(g => g.id))

    const go = debounce(async q => {
      const r = document.getElementById('gs-results')
      const hint = document.getElementById('gs-hint')
      if (!q) { r.innerHTML = ''; hint.textContent = 'Type to search.'; hint.style.display = ''; return }
      hint.textContent = 'Searching…'; hint.style.display = ''
      const { data, error } = await sb.from('groups')
        .select('id, name, description, is_public').ilike('name', `%${q}%`).limit(30)
      if (error) { hint.textContent = error.message; return }
      if (!data?.length) { hint.textContent = 'No groups match.'; r.innerHTML = ''; return }
      hint.style.display = 'none'

      r.innerHTML = data.map(g => {
        const joined = myMembership.has(g.id)
        const reqStatus = state.myPendingReqStatus[g.id]
        let actionHTML
        if (joined) actionHTML = `<span class="joined-label">Joined</span>`
        else if (g.is_public) actionHTML = `<button class="btn-join" data-join="${g.id}">Join</button>`
        else if (reqStatus === 'pending') actionHTML = `<button class="btn-join pending" disabled>Pending…</button>`
        else if (reqStatus === 'denied') actionHTML = `<button class="btn-join" data-request="${g.id}">Request again</button>`
        else actionHTML = `<button class="btn-join" data-request="${g.id}">Request to join</button>`
        const lock = g.is_public ? '' : ' 🔒'
        return `<div class="join-row">
          <div class="row-text" style="min-width:0;">
            <p class="row-title">${escapeHtml(g.name)}${lock}</p>
            ${g.description ? `<p class="row-sub">${escapeHtml(g.description)}</p>` : ''}
          </div>
          ${actionHTML}
        </div>`
      }).join('')

      r.querySelectorAll('[data-join]').forEach(b => b.onclick = async () => {
        const g = data.find(x => x.id === b.dataset.join)
        b.disabled = true; b.textContent = 'Joining…'
        try {
          const { error: je } = await sb.from('group_members')
            .insert({ group_id: g.id, user_id: state.session.user.id, role: 'member' })
          if (je) throw je
          const sysRow = buildSystemRow({
            text: `${state.profile.display_name || state.profile.username} joined the group`,
            isGroup: true, groupId: g.id
          })
          await sb.from('messages').insert(sysRow)
          state.groupChats = [g, ...state.groupChats]
          closeModal()
          window.dispatchEvent(new CustomEvent('pitchtalk:open-group', { detail: { group: g } }))
          window.dispatchEvent(new CustomEvent('pitchtalk:sidebar-rerender'))
        } catch (err) {
          toastError(err.message)
          b.disabled = false; b.textContent = 'Join'
        }
      })

      r.querySelectorAll('[data-request]').forEach(b => b.onclick = async () => {
        const g = data.find(x => x.id === b.dataset.request)
        b.disabled = true; b.textContent = 'Sending…'
        await requestJoinGroup(g)
        b.disabled = false
        b.textContent = 'Pending…'
        b.classList.add('pending')
      })
    }, 300)
    inp.addEventListener('input', e => go(e.target.value.trim()))
  }

  if (!isChatScope) {
    body.querySelectorAll('.search-tabs button').forEach(btn => {
      btn.onclick = () => {
        body.querySelectorAll('.search-tabs button').forEach(x => x.classList.remove('active'))
        btn.classList.add('active')
        if (btn.dataset.tab === 'messages') paintMessagesTab()
        else paintGroupsTab()
      }
    })
  }
  paintMessagesTab()
}

function highlightMatch(text, q) {
  const safe = escapeHtml(text)
  const safeQ = escapeHtml(q)
  if (!safeQ) return safe
  const escaped = safeQ.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  return safe.replace(new RegExp(escaped, 'ig'),
    m => `<mark style="background:rgba(255,90,31,.35);color:inherit;padding:0 2px;border-radius:2px;">${m}</mark>`)
}

// =========================================================================
// TOOLS MODAL
// =========================================================================
function buildToolsModal() {
  document.getElementById('modal-title').textContent = 'Tools'
  const tools = [
    { key: 'splitBill', label: 'Split bill', sub: 'Divvy a total', icon: ICONS.receipt },
    { key: 'task', label: 'Task', sub: 'Assign & track', icon: ICONS.taskIcon },
    { key: 'meeting', label: 'Meeting', sub: 'Propose slots', icon: ICONS.calendar },
    { key: 'location', label: 'Location', sub: 'Drop a pin', icon: ICONS.pin },
    { key: 'poll', label: 'Poll', sub: 'Ask the room', icon: ICONS.poll },
    { key: 'wheel', label: 'Wheel', sub: 'Spin for a pick', icon: ICONS.wheel },
    { key: 'capsule', label: 'Capsule', sub: 'Seal for later', icon: ICONS.capsule },
    { key: 'schedule', label: 'Schedule', sub: 'Send it later', icon: ICONS.clock }
  ]
  const tiles = tools.map(t => `
    <button type="button" class="tool-tile" data-tool="${t.key}">
      <span class="tool-icon-stack">
        <span class="tis-layer">${t.icon}</span>
        <span class="tis-layer">${t.icon}</span>
        <span class="tis-layer">${t.icon}</span>
      </span>
      <span class="tool-label">${escapeHtml(t.label)}</span>
      <span class="tool-sub">${escapeHtml(t.sub)}</span>
    </button>`).join('')
  document.getElementById('modal-body').innerHTML = `<div class="tool-grid">${tiles}</div>`
  document.querySelectorAll('[data-tool]').forEach(b => {
    b.onclick = () => {
      const tool = b.dataset.tool
      closeModal()
      setTimeout(() => openModal(tool), 30)
    }
  })
}

// =========================================================================
// SCHEDULE MODAL
// =========================================================================
function buildScheduleModal(data = {}) {
  const chat = state.activeChat
  if (!chat) { toastError('Open a conversation first'); return }
  const isGroup = chat.type === 'group'
  const presetBody = data?.body || ''
  const now = new Date()
  const tonight = new Date(now); tonight.setHours(20, 0, 0, 0)
  if (tonight <= now) tonight.setDate(tonight.getDate() + 1)
  const fmtLocal = (d) => {
    const p = n => String(n).padStart(2,'0')
    return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`
  }
  document.getElementById('modal-title').textContent = 'Schedule message'
  document.getElementById('modal-body').innerHTML = `
    <div class="field"><label>Message</label>
      <textarea id="sm-body" maxlength="${MAX_MESSAGE_LENGTH}" placeholder="What to send…" style="min-height:80px;resize:vertical;">${escapeHtml(presetBody)}</textarea>
    </div>
    <div class="field"><label>Quick pick</label>
      <div class="schedule-presets">
        <button type="button" data-preset="${new Date(Date.now()+15*60_000).toISOString()}">+15 min</button>
        <button type="button" data-preset="${new Date(Date.now()+60*60_000).toISOString()}">+1 hour</button>
        <button type="button" data-preset="${tonight.toISOString()}">Tonight 8pm</button>
        <button type="button" data-preset="${new Date(Date.now()+86400_000).toISOString()}">Tomorrow</button>
      </div>
    </div>
    <div class="field"><label>Or pick a time</label>
      <input type="datetime-local" id="sm-when" value="${fmtLocal(new Date(Date.now()+15*60_000))}" />
    </div>
    <p class="msg-error hidden" id="sm-error"></p>
    <button class="btn-primary" id="sm-save">Schedule</button>`

  document.querySelectorAll('[data-preset]').forEach(b => {
    b.onclick = () => {
      const d = new Date(b.dataset.preset)
      document.getElementById('sm-when').value = fmtLocal(d)
    }
  })

  document.getElementById('sm-save').onclick = async () => {
    const errEl = document.getElementById('sm-error')
    errEl.classList.add('hidden')
    const body = document.getElementById('sm-body').value.trim()
    const whenStr = document.getElementById('sm-when').value
    if (!body) { errEl.textContent = 'Message is empty.'; errEl.classList.remove('hidden'); return }
    if (!whenStr) { errEl.textContent = 'Pick a time.'; errEl.classList.remove('hidden'); return }
    const sendAt = new Date(whenStr)
    if (sendAt.getTime() <= Date.now() + 5000) {
      errEl.textContent = 'Pick a time in the future.'
      errEl.classList.remove('hidden'); return
    }
    const btn = document.getElementById('sm-save')
    btn.disabled = true; btn.textContent = 'Scheduling…'
    try {
      const { error } = await sb.from('scheduled_messages').insert({
        sender_id: state.session.user.id,
        body,
        send_at: sendAt.toISOString(),
        ...(isGroup ? { group_id: chat.group.id } : { recipient_id: chat.user.id })
      })
      if (error) throw error
      closeModal()
      toastSuccess(`Scheduled for ${scheduleLabel(sendAt.toISOString())}`)
      loadScheduled()
    } catch (err) {
      errEl.textContent = err.message; errEl.classList.remove('hidden')
      btn.disabled = false; btn.textContent = 'Schedule'
    }
  }
}

// =========================================================================
// SCHEDULED LIST MODAL
// =========================================================================
function buildScheduledListModal() {
  document.getElementById('modal-title').textContent = 'Scheduled messages'
  const list = state.scheduled.slice().sort((a,b) => new Date(a.send_at) - new Date(b.send_at))
  document.getElementById('modal-body').innerHTML = list.length
    ? list.map(s => {
        const chat = s.group_id
          ? state.groupChats.find(g => g.id === s.group_id)?.name || 'Group'
          : (state.directChats.find(u => u.id === s.recipient_id)?.display_name || 'Direct')
        return `<div class="scheduled-row">
          <div class="row-text" style="min-width:0;flex:1;">
            <p class="row-title">${escapeHtml(s.body || '(no text)')}</p>
            <p class="row-sub">${escapeHtml(chat)} · ${scheduleLabel(s.send_at)}</p>
          </div>
          <button class="btn-soft" style="flex:none;padding:4px 10px;font-size:11px;color:var(--ember-glow);" data-cancel="${s.id}">Cancel</button>
        </div>`
      }).join('')
    : `<p class="list-empty">No scheduled messages.</p>`

  document.querySelectorAll('[data-cancel]').forEach(b => b.onclick = async () => {
    b.disabled = true; b.textContent = '…'
    const { error } = await sb.from('scheduled_messages').delete().eq('id', b.dataset.cancel)
    if (error) { toastError(error.message); b.disabled = false; b.textContent = 'Cancel'; return }
    await loadScheduled()
    buildScheduledListModal()
  })
}

// Listen for rebuild event
window.addEventListener('pitchtalk:rebuild-scheduled-modal', () => {
  if (document.getElementById('modal-overlay') &&
      document.getElementById('modal-title')?.textContent === 'Scheduled messages') {
    buildScheduledListModal()
  }
})

window.addEventListener('pitchtalk:render-pending-requests', () => {
  if (document.getElementById('gi-pending')) renderPendingRequests()
})