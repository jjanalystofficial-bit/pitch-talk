// =========================================================================
// CHAT — mountChatPane, message nodes, composer, edit/delete/retry
// =========================================================================

import {
  state, MAX_MESSAGE_LENGTH
} from './config.js'
import {
  sb, escapeHtml, avatarHTML, avatarStackHTML,
  formatTime, formatDay, toastError, toastInfo,
  ICONS, debounce, isAllowedFileType, playSound
} from './lib.js'
import {
  currentConversationKey, subscribeTyping, subscribeConversationReads,
  loadConversationReads, markConversationRead, startReadHeartbeat,
  handleComposerTyping, broadcastTyping, renderTypingIndicator,
  stopComposerTyping
} from './typing-reads.js'
import {
  renderedMessageIds, messageCache, pendingSends,
  loadMessages, subscribeMessages, teardownMessagesChannel,
  sendMessage, retryPendingSend, isNearBottomInternal,
  normalizeMessage
} from './messages.js'
import {
  currentMentionContext, renderMessageBody,
  attachMentionAutocomplete, extractMentions
} from './mentions.js'
import { renderStructured } from './structured.js'
import { openModal } from './modals.js'

// =========================================================================
// MOUNT CHAT PANE
// =========================================================================
export async function mountChatPane() {
  await teardownMessagesChannel()
  renderedMessageIds.clear()
  messageCache.clear()
  pendingSends.clear()

  const chat = state.activeChat
  if (!chat) return
  const isGroup = chat.type === 'group'
  const el = document.getElementById('chat-pane')
  if (!el) return

  if (isGroup) {
    try {
      const { data } = await sb.from('group_members')
        .select('user_id, role, profiles:user_id (id, username, display_name, avatar_url)')
        .eq('group_id', chat.group.id)
      state.groupMembers = (data || [])
        .map(r => ({ ...r.profiles, role: r.role }))
        .filter(m => m && m.id)
    } catch (err) {
      state.groupMembers = []
    }
  } else {
    state.groupMembers = []
  }

  const online = !isGroup && state.onlineUsers.has(chat.user.id)
  const ephemeralChip = `<span class="ephemeral-chip" title="Lahat ng messages ay mabubura sa 12:00 MN">${ICONS.clock} midnight</span>`

  let headerLeftHTML = ''
  let headerRightHTML = ''

  if (isGroup) {
    headerLeftHTML = `
      <div class="group-icon" style="width:44px;height:44px;font-size:16px;">#</div>
      <div class="row-text">
        <p class="chat-header-title">${escapeHtml(chat.group.name)} ${ephemeralChip}</p>
        <p class="chat-header-sub" id="chat-header-sub">${state.groupMembers.length} member${state.groupMembers.length === 1 ? '' : 's'}</p>
      </div>`
    headerRightHTML = `
      <div class="call-btns">
        <button class="call-btn" id="btn-chat-search" title="Search in this group">${ICONS.search}</button>
        <button class="call-btn" id="btn-call-audio" title="Group audio call">${ICONS.phone}</button>
        <button class="call-btn" id="btn-call-video" title="Group video call">${ICONS.video}</button>
      </div>
      <button class="group-info-btn" id="btn-group-info" title="View members">
        ${avatarStackHTML(state.groupMembers, 3)}
        <span class="count">${state.groupMembers.length}</span>
      </button>`
  } else {
    headerLeftHTML = `
      ${avatarHTML(chat.user.display_name||chat.user.username, chat.user.avatar_url, 'md', { online, clickable: true, userId: chat.user.id })}
      <div class="row-text">
        <p class="chat-header-title">${escapeHtml(chat.user.display_name||chat.user.username)} ${ephemeralChip}</p>
        <p class="chat-header-sub" id="chat-header-sub">${online ? 'Online' : 'Offline'}</p>
      </div>`
    headerRightHTML = `
      <div class="call-btns">
        <button class="call-btn" id="btn-chat-search" title="Search in this conversation">${ICONS.search}</button>
        <button class="call-btn" id="btn-call-audio" title="Audio call">${ICONS.phone}</button>
        <button class="call-btn" id="btn-call-video" title="Video call">${ICONS.video}</button>
      </div>`
  }

  el.innerHTML = `
    <div class="chat-header">
      <div class="chat-header-left">${headerLeftHTML}</div>
      <div class="chat-header-right" id="chat-header-right">${headerRightHTML}</div>
    </div>
    <div class="chat-messages" id="chat-messages"></div>
    <button id="jump-latest" class="hidden" style="position:absolute;bottom:80px;right:24px;background:var(--ember);color:var(--void);border:none;border-radius:999px;padding:8px 14px;font-size:12px;font-weight:600;box-shadow:0 8px 24px -8px rgba(255,90,31,.5);z-index:5;">↓ New messages</button>
    <form class="composer" id="composer-form">
      <button type="button" class="attach-btn" id="btn-attach" title="Attach a file">${ICONS.paperclip}</button>
      <button type="button" class="attach-btn" id="btn-tools" title="Tools">${ICONS.tools}</button>
      <input type="file" id="file-input" class="hidden" />
      <input class="composer-input" id="composer-text" maxlength="${MAX_MESSAGE_LENGTH}" placeholder="Message ${escapeHtml(isGroup?chat.group.name:chat.user.display_name||chat.user.username)}…" />
      <button type="submit" class="send-btn" id="btn-send" disabled>Send</button>
    </form>`

  if (isGroup) {
    document.getElementById('btn-group-info').onclick = () => openModal('groupInfo')
  }
  document.getElementById('btn-call-audio').onclick = () => window.__pitchtalk_startCall?.('audio')
  document.getElementById('btn-call-video').onclick = () => window.__pitchtalk_startCall?.('video')
  document.getElementById('btn-chat-search').onclick = () => openModal('search', { scope: 'chat' })

  el.querySelectorAll('[data-avatar-user]').forEach(av => {
    av.onclick = (e) => {
      e.stopPropagation()
      const uid = av.dataset.avatarUser
      if (uid === state.session.user.id) { openModal('profile'); return }
      window.__pitchtalk_openUserProfile?.(uid)
    }
  })

  const ti = document.getElementById('composer-text')
  const sBtn = document.getElementById('btn-send')

  ti.addEventListener('input', () => {
    sBtn.disabled = !ti.value.trim()
    if (ti.value.trim()) handleComposerTyping()
    else broadcastTyping(false)
  })
  ti.addEventListener('blur', () => broadcastTyping(false))
  ti.addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      document.getElementById('composer-form').requestSubmit()
    }
  })
  if (isGroup) attachMentionAutocomplete(ti)

  document.getElementById('btn-attach').onclick = () => document.getElementById('file-input').click()
  document.getElementById('btn-tools').onclick = () => openModal('tools')
  document.getElementById('file-input').addEventListener('change', async e => {
    const f = e.target.files?.[0]
    if (!f) return
    e.target.value = ''
    await sendMessage({ file: f })
  })
  document.getElementById('composer-form').addEventListener('submit', async e => {
    e.preventDefault()
    const b = ti.value.trim()
    if (!b) return
    if (b.length > MAX_MESSAGE_LENGTH) {
      toastError(`Message too long (max ${MAX_MESSAGE_LENGTH} chars)`)
      return
    }
    ti.value = ''
    sBtn.disabled = true
    broadcastTyping(false)
    await sendMessage({ body: b })
  })

  window.__pitchtalk_lastRenderedDay = null

  subscribeConversationReads()
  await loadConversationReads()
  await loadMessages()
  subscribeMessages()
  subscribeTyping()

  const ck = currentConversationKey()
  if (ck) markConversationRead(ck)
  startReadHeartbeat()
  renderTypingIndicator()

  const msgsEl = document.getElementById('chat-messages')
  const jumpBtn = document.getElementById('jump-latest')
  if (msgsEl && jumpBtn) {
    const updateJump = () => {
      if (isNearBottomInternal(msgsEl)) jumpBtn.classList.add('hidden')
      else jumpBtn.classList.remove('hidden')
    }
    msgsEl.addEventListener('scroll', updateJump, { passive: true })
    jumpBtn.addEventListener('click', () => {
      msgsEl.scrollTop = msgsEl.scrollHeight
      jumpBtn.classList.add('hidden')
    })
    updateJump()
  }
}

// =========================================================================
// MESSAGE NODE BUILDER
// =========================================================================
export function buildMessageNode(m, { isOptimistic = false } = {}) {
  if (!state.activeChat) return null
  const isGroup = state.activeChat.type === 'group'
  const mine = m.sender_id === state.session.user.id
  const sender = messageSender(m)
  const type = m.message_type || 'text'

  if (type === 'call') return buildCallSummaryNode(m)

  if (type !== 'text' && type !== 'system') {
    const custom = renderStructured(type, m.metadata || {}, m)
    if (custom) {
      const wrap = document.createElement('div')
      wrap.innerHTML = custom.html
      const node = wrap.firstElementChild
      custom.wire?.(node)
      return node
    }
  }

  if (type === 'system') {
    const wrap = document.createElement('div')
    wrap.className = 'system-msg msg-in'
    wrap.innerHTML = `<span>${escapeHtml(m.body || '')}</span>`
    return wrap
  }

  const mentionCtx = currentMentionContext()
  let body = ''
  if (m.is_deleted) {
    body += `<div class="msg-bubble deleted">This message was deleted</div>`
  } else if (m.body) {
    const pendingClass = isOptimistic && m.__status === 'sending' ? ' pending' : ''
    const failedClass  = isOptimistic && m.__status === 'failed'  ? ' failed'  : ''
    body += `<div class="msg-bubble${pendingClass}${failedClass}" data-body="${m.id}">${renderMessageBody(m.body, mentionCtx)}</div>`
  }

  if (m.file_url && !m.is_deleted) {
    if ((m.file_type || '').startsWith('image/')) {
      body += `<a class="image-bubble" href="${escapeHtml(m.file_url)}" target="_blank" rel="noreferrer" download="${escapeHtml(m.file_name)}"><img src="${escapeHtml(m.file_url)}" alt=""></a>`
    } else {
      body += `<a class="file-bubble ${mine ? 'mine' : ''}" href="${escapeHtml(m.file_url)}" target="_blank" rel="noreferrer" download="${escapeHtml(m.file_name)}">
        <span class="file-icon">${ICONS.chat}</span>
        <div class="file-meta">
          <p class="file-name">${escapeHtml(m.file_name || 'file')}</p>
          <p class="file-sub">${formatBytes(m.file_size)} · Download</p>
        </div>
      </a>`
    }
  }

  const actions = (!m.is_deleted && !isOptimistic) ? `
    <div class="msg-actions">
      ${m.body ? `<button data-translate="${m.id}" title="Translate">${ICONS.translate}</button>` : ''}
      ${mine && m.body ? `<button data-edit="${m.id}" title="Edit">${ICONS.edit}</button>` : ''}
      ${mine ? `<button data-delete="${m.id}" class="danger" title="Delete">${ICONS.trash}</button>` : ''}
    </div>` : ''

  const senderAvatar = (isGroup && !mine)
    ? avatarHTML(sender?.display_name||sender?.username||'User', sender?.avatar_url, 'xs', { clickable: true, userId: m.sender_id })
    : ''

  let timeHTML = `<span class="time-text">${formatTime(m.created_at)}</span>`
  timeHTML += m.is_edited ? `<span class="edited-flag"> · edited</span>` : `<span class="edited-flag hidden"> · edited</span>`
  if (m.body && !m.is_deleted) {
    timeHTML += `<span class="translate-toggle hidden" data-toggle-translation="${m.id}">· show translation</span>`
  }
  if (isOptimistic && m.__status === 'sending') {
    timeHTML += `<span class="msg-status-sending"><span class="spin"></span>Sending…</span>`
  } else if (isOptimistic && m.__status === 'failed') {
    timeHTML += `<span class="msg-status-failed" data-retry="${m.id}">⚠ Failed — tap to retry</span>`
  } else if (mine && !m.is_deleted) {
    timeHTML += renderSeenMarkerHTML(m)
  }

  const wrap = document.createElement('div')
  wrap.innerHTML = `<div class="msg-row ${mine ? 'mine' : ''} msg-in" data-msg-id="${m.id}">
    ${senderAvatar}
    <div class="msg-col">
      ${isGroup && !mine ? `<p class="msg-sender">${escapeHtml(sender?.display_name||sender?.username||'')}</p>` : ''}
      ${body}
      ${actions}
      <span class="msg-time">${timeHTML}</span>
    </div>
  </div>`.trim()
  return wrap.firstElementChild
}

function buildCallSummaryNode(m) {
  const info = m.metadata || {}
  const dur = Number(info.duration) || 0
  const isVideo = info.kind === 'video'
  const missed = !!info.missed
  const myId = state.session.user.id
  const iAmCaller = info.caller_id && info.caller_id === myId
  const outgoing = iAmCaller
  const iconSvg = isVideo
    ? ICONS.videoCall
    : (missed ? ICONS.phoneMissed : (outgoing ? ICONS.phoneOut : ICONS.phoneIn))
  const label = missed ? 'Missed' : (outgoing ? 'Outgoing' : 'Incoming')
  const kindLabel = isVideo ? 'video call' : 'audio call'
  const durText = missed ? 'No answer' : window.__pitchtalk_formatDurationLong?.(dur) || `${dur}s`
  const wrap = document.createElement('div')
  wrap.className = 'call-summary-msg msg-in'
  wrap.innerHTML = `<div class="call-summary-card">
    <div class="call-summary-icon">${iconSvg}</div>
    <p class="call-summary-title">${label} ${kindLabel}</p>
    <p class="call-summary-dur">${escapeHtml(durText)}</p>
    <p class="call-summary-time">${formatTime(m.created_at)}</p>
  </div>`
  return wrap
}

function messageSender(m) {
  if (!state.activeChat) return null
  const isGroup = state.activeChat.type === 'group'
  const mine = m.sender_id === state.session.user.id
  if (mine) return state.profile
  if (isGroup) return state.groupMembers.find(x => x.id === m.sender_id)
  return state.activeChat.user
}

function formatBytes(b) {
  if (b==null) return ''
  if (b<1024) return `${b} B`
  if (b<1048576) return `${(b/1024).toFixed(1)} KB`
  if (b<1073741824) return `${(b/1048576).toFixed(1)} MB`
  return `${(b/1073741824).toFixed(2)} GB`
}

// =========================================================================
// SEEN MARKER
// =========================================================================
export function seenByForMessage(m) {
  if (!m || !m.created_at || !state.activeChat) return []
  if (m.sender_id !== state.session.user.id) return []
  const createdMs = new Date(m.created_at).getTime()
  const readers = []
  const isGroup = state.activeChat.type === 'group'

  if (isGroup) {
    state.groupMembers.forEach(mem => {
      if (mem.id === state.session.user.id) return
      const last = state.reads[mem.id]
      if (last && last >= createdMs) readers.push(mem)
    })
  } else {
    const partner = state.activeChat.user
    const last = state.reads[partner.id]
    if (last && last >= createdMs) readers.push(partner)
  }
  return readers
}

export function renderSeenMarkerHTML(m) {
  const readers = seenByForMessage(m)
  if (!readers.length) return ''
  const max = 4
  const shown = readers.slice(0, max)
  const extra = readers.length - shown.length
  const stack = shown.map(r => avatarHTML(r.display_name||r.username, r.avatar_url, 'xs')).join('')
  const overflow = extra > 0 ? `<span style="font-size:9px;color:var(--ink-dim);margin-left:2px;">+${extra}</span>` : ''
  return `<span class="seen-marker" title="Seen by ${readers.map(r => escapeHtml(r.display_name||r.username)).join(', ')}">${stack}${overflow}</span>`
}

export function refreshSeenMarkers() {
  const c = document.getElementById('chat-messages')
  if (!c) return
  c.querySelectorAll('.msg-row.mine').forEach(row => {
    const id = row.dataset.msgId
    if (!id) return
    const timeEl = row.querySelector('.msg-time')
    if (!timeEl) return
    const existing = timeEl.querySelector('.seen-marker')
    const msgData = messageCache.get(id)
    if (!msgData) return
    const html = renderSeenMarkerHTML(msgData)
    if (existing) {
      if (!html) existing.remove()
      else existing.outerHTML = html
    } else if (html) {
      timeEl.insertAdjacentHTML('beforeend', html)
    }
  })
}

window.addEventListener('pitchtalk:reads-changed', () => refreshSeenMarkers())

// =========================================================================
// WIRE MESSAGE ROW
// =========================================================================
export function wireMessageRow(row, m, { isOptimistic = false } = {}) {
  if (!row) return
  messageCache.set(m.id, m)
  row.querySelector(`[data-edit="${m.id}"]`)?.addEventListener('click', () => startEditMessage(m))
  row.querySelector(`[data-delete="${m.id}"]`)?.addEventListener('click', () => deleteMessage(m))
  row.querySelector(`[data-retry="${m.id}"]`)?.addEventListener('click', () => retryPendingSend(m.id))
  row.querySelector(`[data-translate="${m.id}"]`)?.addEventListener('click', () => translateMessage(m))
  row.querySelector(`[data-toggle-translation="${m.id}"]`)?.addEventListener('click', () => toggleTranslation(m.id))
  row.querySelectorAll('[data-avatar-user]').forEach(av => {
    av.onclick = (e) => {
      e.stopPropagation()
      const uid = av.dataset.avatarUser
      if (uid === state.session.user.id) { openModal('profile'); return }
      window.__pitchtalk_openUserProfile?.(uid)
    }
  })
}

// =========================================================================
// EDIT
// =========================================================================
function startEditMessage(m) {
  const c = document.getElementById('chat-messages')
  if (!c) return
  const row = c.querySelector(`[data-msg-id="${m.id}"]`)
  if (!row) return
  const bubble = row.querySelector(`[data-body="${m.id}"]`)
  if (!bubble) return
  bubble.outerHTML = `
    <div class="edit-inline" data-edit-box="${m.id}">
      <textarea id="edit-text-${m.id}" maxlength="${MAX_MESSAGE_LENGTH}">${escapeHtml(m.body || '')}</textarea>
      <div class="edit-inline-actions">
        <button data-cancel="${m.id}">Cancel</button>
        <button class="save" data-save="${m.id}">Save</button>
      </div>
    </div>`
  const ta = document.getElementById(`edit-text-${m.id}`)
  ta.focus()
  ta.setSelectionRange(ta.value.length, ta.value.length)
  row.querySelector(`[data-cancel="${m.id}"]`).onclick = () => {
    ta.parentElement.outerHTML = `<div class="msg-bubble" data-body="${m.id}">${renderMessageBody(m.body, currentMentionContext())}</div>`
  }
  row.querySelector(`[data-save="${m.id}"]`).onclick = async () => {
    const newBody = ta.value.trim()
    if (!newBody) return
    if (newBody.length > MAX_MESSAGE_LENGTH) {
      toastError(`Message too long (max ${MAX_MESSAGE_LENGTH} chars)`)
      return
    }
    try {
      const { error } = await sb.from('messages')
        .update({ body: newBody, is_edited: true, updated_at: new Date().toISOString() })
        .eq('id', m.id)
      if (error) throw error
      m.body = newBody; m.is_edited = true
      messageCache.set(m.id, m)
      ta.parentElement.outerHTML = `<div class="msg-bubble" data-body="${m.id}">${renderMessageBody(newBody, currentMentionContext())}</div>`
      const flag = row.querySelector('.edited-flag')
      if (flag) flag.classList.remove('hidden')
    } catch (err) {
      toastError('Edit failed: ' + err.message)
    }
  }
}

// =========================================================================
// DELETE
// =========================================================================
async function deleteMessage(m) {
  const ok = await window.__pitchtalk_confirmDialog({
    title: 'Delete message?',
    message: 'This will remove the message for everyone in the conversation.',
    confirmText: 'Delete',
    danger: true
  })
  if (!ok) return
  try {
    const { error } = await sb.from('messages')
      .update({ is_deleted: true, body: null, file_url: null })
      .eq('id', m.id)
    if (error) throw error
    m.is_deleted = true; m.body = null; m.file_url = null
    messageCache.set(m.id, m)
    const c = document.getElementById('chat-messages')
    const row = c?.querySelector(`[data-msg-id="${m.id}"]`)
    if (row) {
      const bubble = row.querySelector(`[data-body="${m.id}"]`)
      if (bubble) bubble.outerHTML = `<div class="msg-bubble deleted">This message was deleted</div>`
      row.querySelector('.msg-actions')?.remove()
    }
  } catch (err) {
    toastError('Delete failed: ' + err.message)
  }
}

// =========================================================================
// TRANSLATION
// =========================================================================
async function translateMessage(m) {
  if (!m.body) return
  const key = `${m.id}::${state.translateTo}`
  if (state.translating[key]) return

  const row = document.querySelector(`[data-msg-id="${m.id}"]`)
  const bubble = row?.querySelector(`[data-body="${m.id}"]`)
  if (!bubble) return

  try {
    const { data: cached } = await sb.from('message_translations')
      .select('translated_body')
      .eq('message_id', m.id).eq('target_lang', state.translateTo)
      .maybeSingle()
    if (cached?.translated_body) {
      renderTranslation(row, m, cached.translated_body)
      return
    }

    state.translating[key] = true
    bubble.classList.add('pending')
    const { data: sessionData } = await sb.auth.getSession()
    const token = sessionData?.session?.access_token
    const res = await fetch(`${window.__pitchtalk_SUPABASE_URL}/functions/v1/translate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ text: m.body, target: state.translateTo })
    })
    const j = await res.json()
    if (!res.ok || !j.translated) throw new Error(j.error || 'Translate failed')

    await sb.from('message_translations').insert({
      message_id: m.id, target_lang: state.translateTo, translated_body: j.translated
    })
    renderTranslation(row, m, j.translated)
  } catch (err) {
    toastError('Translation failed: ' + err.message)
  } finally {
    delete state.translating[key]
    bubble.classList.remove('pending')
  }
}

function renderTranslation(row, m, text) {
  const key = `${m.id}::${state.translateTo}`
  state.showTranslation[key] = true
  let box = row.querySelector(`[data-translation="${m.id}"]`)
  if (!box) {
    box = document.createElement('div')
    box.className = 'translation-box'
    box.dataset.translation = m.id
    const col = row.querySelector('.msg-col')
    col.insertBefore(box, col.querySelector('.msg-time'))
  }
  box.innerHTML = `<span class="translation-lang">${state.translateTo.toUpperCase()}</span> ${escapeHtml(text)}`
  const toggle = row.querySelector(`[data-toggle-translation="${m.id}"]`)
  if (toggle) {
    toggle.classList.remove('hidden')
    toggle.textContent = '· hide translation'
  }
}

function toggleTranslation(msgId) {
  const row = document.querySelector(`[data-msg-id="${msgId}"]`)
  if (!row) return
  const box = row.querySelector(`[data-translation="${msgId}"]`)
  const toggle = row.querySelector(`[data-toggle-translation="${msgId}"]`)
  if (!box) return
  const hidden = box.classList.toggle('hidden')
  if (toggle) toggle.textContent = hidden ? '· show translation' : '· hide translation'
}

// =========================================================================
// SCROLL TO MESSAGE
// =========================================================================
export async function scrollToMessage(msgId) {
  const c = document.getElementById('chat-messages')
  if (!c) return
  let row = c.querySelector(`[data-msg-id="${msgId}"]`)
  if (row) {
    row.scrollIntoView({ behavior: 'smooth', block: 'center' })
    flashRow(row)
    return
  }
  row = c.querySelector(`[data-msg-id="${msgId}"]`)
  if (row) {
    row.scrollIntoView({ behavior: 'smooth', block: 'center' })
    flashRow(row)
  } else {
    toastInfo('Message has expired or is too old')
  }
}

function flashRow(row) {
  row.style.transition = 'background .4s ease'
  row.style.background = 'rgba(255,90,31,.18)'
  setTimeout(() => { row.style.background = '' }, 1400)
}

window.addEventListener('pitchtalk:scroll-to', (e) => {
  if (e.detail?.msgId) scrollToMessage(e.detail.msgId)
})