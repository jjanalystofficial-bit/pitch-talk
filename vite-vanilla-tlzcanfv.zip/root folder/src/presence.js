// =========================================================================
// PRESENCE — online/offline tracking + offline beacon
// =========================================================================

import { state, SUPABASE_URL } from './config.js'
import { sb } from './lib.js'

let presenceHeartbeat = null
let presenceMarkedOffline = false

export function isUserOnline(uid) {
  return state.onlineUsers.has(uid)
}

export async function initPresence() {
  if (!state.session) return

  // Mark self online
  await sb.from('presence').upsert({
    user_id: state.session.user.id,
    is_online: true,
    last_seen: new Date().toISOString()
  })

  // Load initial presence
  const { data } = await sb.from('presence').select('*')
  state.onlineUsers = new Set()
  ;(data || []).forEach(p => {
    if (p.is_online && (Date.now() - new Date(p.last_seen).getTime()) < 45000) {
      state.onlineUsers.add(p.user_id)
    }
  })

  // Tear down existing channel if any
  if (state.presenceChannel) {
    try { await sb.removeChannel(state.presenceChannel) } catch (e) {}
    state.presenceChannel = null
  }
  if (presenceHeartbeat) {
    clearInterval(presenceHeartbeat)
    presenceHeartbeat = null
  }

  // Subscribe to presence changes
  state.presenceChannel = sb.channel('presence-global')
    .on('postgres_changes',
      { event: '*', schema: 'public', table: 'presence' },
      (payload) => {
        const row = payload.new || payload.old
        if (!row) return
        if (payload.eventType === 'DELETE' || !row.is_online) {
          state.onlineUsers.delete(row.user_id)
        } else {
          state.onlineUsers.add(row.user_id)
        }
        // Notify UI
        window.dispatchEvent(new CustomEvent('pitchtalk:presence-changed', {
          detail: { userId: row.user_id }
        }))
      }
    ).subscribe()

  // Heartbeat every 30s
  presenceHeartbeat = setInterval(() => {
    if (state.session) {
      sb.from('presence').upsert({
        user_id: state.session.user.id,
        is_online: true,
        last_seen: new Date().toISOString()
      })
    }
  }, 30000)
}

export async function teardownPresence() {
  if (presenceHeartbeat) {
    clearInterval(presenceHeartbeat)
    presenceHeartbeat = null
  }
  if (state.presenceChannel) {
    try { await sb.removeChannel(state.presenceChannel) } catch (e) {}
    state.presenceChannel = null
  }
  state.onlineUsers = new Set()
}

const PRESENCE_OFFLINE_URL = `${SUPABASE_URL}/functions/v1/presence-offline`

export function markPresenceOfflineSync() {
  if (!state.session || presenceMarkedOffline) return
  presenceMarkedOffline = true
  const payload = JSON.stringify({
    user_id: state.session.user.id,
    token: state.session.access_token
  })
  try {
    if (navigator.sendBeacon) {
      const blob = new Blob([payload], { type: 'application/json' })
      const ok = navigator.sendBeacon(PRESENCE_OFFLINE_URL, blob)
      if (ok) return
    }
  } catch (e) {}
  try {
    fetch(PRESENCE_OFFLINE_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: payload,
      keepalive: true
    }).catch(() => {})
  } catch (e) {}
}

export function resetPresenceOfflineFlag() {
  presenceMarkedOffline = false
}

// Wire up global listeners (call once from main.js)
export function installPresenceListeners() {
  window.addEventListener('pagehide', markPresenceOfflineSync)
  window.addEventListener('beforeunload', markPresenceOfflineSync)

  document.addEventListener('visibilitychange', () => {
    if (!state.session) return
    if (document.visibilityState === 'hidden') {
      setTimeout(() => {
        if (document.visibilityState === 'hidden') markPresenceOfflineSync()
      }, 30000)
    } else {
      presenceMarkedOffline = false
      sb.from('presence').upsert({
        user_id: state.session.user.id,
        is_online: true,
        last_seen: new Date().toISOString()
      })
    }
  })
}